from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit, QTextEdit,
    QDateEdit, QPushButton, QMessageBox
)
from PyQt6.QtCore import QDate

class DialogoTransferencia(QDialog):
    def __init__(self, db, proyecto_actual, cuentas, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Transferencia entre cuentas")
        self.setFixedSize(400, 350)
        self.resultado = None
        self.db = db
        self.proyecto_actual = proyecto_actual

        layout = QVBoxLayout(self)

        # --- Cuenta origen ---
        layout.addWidget(QLabel("Cuenta origen:"))
        self.cuenta_origen_cb = QComboBox()
        self.cuenta_origen_cb.addItems(cuentas)
        layout.addWidget(self.cuenta_origen_cb)

        # --- Cuenta destino ---
        layout.addWidget(QLabel("Cuenta destino:"))
        self.cuenta_destino_cb = QComboBox()
        self.cuenta_destino_cb.addItems(cuentas)
        layout.addWidget(self.cuenta_destino_cb)

        # --- Monto ---
        layout.addWidget(QLabel("Monto:"))
        self.monto_edit = QLineEdit()
        layout.addWidget(self.monto_edit)

        # --- Fecha ---
        layout.addWidget(QLabel("Fecha:"))
        self.fecha_edit = QDateEdit()
        self.fecha_edit.setCalendarPopup(True)
        self.fecha_edit.setDate(QDate.currentDate())
        layout.addWidget(self.fecha_edit)

        # --- Descripción ---
        layout.addWidget(QLabel("Descripción:"))
        self.descripcion_edit = QLineEdit()
        layout.addWidget(self.descripcion_edit)

        # --- Comentario ---
        layout.addWidget(QLabel("Comentario:"))
        self.comentario_edit = QTextEdit()
        layout.addWidget(self.comentario_edit)

        # --- Botones ---
        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        btn_guardar.clicked.connect(self.guardar)
        btn_cancelar.clicked.connect(self.reject)

    def guardar(self):
        cuenta_origen = self.cuenta_origen_cb.currentText()
        cuenta_destino = self.cuenta_destino_cb.currentText()
        if cuenta_origen == cuenta_destino:
            QMessageBox.warning(self, "Error", "La cuenta origen y destino deben ser diferentes.")
            return
        try:
            monto = float(self.monto_edit.text().replace(",", "").replace(" ", ""))
        except ValueError:
            QMessageBox.warning(self, "Error", "El monto debe ser un número.")
            return
        fecha = self.fecha_edit.date().toPyDate()
        descripcion = self.descripcion_edit.text().strip()
        comentario = self.comentario_edit.toPlainText().strip()

        cuenta_origen_id = self.db.obtener_o_crear_id('cuentas', cuenta_origen)
        cuenta_destino_id = self.db.obtener_o_crear_id('cuentas', cuenta_destino)

        # --- Solución: Usar categoría especial "Transferencia" para evitar errores NOT NULL ---
        categoria_transferencia_id = self.db.obtener_o_crear_id('categorias', "Transferencia")

        datos_gasto = {
            'cuenta_id': cuenta_origen_id,
            'categoria_id': categoria_transferencia_id,
            'subcategoria_id': None,
            'tipo': "Gasto",
            'descripcion': f"Transferencia a {cuenta_destino}: {descripcion}",
            'comentario': comentario,
            'monto': monto,
            'fecha': fecha
        }
        datos_ingreso = {
            'cuenta_id': cuenta_destino_id,
            'categoria_id': categoria_transferencia_id,
            'subcategoria_id': None,
            'tipo': "Ingreso",
            'descripcion': f"Transferencia desde {cuenta_origen}: {descripcion}",
            'comentario': comentario,
            'monto': monto,
            'fecha': fecha
        }

        exito_gasto = self.proyecto_actual.agregar_transaccion(datos_gasto)
        exito_ingreso = self.proyecto_actual.agregar_transaccion(datos_ingreso)

        if exito_gasto and exito_ingreso:
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "No se pudo registrar la transferencia.")