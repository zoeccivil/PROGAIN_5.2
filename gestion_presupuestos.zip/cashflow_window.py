"""
Ventana de Flujo de Caja por Proyecto.

Esta ventana muestra un resumen del flujo de caja (ingresos, gastos, balance)
por cuenta y por mes/año para un proyecto específico.
"""
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QDateEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QFileDialog, QMessageBox,
    QTabWidget
)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont
import logging
import csv
import os

logger = logging.getLogger(__name__)

# Nombres de meses en español
MESES_NOMBRES = {
    '01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
    '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
    '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'
}


class CashflowWindow(QMainWindow):
    """Ventana de Flujo de Caja por Proyecto."""
    
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.proyecto_id = None
        self.proyecto_nombre = None
        self.transacciones = []
        
        self.setWindowTitle("Flujo de Caja")
        self.setGeometry(150, 150, 900, 600)
        
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # --- Encabezado ---
        header_layout = QHBoxLayout()
        self.lbl_proyecto = QLabel("Proyecto: ---")
        self.lbl_proyecto.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        header_layout.addWidget(self.lbl_proyecto)
        header_layout.addStretch()
        main_layout.addLayout(header_layout)
        
        # --- Controles de rango de fechas ---
        fecha_layout = QHBoxLayout()
        fecha_layout.addWidget(QLabel("Desde:"))
        self.fecha_inicio = QDateEdit()
        self.fecha_inicio.setCalendarPopup(True)
        self.fecha_inicio.setDate(QDate.currentDate().addYears(-1))
        fecha_layout.addWidget(self.fecha_inicio)
        
        fecha_layout.addWidget(QLabel("Hasta:"))
        self.fecha_fin = QDateEdit()
        self.fecha_fin.setCalendarPopup(True)
        self.fecha_fin.setDate(QDate.currentDate())
        fecha_layout.addWidget(self.fecha_fin)
        
        self.btn_actualizar = QPushButton("Actualizar")
        self.btn_actualizar.clicked.connect(self.refresh)
        fecha_layout.addWidget(self.btn_actualizar)
        
        fecha_layout.addStretch()
        
        self.btn_exportar_csv = QPushButton("Exportar CSV")
        self.btn_exportar_csv.clicked.connect(self._exportar_csv)
        fecha_layout.addWidget(self.btn_exportar_csv)
        
        main_layout.addLayout(fecha_layout)
        
        # --- Tabs para diferentes vistas ---
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)
        
        # Tab 1: Resumen por Cuenta
        self.tab_cuentas = QWidget()
        tab_cuentas_layout = QVBoxLayout(self.tab_cuentas)
        
        self.tabla_cuentas = QTableWidget(0, 4)
        self.tabla_cuentas.setHorizontalHeaderLabels(["Cuenta", "Total Ingresos", "Total Gastos", "Balance"])
        header = self.tabla_cuentas.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tab_cuentas_layout.addWidget(self.tabla_cuentas)
        
        self.tabs.addTab(self.tab_cuentas, "Resumen por Cuenta")
        
        # Tab 2: Resumen por Mes
        self.tab_meses = QWidget()
        tab_meses_layout = QVBoxLayout(self.tab_meses)
        
        self.tabla_meses = QTableWidget(0, 4)
        self.tabla_meses.setHorizontalHeaderLabels(["Mes/Año", "Ingresos", "Gastos", "Balance"])
        header_meses = self.tabla_meses.horizontalHeader()
        header_meses.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        tab_meses_layout.addWidget(self.tabla_meses)
        
        self.tabs.addTab(self.tab_meses, "Resumen por Mes")
        
        # --- Resumen total ---
        resumen_group = QGroupBox("Totales Generales")
        resumen_layout = QHBoxLayout()
        self.lbl_total_ingresos = QLabel("Total Ingresos: RD$ 0.00")
        self.lbl_total_ingresos.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.lbl_total_gastos = QLabel("Total Gastos: RD$ 0.00")
        self.lbl_total_gastos.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.lbl_total_balance = QLabel("Balance: RD$ 0.00")
        self.lbl_total_balance.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        resumen_layout.addWidget(self.lbl_total_ingresos)
        resumen_layout.addWidget(self.lbl_total_gastos)
        resumen_layout.addWidget(self.lbl_total_balance)
        resumen_group.setLayout(resumen_layout)
        main_layout.addWidget(resumen_group)
        
        logger.debug("Ventana CashflowWindow inicializada")
    
    def set_project(self, project_id, project_name):
        """Establece el proyecto para mostrar el flujo de caja.
        
        Args:
            project_id: ID del proyecto
            project_name: Nombre del proyecto
        """
        self.proyecto_id = project_id
        self.proyecto_nombre = project_name
        self.setWindowTitle(f"Flujo de Caja - {project_name}")
        self.lbl_proyecto.setText(f"Proyecto: {project_name}")
        logger.info(f"Proyecto establecido: {project_name} (ID: {project_id})")
    
    def set_period(self, fecha_inicio, fecha_fin):
        """Establece el rango de fechas para el flujo de caja.
        
        Args:
            fecha_inicio: Fecha de inicio (QDate o string YYYY-MM-DD)
            fecha_fin: Fecha de fin (QDate o string YYYY-MM-DD)
        """
        if isinstance(fecha_inicio, str):
            partes = fecha_inicio.split('-')
            if len(partes) == 3:
                self.fecha_inicio.setDate(QDate(int(partes[0]), int(partes[1]), int(partes[2])))
        elif isinstance(fecha_inicio, QDate):
            self.fecha_inicio.setDate(fecha_inicio)
        
        if isinstance(fecha_fin, str):
            partes = fecha_fin.split('-')
            if len(partes) == 3:
                self.fecha_fin.setDate(QDate(int(partes[0]), int(partes[1]), int(partes[2])))
        elif isinstance(fecha_fin, QDate):
            self.fecha_fin.setDate(fecha_fin)
    
    def refresh(self):
        """Recalcula y muestra el flujo de caja."""
        if not self.proyecto_id:
            logger.warning("No hay proyecto seleccionado")
            return
        
        logger.debug(f"Actualizando flujo de caja para proyecto {self.proyecto_id}")
        
        # Obtener transacciones del proyecto en el período
        fecha_inicio = self.fecha_inicio.date().toString("yyyy-MM-dd")
        fecha_fin = self.fecha_fin.date().toString("yyyy-MM-dd")
        
        filtros = {
            'fecha_inicio': fecha_inicio,
            'fecha_fin': fecha_fin
        }
        
        self.transacciones = self.db.obtener_transacciones_por_proyecto(self.proyecto_id, filtros) or []
        logger.debug(f"Se obtuvieron {len(self.transacciones)} transacciones")
        
        # Calcular resumen por cuenta
        resumen_cuentas = self._calcular_resumen_por_cuenta()
        self._mostrar_resumen_cuentas(resumen_cuentas)
        
        # Calcular resumen por mes
        resumen_meses = self._calcular_resumen_por_mes()
        self._mostrar_resumen_meses(resumen_meses)
        
        # Calcular totales generales
        total_ingresos = sum(r['ingresos'] for r in resumen_cuentas.values())
        total_gastos = sum(r['gastos'] for r in resumen_cuentas.values())
        total_balance = total_ingresos - total_gastos
        
        self.lbl_total_ingresos.setText(f"Total Ingresos: RD$ {total_ingresos:,.2f}")
        self.lbl_total_gastos.setText(f"Total Gastos: RD$ {total_gastos:,.2f}")
        self.lbl_total_balance.setText(f"Balance: RD$ {total_balance:,.2f}")
        
        # Aplicar color al balance
        if total_balance >= 0:
            self.lbl_total_balance.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.lbl_total_balance.setStyleSheet("color: red; font-weight: bold;")
    
    def _calcular_resumen_por_cuenta(self):
        """Calcula el resumen de ingresos/gastos por cuenta.
        
        Returns:
            dict: {cuenta_nombre: {'ingresos': float, 'gastos': float}}
        """
        resumen = {}
        for t in self.transacciones:
            cuenta = t.get('cuenta_nombre', 'Sin cuenta')
            if cuenta not in resumen:
                resumen[cuenta] = {'ingresos': 0.0, 'gastos': 0.0}
            
            monto = t.get('monto', 0)
            if t.get('tipo') == 'Ingreso':
                resumen[cuenta]['ingresos'] += monto
            elif t.get('tipo') == 'Gasto':
                resumen[cuenta]['gastos'] += monto
        
        return resumen
    
    def _calcular_resumen_por_mes(self):
        """Calcula el resumen de ingresos/gastos por mes.
        
        Returns:
            dict: {mes_año: {'ingresos': float, 'gastos': float}}
        """
        resumen = {}
        for t in self.transacciones:
            fecha_str = str(t.get('fecha', ''))
            if not fecha_str or '-' not in fecha_str:
                continue
            
            try:
                partes = fecha_str.split('-')
                mes_anio = f"{partes[0]}-{partes[1]}"  # YYYY-MM
            except (IndexError, ValueError):
                continue
            
            if mes_anio not in resumen:
                resumen[mes_anio] = {'ingresos': 0.0, 'gastos': 0.0}
            
            monto = t.get('monto', 0)
            if t.get('tipo') == 'Ingreso':
                resumen[mes_anio]['ingresos'] += monto
            elif t.get('tipo') == 'Gasto':
                resumen[mes_anio]['gastos'] += monto
        
        return resumen
    
    def _mostrar_resumen_cuentas(self, resumen):
        """Muestra el resumen por cuenta en la tabla."""
        self.tabla_cuentas.setRowCount(0)
        
        for fila, (cuenta, datos) in enumerate(sorted(resumen.items())):
            self.tabla_cuentas.insertRow(fila)
            balance = datos['ingresos'] - datos['gastos']
            
            self.tabla_cuentas.setItem(fila, 0, QTableWidgetItem(cuenta))
            self.tabla_cuentas.setItem(fila, 1, QTableWidgetItem(f"RD$ {datos['ingresos']:,.2f}"))
            self.tabla_cuentas.setItem(fila, 2, QTableWidgetItem(f"RD$ {datos['gastos']:,.2f}"))
            
            balance_item = QTableWidgetItem(f"RD$ {balance:,.2f}")
            if balance >= 0:
                balance_item.setForeground(Qt.GlobalColor.darkGreen)
            else:
                balance_item.setForeground(Qt.GlobalColor.red)
            self.tabla_cuentas.setItem(fila, 3, balance_item)
    
    def _mostrar_resumen_meses(self, resumen):
        """Muestra el resumen por mes en la tabla."""
        self.tabla_meses.setRowCount(0)
        
        for fila, (mes_anio, datos) in enumerate(sorted(resumen.items())):
            self.tabla_meses.insertRow(fila)
            balance = datos['ingresos'] - datos['gastos']
            
            # Formatear mes/año
            try:
                anio, mes = mes_anio.split('-')
                mes_nombre = MESES_NOMBRES.get(mes, mes)
                mes_anio_formato = f"{mes_nombre} {anio}"
            except ValueError:
                mes_anio_formato = mes_anio
            
            self.tabla_meses.setItem(fila, 0, QTableWidgetItem(mes_anio_formato))
            self.tabla_meses.setItem(fila, 1, QTableWidgetItem(f"RD$ {datos['ingresos']:,.2f}"))
            self.tabla_meses.setItem(fila, 2, QTableWidgetItem(f"RD$ {datos['gastos']:,.2f}"))
            
            balance_item = QTableWidgetItem(f"RD$ {balance:,.2f}")
            if balance >= 0:
                balance_item.setForeground(Qt.GlobalColor.darkGreen)
            else:
                balance_item.setForeground(Qt.GlobalColor.red)
            self.tabla_meses.setItem(fila, 3, balance_item)
    
    def _exportar_csv(self):
        """Exporta el resumen de flujo de caja a CSV."""
        if not self.proyecto_id:
            QMessageBox.warning(self, "Error", "No hay proyecto seleccionado.")
            return
        
        # Preguntar dónde guardar
        default_name = f"flujo_caja_{self.proyecto_nombre}_{QDate.currentDate().toString('yyyyMMdd')}.csv"
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Exportar Flujo de Caja", default_name, "Archivos CSV (*.csv)"
        )
        
        if not filepath:
            return
        
        try:
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                
                # Resumen por cuenta
                writer.writerow([f"Flujo de Caja - {self.proyecto_nombre}"])
                writer.writerow([f"Período: {self.fecha_inicio.date().toString('dd/MM/yyyy')} - {self.fecha_fin.date().toString('dd/MM/yyyy')}"])
                writer.writerow([])
                writer.writerow(["RESUMEN POR CUENTA"])
                writer.writerow(["Cuenta", "Total Ingresos", "Total Gastos", "Balance"])
                
                resumen_cuentas = self._calcular_resumen_por_cuenta()
                for cuenta, datos in sorted(resumen_cuentas.items()):
                    balance = datos['ingresos'] - datos['gastos']
                    writer.writerow([cuenta, datos['ingresos'], datos['gastos'], balance])
                
                writer.writerow([])
                writer.writerow(["RESUMEN POR MES"])
                writer.writerow(["Mes/Año", "Ingresos", "Gastos", "Balance"])
                
                resumen_meses = self._calcular_resumen_por_mes()
                for mes_anio, datos in sorted(resumen_meses.items()):
                    balance = datos['ingresos'] - datos['gastos']
                    writer.writerow([mes_anio, datos['ingresos'], datos['gastos'], balance])
                
                # Totales
                writer.writerow([])
                total_ingresos = sum(r['ingresos'] for r in resumen_cuentas.values())
                total_gastos = sum(r['gastos'] for r in resumen_cuentas.values())
                total_balance = total_ingresos - total_gastos
                writer.writerow(["TOTALES", total_ingresos, total_gastos, total_balance])
            
            QMessageBox.information(self, "Éxito", f"Flujo de caja exportado a:\n{filepath}")
            logger.info(f"Flujo de caja exportado a: {filepath}")
        
        except Exception as e:
            logger.error(f"Error al exportar CSV: {e}")
            QMessageBox.warning(self, "Error", f"No se pudo exportar el archivo:\n{e}")
