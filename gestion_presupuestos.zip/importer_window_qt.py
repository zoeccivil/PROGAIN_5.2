from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QTableWidget, QTableWidgetItem, QFileDialog, QMessageBox, QGroupBox, QTextEdit
)
from PyQt6.QtCore import Qt, QDate
import pandas as pd
import os

class ImporterWindowQt(QDialog):
    def __init__(self, parent, db_manager, proyecto_actual):
        super().__init__(parent)
        self.db = db_manager
        self.proyecto_actual = proyecto_actual
        self.setWindowTitle(f"Asistente de Importación - Proyecto: {self.proyecto_actual.nombre}")
        self.resize(1100, 700)

        self.df_data = None
        self.categorias_map = {}
        self.cuentas_map = {}
        self.subcategorias_map = {}

        layout = QVBoxLayout(self)

        # --- Paso 1: Cargar archivo ---
        file_group = QGroupBox("Paso 1: Cargar Archivo de Transacciones")
        file_layout = QHBoxLayout(file_group)
        self.btn_load_file = QPushButton("Cargar Archivo (XLS, XLSX, CSV)")
        self.lbl_file = QLabel("Ningún archivo cargado.")
        file_layout.addWidget(self.btn_load_file)
        file_layout.addWidget(self.lbl_file)
        layout.addWidget(file_group)

        # --- Tabla de transacciones ---
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Fecha", "Concepto", "Monto", "Tipo"])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)

        # --- Paso 2: Asignar datos de destino ---
        assign_group = QGroupBox("Paso 2: Asignar Datos y Añadir al Proyecto")
        assign_layout = QHBoxLayout(assign_group)
        assign_layout.addWidget(QLabel("Cuenta Destino*:"))
        self.combo_cuenta = QComboBox()
        assign_layout.addWidget(self.combo_cuenta)
        assign_layout.addWidget(QLabel("Categoría*:"))
        self.combo_categoria = QComboBox()
        assign_layout.addWidget(self.combo_categoria)
        assign_layout.addWidget(QLabel("Subcategoría*:"))
        self.combo_subcategoria = QComboBox()
        assign_layout.addWidget(self.combo_subcategoria)
        self.btn_add = QPushButton("Añadir Transacciones Seleccionadas")
        self.btn_add.setEnabled(False)
        assign_layout.addWidget(self.btn_add)
        layout.addWidget(assign_group)

        # --- Registro de actividad ---
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        # --- Conexiones ---
        self.btn_load_file.clicked.connect(self.load_data_file)
        self.combo_categoria.currentIndexChanged.connect(self.update_subcategories)
        self.btn_add.clicked.connect(self.add_selected_to_project)

        # --- Datos iniciales ---
        self.cargar_datos_iniciales_db()

    def log(self, msg):
        self.log_text.append(f"[{pd.Timestamp.now().strftime('%H:%M:%S')}] {msg}")

    def cargar_datos_iniciales_db(self):
        # Cargar cuentas
        cuentas_data = self.db.obtener_cuentas_por_proyecto(self.proyecto_actual.id) or []
        self.cuentas_map = {c['nombre']: c['id'] for c in cuentas_data}
        self.combo_cuenta.clear()
        self.combo_cuenta.addItems(sorted(self.cuentas_map.keys()))

        # Categorías
        categorias_data = self.db.obtener_categorias_por_proyecto(self.proyecto_actual.id) or []
        self.categorias_map = {c['nombre']: c['id'] for c in categorias_data}
        self.combo_categoria.clear()
        self.combo_categoria.addItems(sorted(self.categorias_map.keys()))
        self.update_subcategories()
        self.log("Datos de cuentas y categorías cargados desde la base de datos.")

    def update_subcategories(self):
        cat_nombre = self.combo_categoria.currentText()
        cat_id = self.categorias_map.get(cat_nombre)
        subcats_data = self.db.obtener_subcategorias_por_categoria(cat_id) if cat_id else []
        self.subcategorias_map = {s['nombre']: s['id'] for s in subcats_data}
        self.combo_subcategoria.clear()
        self.combo_subcategoria.addItems(sorted(self.subcategorias_map.keys()))

    def load_data_file(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar archivo de datos", "",
            "Archivos de Excel (*.xls *.xlsx);;Archivos CSV (*.csv)"
        )
        if not filepath:
            return
        try:
            self.log(f"Cargando archivo: {os.path.basename(filepath)}...")
            if filepath.lower().endswith(('.xls', '.xlsx')):
                df = pd.read_excel(filepath)
            elif filepath.lower().endswith('.csv'):
                df = pd.read_csv(filepath, encoding='utf-8')
            else:
                raise ValueError("Formato de archivo no soportado.")

            df.columns = df.columns.str.strip()
            # Adaptar a tu formato de archivo real:
            # Asumimos columnas: 'Fecha', 'Descripción', 'Débito', 'Crédito'
            df['Débito'] = df.get('Débito', 0).fillna(0)
            df['Crédito'] = df.get('Crédito', 0).fillna(0)
            df['Débito_num'] = df['Débito'].apply(self.clean_monto)
            df['Crédito_num'] = df['Crédito'].apply(self.clean_monto)
            df['Monto'] = df.apply(lambda row: row['Débito_num'] if row['Débito_num'] > 0 else row['Crédito_num'], axis=1)
            df['Tipo'] = df.apply(lambda row: 'Gasto' if row['Débito_num'] > 0 else 'Ingreso', axis=1)
            df['Fecha_dt'] = pd.to_datetime(df['Fecha'], dayfirst=True, errors='coerce')
            df.dropna(subset=['Fecha_dt'], inplace=True)
            df = df[df['Monto'] > 0].copy()

            self.df_data = df
            self.lbl_file.setText(os.path.basename(filepath))
            self.table.setRowCount(0)
            for idx, row in self.df_data.iterrows():
                self.table.insertRow(self.table.rowCount())
                self.table.setItem(self.table.rowCount()-1, 0, QTableWidgetItem(row['Fecha_dt'].strftime('%Y-%m-%d')))
                self.table.setItem(self.table.rowCount()-1, 1, QTableWidgetItem(str(row.get("Descripción", ""))))
                self.table.setItem(self.table.rowCount()-1, 2, QTableWidgetItem(f"{row['Monto']:,.2f}"))
                self.table.setItem(self.table.rowCount()-1, 3, QTableWidgetItem(row['Tipo']))
            self.log(f"Archivo cargado. {len(self.df_data)} transacciones encontradas.")
            self.btn_add.setEnabled(True)
        except KeyError as e:
            QMessageBox.critical(self, "Error de Columna", f"No se encontró la columna esperada: {e}. Verifica el formato del archivo.")
        except Exception as e:
            QMessageBox.critical(self, "Error al Cargar", f"No se pudo leer el archivo.\nError: {e}")

    def clean_monto(self, value):
        if pd.isna(value) or value is None: return 0.0
        s_value = str(value).replace('"', '').replace(',', '').strip()
        try: return float(s_value)
        except (ValueError, TypeError): return 0.0

    def add_selected_to_project(self):
        selected_rows = set([idx.row() for idx in self.table.selectedIndexes()])
        if not selected_rows:
            QMessageBox.warning(self, "Sin selección", "Selecciona al menos una transacción de la tabla.")
            return

        cuenta_nombre = self.combo_cuenta.currentText()
        cat_nombre = self.combo_categoria.currentText()
        sub_nombre = self.combo_subcategoria.currentText()

        if not all([cuenta_nombre, cat_nombre, sub_nombre]):
            QMessageBox.warning(self, "Datos faltantes", "Debes seleccionar una Cuenta, Categoría y Subcategoría de destino.")
            return

        cuenta_id = self.cuentas_map.get(cuenta_nombre)
        cat_id = self.categorias_map.get(cat_nombre)
        subcat_id = self.subcategorias_map.get(sub_nombre)
        if not all([cuenta_id, cat_id, subcat_id]):
            QMessageBox.warning(self, "Datos inválidos", "Cuenta/Categoría/Subcategoría seleccionada no válida.")
            return

        added_count = 0
        for idx in selected_rows:
            try:
                csv_row = self.df_data.iloc[idx]
                datos_transaccion = {
                    'cuenta_id': cuenta_id,
                    'categoria_id': cat_id,
                    'subcategoria_id': subcat_id,
                    'tipo': csv_row['Tipo'],
                    'descripcion': csv_row.get('Descripción', ''),
                    'comentario': "Importado desde archivo",
                    'monto': csv_row['Monto'],
                    'fecha': csv_row['Fecha_dt'].date()
                }
                # Usamos el método del objeto Proyecto para agregar la transacción
                if self.proyecto_actual.agregar_transaccion(datos_transaccion):
                    added_count += 1
                else:
                    self.log(f"Error al guardar en BD la fila {idx}.")
            except Exception as e:
                self.log(f"Error procesando la fila {idx}: {e}")

        self.log(f"Proceso completado. Se añadieron {added_count} de {len(selected_rows)} transacciones al proyecto.")
        if added_count > 0:
            QMessageBox.information(self, "Éxito", f"{added_count} transacciones fueron añadidas exitosamente al proyecto.")
