from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QPushButton, QMessageBox
)
from PyQt6.QtCore import Qt

class GestionCuentasProyectoDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Gestionar Cuentas del Proyecto: {proyecto.nombre}")
        self.setFixedSize(700, 400)

        # --- Layout principal ---
        main_layout = QVBoxLayout(self)

        # --- Layout de listas ---
        listas_layout = QHBoxLayout()
        # Cuentas disponibles (maestras)
        disponibles_layout = QVBoxLayout()
        disponibles_layout.addWidget(QLabel("Cuentas Disponibles"))
        self.list_disponibles = QListWidget()
        disponibles_layout.addWidget(self.list_disponibles)
        listas_layout.addLayout(disponibles_layout)

        # Botones mover
        mover_layout = QVBoxLayout()
        self.btn_agregar = QPushButton(">>")
        self.btn_quitar = QPushButton("<<")
        mover_layout.addStretch()
        mover_layout.addWidget(self.btn_agregar)
        mover_layout.addWidget(self.btn_quitar)
        mover_layout.addStretch()
        listas_layout.addLayout(mover_layout)

        # Cuentas del proyecto
        proyecto_layout = QVBoxLayout()
        proyecto_layout.addWidget(QLabel("Cuentas del Proyecto"))
        self.list_proyecto = QListWidget()
        proyecto_layout.addWidget(self.list_proyecto)
        self.btn_principal = QPushButton("Establecer como Principal")
        proyecto_layout.addWidget(self.btn_principal)
        listas_layout.addLayout(proyecto_layout)

        main_layout.addLayout(listas_layout)

        # --- Botones inferiores ---
        btn_layout = QHBoxLayout()
        self.btn_cancelar = QPushButton("Cancelar")
        self.btn_guardar = QPushButton("Guardar Cambios")
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancelar)
        btn_layout.addWidget(self.btn_guardar)
        main_layout.addLayout(btn_layout)

        # --- Estado interno ---
        self.cuentas_disponibles = []
        self.cuentas_proyecto = []
        self.id_cuenta_principal = None

        # --- Cargar datos iniciales ---
        self._cargar_cuentas()

        # --- Conexiones ---
        self.btn_agregar.clicked.connect(self._mover_a_proyecto)
        self.btn_quitar.clicked.connect(self._quitar_de_proyecto)
        self.btn_principal.clicked.connect(self._establecer_principal)
        self.btn_guardar.clicked.connect(self._guardar_cambios)
        self.btn_cancelar.clicked.connect(self.reject)

    def _cargar_cuentas(self):
        # Todas las cuentas maestras (disponibles)
        disponibles = self.db.obtener_cuentas_maestras() or []
        # Todas las cuentas asociadas al proyecto
        cuentas_proy = self.db.obtener_cuentas_por_proyecto(self.proyecto.id) or []
        # IDs de cuentas en el proyecto
        ids_proy = set(c['id'] for c in cuentas_proy)
        self.cuentas_proyecto = list(cuentas_proy)
        self.cuentas_disponibles = [c for c in disponibles if c['id'] not in ids_proy]
        # Principal
        for c in cuentas_proy:
            if c.get('is_principal'):
                self.id_cuenta_principal = c['id']
                break
        self._actualizar_listas()

    def _actualizar_listas(self):
        self.list_disponibles.clear()
        for c in self.cuentas_disponibles:
            self.list_disponibles.addItem(c['nombre'])
        self.list_proyecto.clear()
        for c in self.cuentas_proyecto:
            txt = c['nombre']
            if self.id_cuenta_principal == c['id']:
                txt += " (Principal)"
            self.list_proyecto.addItem(txt)

    def _mover_a_proyecto(self):
        items = self.list_disponibles.selectedItems()
        if not items:
            return
        nombre = items[0].text()
        cuenta = next((c for c in self.cuentas_disponibles if c['nombre'] == nombre), None)
        if cuenta:
            self.cuentas_disponibles.remove(cuenta)
            self.cuentas_proyecto.append({'id': cuenta['id'], 'nombre': cuenta['nombre'], 'is_principal': 0})
            self._actualizar_listas()

    def _quitar_de_proyecto(self):
        items = self.list_proyecto.selectedItems()
        if not items:
            return
        nombre = items[0].text().replace(" (Principal)", "")
        cuenta = next((c for c in self.cuentas_proyecto if c['nombre'] == nombre), None)
        if cuenta:
            if self.id_cuenta_principal == cuenta['id']:
                self.id_cuenta_principal = None
            self.cuentas_proyecto.remove(cuenta)
            self.cuentas_disponibles.append({'id': cuenta['id'], 'nombre': cuenta['nombre']})
            self._actualizar_listas()

    def _establecer_principal(self):
        items = self.list_proyecto.selectedItems()
        if not items:
            QMessageBox.warning(self, "Sin selección", "Selecciona una cuenta del proyecto para establecer como principal.")
            return
        nombre = items[0].text().replace(" (Principal)", "")
        cuenta = next((c for c in self.cuentas_proyecto if c['nombre'] == nombre), None)
        if cuenta:
            self.id_cuenta_principal = cuenta['id']
            self._actualizar_listas()

    def _guardar_cambios(self):
        if not self.cuentas_proyecto:
            QMessageBox.warning(self, "Error", "Debes asignar al menos una cuenta al proyecto.")
            return
        if not self.id_cuenta_principal:
            QMessageBox.warning(self, "Error", "Debes establecer una cuenta principal.")
            return
        ids = [c['id'] for c in self.cuentas_proyecto]
        exito = self.db.actualizar_cuentas_de_proyecto(
            self.proyecto.id,
            ids,
            self.id_cuenta_principal
        )
        if exito:
            QMessageBox.information(self, "Guardado", "Cuentas del proyecto actualizadas correctamente.")
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "No se pudieron guardar las cuentas del proyecto.")
