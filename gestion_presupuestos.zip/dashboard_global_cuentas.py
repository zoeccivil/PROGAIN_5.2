from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QComboBox, QLabel, QPushButton, QSplitter, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtWebEngineWidgets import QWebEngineView
import pandas as pd
import plotly.express as px
import pdfkit
import base64
import tempfile
import os

class DashboardGlobalCuentasWindow(QMainWindow):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.setWindowTitle("Dashboard Global de Cuentas")
        self.resize(1600, 900)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.setCentralWidget(splitter)

        # Panel izquierdo: tabla principal
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        self.table_cuentas = QTableWidget()
        left_layout.addWidget(QLabel("Resumen de cuentas:"))
        left_layout.addWidget(self.table_cuentas)
        splitter.addWidget(left_widget)

        # Panel derecho: filtros y gráficos
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)

        # Filtros
        filtro_layout = QHBoxLayout()
        filtro_layout.addWidget(QLabel("Tipo de gráfico:"))
        self.combo_tipo_grafico = QComboBox()
        self.combo_tipo_grafico.addItems([
            "Balance neto por cuenta",
            "Ingresos vs Gastos por cuenta",
            "Gastos por proyecto (cuenta seleccionada)"
        ])
        filtro_layout.addWidget(self.combo_tipo_grafico)

        filtro_layout.addWidget(QLabel("Cuenta:"))
        self.combo_cuentas = QComboBox()
        filtro_layout.addWidget(self.combo_cuentas)

        # --- PALETA DE COLORES ---
        filtro_layout.addWidget(QLabel("Paleta:"))
        self.combo_paleta = QComboBox()
        self.combo_paleta.addItems([
            "Pastel", "Set3", "Dark2", "Viridis", "Plasma", "Blues", "Greens"
        ])
        filtro_layout.addWidget(self.combo_paleta)

        right_layout.addLayout(filtro_layout)

        # Gráfico
        self.web_view = QWebEngineView()
        right_layout.addWidget(self.web_view, stretch=1)

        # Botón exportar PDF
        export_layout = QHBoxLayout()
        self.btn_export_pdf = QPushButton("Exportar PDF")
        export_layout.addWidget(self.btn_export_pdf)
        right_layout.addLayout(export_layout)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(1, 3)

        # --- Cargar datos iniciales ---
        self.df_cuentas = self.obtener_balances_globales()
        self.df_transacciones = self.obtener_todas_las_transacciones()
        self.cargar_tabla_principal()
        self.cargar_filtros()
        self.actualizar_grafico()

        # Conexiones
        self.combo_tipo_grafico.currentIndexChanged.connect(self.actualizar_grafico)
        self.combo_cuentas.currentIndexChanged.connect(self.actualizar_grafico)
        self.combo_paleta.currentIndexChanged.connect(self.actualizar_grafico)
    # --- Métodos de obtención de datos ---
    def obtener_balances_globales(self):
        # Usa el método balances_globales_todas_cuentas de tu lógica
        datos = self.db_manager.balances_globales_todas_cuentas()
        return pd.DataFrame([dict(fila) for fila in datos])

    def obtener_todas_las_transacciones(self):
        # Usa el método obtener_todas_las_transacciones de tu lógica
        datos = self.db_manager.obtener_todas_las_transacciones()
        df = pd.DataFrame([dict(fila) for fila in datos])
        if not df.empty:
            df['fecha'] = pd.to_datetime(df['fecha'])
        return df

    # --- Cargar tabla principal ---
    def cargar_tabla_principal(self):
        df = self.df_cuentas.copy()
        if 'balance' not in df.columns:
            df['balance'] = df['total_ingresos'] - df['total_gastos']
        self.table_cuentas.setRowCount(len(df))
        self.table_cuentas.setColumnCount(4)
        self.table_cuentas.setHorizontalHeaderLabels(["Cuenta", "Ingresos", "Gastos", "Balance"])
        for i, row in df.iterrows():
            self.table_cuentas.setItem(i, 0, QTableWidgetItem(str(row['cuenta'])))
            self.table_cuentas.setItem(i, 1, QTableWidgetItem(f"{row['total_ingresos']:,.2f}"))
            self.table_cuentas.setItem(i, 2, QTableWidgetItem(f"{row['total_gastos']:,.2f}"))
            self.table_cuentas.setItem(i, 3, QTableWidgetItem(f"{row['balance']:,.2f}"))

    # --- Cargar filtros de cuentas ---
    def cargar_filtros(self):
        cuentas = sorted(self.df_cuentas['cuenta'].unique().tolist())
        self.combo_cuentas.clear()
        self.combo_cuentas.addItem("Todas")
        for cuenta in cuentas:
            self.combo_cuentas.addItem(cuenta)

    # --- Actualizar gráfico según selección ---
    def actualizar_grafico(self):
        tipo = self.combo_tipo_grafico.currentText()
        cuenta_sel = self.combo_cuentas.currentText()
        paleta = self.combo_paleta.currentText()
        df = self.df_cuentas.copy()
        if 'balance' not in df.columns:
            df['balance'] = df['total_ingresos'] - df['total_gastos']

        # Mapas de paletas
        palettes = {
            "Pastel": px.colors.qualitative.Pastel,
            "Set3": px.colors.qualitative.Set3,
            "Dark2": px.colors.qualitative.Dark2,
            "Viridis": px.colors.sequential.Viridis,
            "Plasma": px.colors.sequential.Plasma,
            "Blues": px.colors.sequential.Blues,
            "Greens": px.colors.sequential.Greens,
        }
        palette_colors = palettes.get(paleta, px.colors.qualitative.Pastel)

        if tipo == "Balance neto por cuenta":
            fig = px.bar(
                df,
                x="balance",
                y="cuenta",
                orientation="h",
                labels={"cuenta": "Cuenta", "balance": "Balance"},
                color_discrete_sequence=palette_colors,
            )
        elif tipo == "Ingresos vs Gastos por cuenta":
            df_melt = df.melt(
                id_vars='cuenta',
                value_vars=['total_ingresos', 'total_gastos'],
                var_name='Tipo',
                value_name='Monto'
            )
            fig = px.bar(
                df_melt,
                x="Monto",
                y="cuenta",
                color="Tipo",
                orientation="h",   # Barras horizontales, agrupadas
                labels={"cuenta": "Cuenta", "Monto": "Monto"},
                barmode="group",
                color_discrete_sequence=palette_colors
            )
            fig.update_layout(
                bargap=0.15,
                bargroupgap=0.05,
                title="Ingresos vs Gastos por Cuenta (Global)",
                font_family="Arial",
                font_color="#333",
                legend_title="Tipo",
                plot_bgcolor="#f8f9fa"
            )
            fig.update_xaxes(tickformat=",")
        elif tipo == "Gastos por proyecto (cuenta seleccionada)":
            cuenta = cuenta_sel if cuenta_sel != "Todas" else None
            df_trx = self.df_transacciones
            if cuenta:
                df_trx = df_trx[df_trx['cuenta'] == cuenta]
            gastos_proj = df_trx[df_trx['tipo'] == 'Gasto'].groupby('proyecto')['monto'].sum().reset_index()
            if not gastos_proj.empty:
                fig = px.pie(
                    gastos_proj,
                    names='proyecto',
                    values='monto',
                    title='Gastos por Proyecto',
                    color_discrete_sequence=palette_colors
                )
            else:
                fig = px.bar(x=["Sin datos"], y=[0])
        else:
            fig = px.bar(x=["Sin datos"], y=[0])

        self.web_view.setHtml(fig.to_html(include_plotlyjs='cdn'))

     # --- Exportar PDF ---
    def exportar_reporte_pdf(self):
        wkhtml_path = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
        if not os.path.exists(wkhtml_path):
            wkhtml_path = r'C:\Program Files\wkhtmltopdf\wkhtmltopdf.exe'
            if not os.path.exists(wkhtml_path):
                QMessageBox.warning(self, "Error", f"No se encontró wkhtmltopdf.exe en {wkhtml_path}")
                return
        config = pdfkit.configuration(wkhtmltopdf=wkhtml_path)

        filename, _ = QFileDialog.getSaveFileName(self, "Guardar reporte PDF", "dashboard_global_cuentas.pdf", "Archivo PDF (*.pdf)")
        if not filename:
            return

        # Exporta gráfico como imagen base64
        temp_img = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
        # Exporta el gráfico actual como imagen
        self.web_view.grab().save(temp_img.name)
        temp_img.close()
        with open(temp_img.name, "rb") as f:
            img_data = f.read()
        img_base64 = base64.b64encode(img_data).decode("utf-8")
        img_src = f"data:image/png;base64,{img_base64}"

        # Prepara tabla principal en HTML
        tabla_html = self.df_cuentas.to_html(index=False, float_format=lambda x: f"{x:,.2f}", border=1)

        html = f"""
        <html>
        <head>
        <meta charset="utf-8"/>
        <style>
        body {{ font-family: 'Arial Narrow', Arial, sans-serif; }}
        table {{ border: 1px solid #ccc; border-collapse: collapse; width: 100%; margin-top: 24px; font-family: 'Arial Narrow', Arial, sans-serif; font-size:13px; }}
        th, td {{ border: 1px solid #ccc; padding: 6px; text-align: left; }}
        th {{ background: #e3eefd; }}
        </style>
        </head>
        <body>
        <h1>Dashboard Global de Cuentas</h1>
        <img src="{img_src}" style="width:100%;max-width:1400px;"/>
        {tabla_html}
        </body>
        </html>
        """

        options = {
            'page-size': 'Legal',
            'orientation': 'Landscape',
            'encoding': "UTF-8",
            'margin-top': '0.5in',
            'margin-bottom': '0.5in',
            'margin-left': '0.5in',
            'margin-right': '0.5in',
        }

        try:
            pdfkit.from_string(html, filename, configuration=config, options=options)
            QMessageBox.information(self, "Éxito", "PDF exportado correctamente.")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo exportar PDF: {e}")
        finally:
            try:
                os.remove(temp_img.name)
            except Exception:
                pass