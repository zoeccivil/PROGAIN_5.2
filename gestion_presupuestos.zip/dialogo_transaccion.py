from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QLineEdit, QTextEdit,
    QDateEdit, QPushButton, QMessageBox
)
from PyQt6.QtCore import QDate

class DialogoTransaccion(QDialog):
    def __init__(self, db, proyecto_actual, cuentas, categorias, parent=None, transaccion=None):
        super().__init__(parent)
        self.setWindowTitle("Editar Transacción" if transaccion else "Añadir Transacción")
        self.setFixedSize(400, 400)
        self.resultado = None
        self.db = db
        self.proyecto_actual = proyecto_actual
        self.transaccion = transaccion

        layout = QVBoxLayout(self)

        # --- Tipo ---
        layout.addWidget(QLabel("Tipo:"))
        self.tipo_cb = QComboBox()
        self.tipo_cb.addItems(["Gasto", "Ingreso"])
        layout.addWidget(self.tipo_cb)

        # --- Cuenta ---
        layout.addWidget(QLabel("Cuenta:"))
        self.cuenta_cb = QComboBox()
        self.cuenta_cb.addItems(cuentas)
        layout.addWidget(self.cuenta_cb)

        # --- Categoría ---
        layout.addWidget(QLabel("Categoría:"))
        self.categoria_cb = QComboBox()
        self.categoria_cb.addItems(categorias)
        layout.addWidget(self.categoria_cb)

        # --- Subcategoría ---
        layout.addWidget(QLabel("Subcategoría:"))
        self.subcategoria_cb = QComboBox()
        self.subcategoria_cb.addItem("N/A")
        layout.addWidget(self.subcategoria_cb)
        self.categoria_cb.currentIndexChanged.connect(self._actualizar_subcategorias)

        # --- Descripción ---
        layout.addWidget(QLabel("Descripción:"))
        self.descripcion_edit = QLineEdit()
        layout.addWidget(self.descripcion_edit)

        # --- Monto ---
        layout.addWidget(QLabel("Monto:"))
        self.monto_edit = QLineEdit()
        layout.addWidget(self.monto_edit)

        # --- Fecha ---
        layout.addWidget(QLabel("Fecha:"))
        self.fecha_edit = QDateEdit()
        self.fecha_edit.setCalendarPopup(True)
        self.fecha_edit.setDate(QDate.currentDate())
        layout.addWidget(self.fecha_edit)

        # --- Comentario ---
        layout.addWidget(QLabel("Comentario:"))
        self.comentario_edit = QTextEdit()
        layout.addWidget(self.comentario_edit)

        # --- Botones ---
        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        btn_guardar.clicked.connect(self.guardar)
        btn_cancelar.clicked.connect(self.reject)

        # --- Precarga si está editando
        if transaccion:
            self.tipo_cb.setCurrentText(transaccion.tipo)
            self.cuenta_cb.setCurrentText(transaccion.cuenta_nombre)
            self.categoria_cb.setCurrentText(transaccion.categoria_nombre)
            self._actualizar_subcategorias()
            self.subcategoria_cb.setCurrentText(transaccion.subcategoria_nombre if transaccion.subcategoria_nombre else "N/A")
            self.descripcion_edit.setText(transaccion.descripcion)
            self.monto_edit.setText(str(transaccion.monto))
            self.fecha_edit.setDate(QDate(transaccion.fecha.year, transaccion.fecha.month, transaccion.fecha.day))
            self.comentario_edit.setText(transaccion.comentario if transaccion.comentario else "")
        else:
            self._actualizar_subcategorias()

    def _actualizar_subcategorias(self):
        cat_nombre = self.categoria_cb.currentText()
        self.subcategoria_cb.clear()
        subcats = self.db.obtener_subcategorias_por_categoria(
            self.db.obtener_o_crear_id('categorias', cat_nombre)
        ) or []
        if not subcats:
            self.subcategoria_cb.addItem("N/A")
        else:
            for s in subcats:
                self.subcategoria_cb.addItem(s['nombre'])

    def guardar(self):
        tipo = self.tipo_cb.currentText()
        cuenta_nombre = self.cuenta_cb.currentText()
        categoria_nombre = self.categoria_cb.currentText()
        subcategoria_nombre = self.subcategoria_cb.currentText()
        descripcion = self.descripcion_edit.text().strip()
        try:
            monto = float(self.monto_edit.text().replace(",", "").replace(" ", ""))
        except ValueError:
            QMessageBox.warning(self, "Error", "El monto debe ser un número.")
            return
        fecha = self.fecha_edit.date().toPyDate()
        comentario = self.comentario_edit.toPlainText().strip()

        cuenta_id = self.db.obtener_o_crear_id('cuentas', cuenta_nombre)
        categoria_id = self.db.obtener_o_crear_id('categorias', categoria_nombre)
        subcategoria_id = None
        if subcategoria_nombre and subcategoria_nombre != "N/A":
            subcategoria_id = self.db.obtener_o_crear_id('subcategorias', subcategoria_nombre, 'categoria_id', categoria_id)

        datos = {
            'cuenta_id': cuenta_id,
            'categoria_id': categoria_id,
            'subcategoria_id': subcategoria_id,
            'tipo': tipo,
            'descripcion': descripcion,
            'comentario': comentario,
            'monto': monto,
            'fecha': fecha
        }

        if self.transaccion:
            exito = self.proyecto_actual.editar_transaccion(self.transaccion.id, datos)
        else:
            exito = self.proyecto_actual.agregar_transaccion(datos)
        if exito:
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "No se pudo guardar la transacción.")