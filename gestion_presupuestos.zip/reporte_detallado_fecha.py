from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QHeaderView, QDateEdit, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt, QDate

class ReporteDetalladoFechaDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Reporte Detallado por Fecha - {proyecto.nombre}")
        self.resize(900, 650)  # Ahora es maximizable
        self._setup_ui()
        self._actualizar_tabla()

    def _setup_ui(self):
        layout = QVBoxLayout(self)

        # --- Filtros de fecha
        filtro_layout = QHBoxLayout()
        filtro_layout.addWidget(QLabel("Desde:"))
        self.date_desde = QDateEdit()
        self.date_desde.setCalendarPopup(True)
        self.date_desde.setDate(QDate.currentDate().addMonths(-1))
        filtro_layout.addWidget(self.date_desde)

        filtro_layout.addWidget(QLabel("Hasta:"))
        self.date_hasta = QDateEdit()
        self.date_hasta.setCalendarPopup(True)
        self.date_hasta.setDate(QDate.currentDate())
        filtro_layout.addWidget(self.date_hasta)

        btn_filtrar = QPushButton("Filtrar")
        filtro_layout.addWidget(btn_filtrar)
        layout.addLayout(filtro_layout)

        # --- Tabla de transacciones
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "Tipo", "Categoría", "Subcategoría", "Descripción", "Monto", "Fecha"
        ])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        header.setSectionsMovable(True)
        # Anchos iniciales sugeridos (puedes adaptarlos)
        column_widths = [90, 120, 120, 260, 120, 100]
        for i, ancho in enumerate(column_widths):
            self.table.setColumnWidth(i, ancho)
        layout.addWidget(self.table)

        # --- Botones de exportar
        export_layout = QHBoxLayout()
        btn_pdf = QPushButton("Exportar a PDF")
        btn_excel = QPushButton("Exportar a Excel")
        export_layout.addWidget(btn_pdf)
        export_layout.addWidget(btn_excel)
        layout.addLayout(export_layout)

        # --- Eventos
        btn_filtrar.clicked.connect(self._actualizar_tabla)
        self.date_desde.dateChanged.connect(self._actualizar_tabla)
        self.date_hasta.dateChanged.connect(self._actualizar_tabla)
        btn_pdf.clicked.connect(self._exportar_pdf)
        btn_excel.clicked.connect(self._exportar_excel)

    def _actualizar_tabla(self):
        # --- Obtener fechas
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        # --- Consulta
        transacciones = self.db.obtener_transacciones_por_fecha(self.proyecto.id, fecha_ini, fecha_fin)
        self.transacciones_filtradas = [
            {
                "Tipo": t["tipo"],
                "Categoría": t["categoria_nombre"],
                "Subcategoría": t["subcategoria_nombre"],
                "Descripción": t["descripcion"],
                "Monto": t["monto"],
                "Fecha": t["fecha"]
            }
            for t in transacciones
        ]
        # --- Llenar tabla
        self.table.setRowCount(len(self.transacciones_filtradas))
        for i, t in enumerate(self.transacciones_filtradas):
            self.table.setItem(i, 0, QTableWidgetItem(str(t["Tipo"])))
            self.table.setItem(i, 1, QTableWidgetItem(str(t["Categoría"])))
            self.table.setItem(i, 2, QTableWidgetItem(str(t["Subcategoría"])))
            self.table.setItem(i, 3, QTableWidgetItem(str(t["Descripción"])))
            # --- Formato moneda RD$ XX,XXX.XX ---
            self.table.setItem(i, 4, QTableWidgetItem(f"RD$ {t['Monto']:,.2f}"))
            self.table.setItem(i, 5, QTableWidgetItem(str(t["Fecha"])))
            self.table.item(i, 4).setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

    def _exportar_pdf(self):
        from report_generator import ReportGenerator
        from PyQt6.QtWidgets import QFileDialog, QMessageBox

        # Genera nombre elegante y compacto para el reporte
        nombre_proyecto = self.proyecto.nombre.replace(" ", "_")
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        nombre_reporte = f"Reporte_Detallado_{nombre_proyecto}_{fecha_fin}.pdf"

        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar reporte PDF",
            nombre_reporte,
            "Archivos PDF (*.pdf)"
        )
        if not filepath:
            return
        rg = ReportGenerator(
            data=self.transacciones_filtradas,
            title="Reporte Detallado por Fecha",
            project_name=self.proyecto.nombre,
            date_range=f"{fecha_ini}_{fecha_fin}",
            currency_symbol="RD$",
            column_map={
                "Tipo": "Tipo",
                "Categoría": "Categoría",
                "Subcategoría": "Subcategoría",
                "Descripción": "Descripción",
                "Monto": "Monto",
                "Fecha": "Fecha"
            }
        )
        ok, msg = rg.to_pdf(filepath)
        if ok:
            QMessageBox.information(self, "Exportación", "Reporte PDF exportado correctamente.")
        else:
            QMessageBox.warning(self, "Error PDF", f"No se pudo exportar PDF: {msg}")

    def _exportar_excel(self):
        from report_generator import ReportGenerator
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Guardar reporte Excel", "reporte_detallado_fecha.xlsx", "Archivos Excel (*.xlsx)"
        )
        if not filepath:
            return
        column_map = {
            "Tipo": "Tipo",
            "Categoría": "Categoría",
            "Subcategoría": "Subcategoría",
            "Descripción": "Descripción",
            "Monto": "Monto",
            "Fecha": "Fecha"
        }
        rg = ReportGenerator(
            data=self.transacciones_filtradas,
            title="Reporte Detallado por Fecha",
            project_name=self.proyecto.nombre,
            date_range=f"{self.date_desde.date().toString('dd/MM/yyyy')} - {self.date_hasta.date().toString('dd/MM/yyyy')}",
            currency_symbol="RD$",
            column_map=column_map
        )
        ok, msg = rg.to_excel(filepath)
        if ok:
            QMessageBox.information(self, "Exportación", "Reporte Excel exportado correctamente.")
        else:
            QMessageBox.warning(self, "Error Excel", f"No se pudo exportar Excel: {msg}")