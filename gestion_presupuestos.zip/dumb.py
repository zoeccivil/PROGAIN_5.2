#!/usr/bin/env python3
"""
dump_db_info_gui.py

Script para inspeccionar una base de datos SQLite usando un diálogo de selección de fichero.
Genera una carpeta ./db_dump_<timestamp>/ con:
 - tables.txt                  : lista de tablas
 - pragma_<tabla>.csv          : esquema (PRAGMA table_info) por tabla (si existe)
 - sample_<tabla>.csv          : primeras N filas de ejemplo por tabla (transacciones filtra proyecto_id=8)
 - counts.txt                  : counts rápidos solicitados
 - log.txt                     : registro de operaciones y errores

Uso:
  python dump_db_info_gui.py

Al ejecutarlo se abrirá una ventana para seleccionar el archivo .db.
"""
import sqlite3
import csv
import os
import datetime
import sys
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox

TARGET_TABLES = [
    "transacciones",
    "pagos",
    "equipos_alquiler_meta",
    "equipos_entidades",
    "proyectos",
    "cuentas",
    "categorias",
    "subcategorias",
]

DEFAULT_SAMPLE_LIMIT = 50

def safe_query(cur, sql, params=()):
    try:
        cur.execute(sql, params)
        rows = cur.fetchall()
        desc = [d[0] for d in cur.description] if cur.description else []
        return rows, desc, None
    except Exception as e:
        return None, None, str(e)

def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if header:
            w.writerow(header)
        for r in rows:
            # convert sqlite3.Row or tuples to list
            w.writerow([("" if v is None else v) for v in (tuple(r) if not isinstance(r, (list, tuple)) else r)])

def choose_db_file():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Selecciona el archivo de base de datos SQLite (.db)",
        filetypes=[("SQLite Database", "*.db *.sqlite *.sqlite3"), ("All files", "*.*")],
    )
    root.destroy()
    return file_path

def main():
    try:
        db_path = choose_db_file()
        if not db_path:
            print("No se seleccionó ningún archivo. Saliendo.")
            return

        if not os.path.exists(db_path):
            messagebox.showerror("Error", f"No se encontró el archivo: {db_path}")
            return

        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        outdir = f"db_dump_{ts}"
        os.makedirs(outdir, exist_ok=True)

        log_lines = []
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Lista de tablas
        tables_sql = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
        rows, desc, err = safe_query(cur, tables_sql)
        tables_list = []
        tables_path = os.path.join(outdir, "tables.txt")
        with open(tables_path, "w", encoding="utf-8") as f:
            if err:
                f.write(f"ERROR ejecutando .tables: {err}\n")
                log_lines.append(f"ERROR .tables: {err}")
            else:
                tables_list = [r[0] for r in rows]
                for t in tables_list:
                    f.write(t + "\n")
                log_lines.append(f"Found {len(tables_list)} tables")

        # PRAGMA table_info and samples
        for tbl in TARGET_TABLES:
            pragma_file = os.path.join(outdir, f"pragma_{tbl}.csv")
            sample_file = os.path.join(outdir, f"sample_{tbl}.csv")
            # PRAGMA
            pragma_sql = f"PRAGMA table_info('{tbl}');"
            pragma_rows, pragma_meta, pragma_err = safe_query(cur, pragma_sql)
            if pragma_err or not pragma_rows:
                with open(pragma_file, "w", encoding="utf-8") as f:
                    if pragma_err:
                        f.write(f"NO EXISTE o error: {pragma_err}\n")
                        log_lines.append(f"{tbl}: PRAGMA ERROR: {pragma_err}")
                    else:
                        f.write("NO EXISTE (0 filas en PRAGMA)\n")
                        log_lines.append(f"{tbl}: PRAGMA returned 0 rows")
            else:
                header = ["cid","name","type","notnull","dflt_value","pk"]
                # pragma_rows contains tuples like (cid, name, type, notnull, dflt_value, pk)
                write_csv(pragma_file, header, pragma_rows)
                log_lines.append(f"{tbl}: PRAGMA rows={len(pragma_rows)}")

            # Samples
            if tbl == "transacciones":
                sample_sql = f"SELECT * FROM {tbl} WHERE proyecto_id = 8 LIMIT {DEFAULT_SAMPLE_LIMIT};"
            else:
                sample_sql = f"SELECT * FROM {tbl} LIMIT {DEFAULT_SAMPLE_LIMIT};"

            try:
                cur.execute(sample_sql)
                sample_rows = cur.fetchall()
                sample_meta = [d[0] for d in cur.description] if cur.description else []
                if sample_meta:
                    write_csv(sample_file, sample_meta, [tuple(r) for r in sample_rows])
                    log_lines.append(f"{tbl}: samples rows={len(sample_rows)}")
                else:
                    with open(sample_file, "w", encoding="utf-8") as f:
                        f.write("NO EXISTE o tabla vacía\n")
                    log_lines.append(f"{tbl}: SELECT returned no columns (table may not exist)")
            except Exception as e:
                with open(sample_file, "w", encoding="utf-8") as f:
                    f.write(f"NO EXISTE o error en SELECT: {str(e)}\n")
                log_lines.append(f"{tbl}: SELECT error: {str(e)}")

        # Counts rápidos
        counts_path = os.path.join(outdir, "counts.txt")
        with open(counts_path, "w", encoding="utf-8") as f:
            q = "SELECT COUNT(*) FROM transacciones WHERE proyecto_id = 8;"
            try:
                cur.execute(q)
                c = cur.fetchone()[0]
                f.write(f"total_transacciones_proyecto_8: {c}\n")
            except Exception as e:
                f.write(f"total_transacciones_proyecto_8: ERROR: {e}\n")
            for t in ["pagos","equipos_alquiler_meta","equipos_entidades"]:
                q = f"SELECT COUNT(*) FROM {t};"
                try:
                    cur.execute(q)
                    c = cur.fetchone()[0]
                    f.write(f"total_{t}: {c}\n")
                except Exception as e:
                    f.write(f"total_{t}: ERROR: {e}\n")

        # Close and write log
        conn.close()
        with open(os.path.join(outdir, "log.txt"), "w", encoding="utf-8") as f:
            for l in log_lines:
                f.write(l + "\n")

        summary = f"Dump completado en: {outdir}\nArchivos generados:\n" + "\n".join(sorted(os.listdir(outdir)))
        print(summary)
        # Show a message box with the folder path
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Dump completado", f"Dump completado en:\n{outdir}\n\nRevisa los archivos y pega aquí los que necesites.")
        root.destroy()

    except Exception as ex:
        tb = traceback.format_exc()
        print("Error:", ex)
        print(tb)
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Error", f"Ha ocurrido un error:\n{ex}\n\nRevisa la terminal para más detalles.")
            root.destroy()
        except:
            pass

if __name__ == "__main__":
    main()