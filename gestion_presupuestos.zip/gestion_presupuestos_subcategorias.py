from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QMessageBox, QHBoxLayout, QHeaderView, QComboBox, QFileDialog
)
from PyQt6.QtCore import Qt

class GestionPresupuestosSubcategoriasDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Presupuestos por Subcategoría - {proyecto.nombre}")
        self.setFixedSize(800, 700)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Filtra por categoría y subcategoría:"))

        filtro_layout = QHBoxLayout()
        self.combo_categoria = QComboBox()
        self.combo_subcategoria = QComboBox()
        self.combo_categoria.addItem("Todas las categorías")
        self.combo_subcategoria.addItem("Todas las subcategorías")
        filtro_layout.addWidget(QLabel("Categoría:"))
        filtro_layout.addWidget(self.combo_categoria)
        filtro_layout.addWidget(QLabel("Subcategoría:"))
        filtro_layout.addWidget(self.combo_subcategoria)
        layout.addLayout(filtro_layout)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            "Categoría", "Subcategoría", "Presupuesto", "Gastado", "Diferencia"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)

        self.label_totales = QLabel("")
        layout.addWidget(self.label_totales)

        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar Cambios")
        btn_exportar_excel = QPushButton("Exportar a Excel")
        btn_exportar_pdf = QPushButton("Exportar a PDF")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_exportar_excel)
        btn_layout.addWidget(btn_exportar_pdf)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        self.presupuestos = self.db.obtener_presupuestos_por_subcategoria(self.proyecto.id) or []
        self._llenar_combos()
        self._cargar_presupuestos()

        self.combo_categoria.currentIndexChanged.connect(self._filtrar)
        self.combo_subcategoria.currentIndexChanged.connect(self._filtrar)
        btn_guardar.clicked.connect(self._guardar)
        btn_cancelar.clicked.connect(self.reject)
        btn_exportar_excel.clicked.connect(self._exportar_excel)
        btn_exportar_pdf.clicked.connect(self._exportar_pdf)

    def _llenar_combos(self):
        categorias = sorted(set(p["categoria_nombre"] for p in self.presupuestos))
        self.combo_categoria.addItems(categorias)

    def _actualizar_combo_subcategorias(self):
        cat = self.combo_categoria.currentText()
        self.combo_subcategoria.blockSignals(True)
        self.combo_subcategoria.clear()
        self.combo_subcategoria.addItem("Todas las subcategorías")
        if cat == "Todas las categorías":
            subs = sorted(set(p["subcategoria_nombre"] for p in self.presupuestos))
        else:
            subs = sorted(set(p["subcategoria_nombre"] for p in self.presupuestos if p["categoria_nombre"] == cat))
        self.combo_subcategoria.addItems(subs)
        self.combo_subcategoria.blockSignals(False)

    def _filtrar(self):
        self._actualizar_combo_subcategorias()
        cat = self.combo_categoria.currentText()
        subcat = self.combo_subcategoria.currentText()
        if cat == "Todas las categorías":
            datos = self.presupuestos
        else:
            datos = [p for p in self.presupuestos if p["categoria_nombre"] == cat]
        if subcat != "Todas las subcategorías":
            datos = [p for p in datos if p["subcategoria_nombre"] == subcat]
        self._cargar_presupuestos(datos)

    def _cargar_presupuestos(self, presupuestos=None):
        if presupuestos is None:
            presupuestos = self.presupuestos

        self.table.setRowCount(len(presupuestos))
        total_presupuesto = 0
        total_gasto = 0

        for i, item in enumerate(presupuestos):
            subcat_id = item["subcategoria_id"]
            cat_nombre = item["categoria_nombre"]
            subcat_nombre = item["subcategoria_nombre"]
            presupuesto = item.get("presupuesto", 0)
            gastado = self.db.obtener_gasto_por_subcategoria_en_proyecto(self.proyecto.id, subcat_id)
            diferencia = presupuesto - gastado

            self.table.setItem(i, 0, QTableWidgetItem(cat_nombre))
            self.table.setItem(i, 1, QTableWidgetItem(subcat_nombre))
            self.table.setItem(i, 2, QTableWidgetItem(str(presupuesto)))
            self.table.setItem(i, 3, QTableWidgetItem(str(gastado)))
            item_dif = QTableWidgetItem(str(diferencia))
            if diferencia < 0:
                item_dif.setForeground(Qt.GlobalColor.red)
            self.table.setItem(i, 4, item_dif)

            total_presupuesto += presupuesto
            total_gasto += gastado

        self.label_totales.setText(
            f"Total presupuesto asignado: {total_presupuesto:.2f} | Total gastado: {total_gasto:.2f} | Saldo: {total_presupuesto-total_gasto:.2f}"
        )

        for i in range(self.table.rowCount()):
            self.table.item(i, 2).setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsEditable)

    def _guardar(self):
        filas_invalidas = []
        for i in range(self.table.rowCount()):
            subcat_nombre = self.table.item(i, 1).text()
            presupuesto_str = self.table.item(i, 2).text().replace(",", "")
            try:
                presupuesto = float(presupuesto_str)
            except Exception:
                filas_invalidas.append(i+1)
                continue
            subcategoria_id = None
            for subcat in self.presupuestos:
                if subcat["subcategoria_nombre"] == subcat_nombre:
                    subcategoria_id = subcat["subcategoria_id"]
                    break
            if subcategoria_id is not None:
                self.db.actualizar_presupuesto_subcategoria(self.proyecto.id, subcategoria_id, presupuesto)
        if filas_invalidas:
            QMessageBox.warning(self, "Error", f"Presupuesto inválido en las filas: {', '.join(map(str, filas_invalidas))}")
            return
        QMessageBox.information(self, "Presupuestos", "Presupuestos de subcategorías actualizados correctamente.")
        self.accept()

    def _exportar_excel(self):
        from report_generator import ReportGenerator

        datos = []
        for i in range(self.table.rowCount()):
            datos.append({
                "Categoría": self.table.item(i, 0).text(),
                "Subcategoría": self.table.item(i, 1).text(),
                "Presupuesto": float(self.table.item(i, 2).text()),
                "Gastado": float(self.table.item(i, 3).text()),
                "Diferencia": float(self.table.item(i, 4).text())
            })

        filepath, _ = QFileDialog.getSaveFileName(self, "Guardar reporte Excel", "presupuestos_subcategorias.xlsx", "Archivos Excel (*.xlsx)")
        if not filepath:
            return

        column_map = {
            "Categoría": "Categoría",
            "Subcategoría": "Subcategoría",
            "Presupuesto": "Presupuesto",
            "Gastado": "Gastado",
            "Diferencia": "Diferencia"
        }
        rg = ReportGenerator(
            data=datos,
            title="Presupuestos por Subcategoría",
            project_name=self.proyecto.nombre,
            date_range="",
            currency_symbol="RD$",
            column_map=column_map
        )
        ok, msg = rg.to_excel(filepath)
        if ok:
            QMessageBox.information(self, "Exportación", "Reporte exportado correctamente.")
        else:
            QMessageBox.warning(self, "Error", f"No se pudo exportar: {msg}")

    def _exportar_pdf(self):
        from report_generator import ReportGenerator

        datos = []
        for i in range(self.table.rowCount()):
            datos.append({
                "Categoría": self.table.item(i, 0).text(),
                "Subcategoría": self.table.item(i, 1).text(),
                "Presupuesto": float(self.table.item(i, 2).text()),
                "Gastado": float(self.table.item(i, 3).text()),
                "Diferencia": float(self.table.item(i, 4).text())
            })

        filepath, _ = QFileDialog.getSaveFileName(self, "Guardar reporte PDF", "presupuestos_subcategorias.pdf", "Archivos PDF (*.pdf)")
        if not filepath:
            return

        column_map = {
            "Categoría": "Categoría",
            "Subcategoría": "Subcategoría",
            "Presupuesto": "Presupuesto",
            "Gastado": "Gastado",
            "Diferencia": "Diferencia"
        }
        rg = ReportGenerator(
            data=datos,
            title="Presupuestos por Subcategoría",
            project_name=self.proyecto.nombre,
            date_range="",
            currency_symbol="RD$",
            column_map=column_map
        )
        ok, msg = rg.to_pdf(filepath)
        if ok:
            QMessageBox.information(self, "Exportación", "Reporte PDF exportado correctamente.")
        else:
            QMessageBox.warning(self, "Error", f"No se pudo exportar PDF: {msg}")