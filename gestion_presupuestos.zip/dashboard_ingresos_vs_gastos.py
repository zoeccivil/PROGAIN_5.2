from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox,
    QDateEdit, QTreeWidget, QTreeWidgetItem, QSplitter, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtWebEngineWidgets import QWebEngineView
import pandas as pd
import plotly.express as px
import pdfkit
import base64
import tempfile
import os

class DashboardIngresosVsGastosWindow(QMainWindow):
    def __init__(self, db_manager, proyecto_actual, moneda, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager  # <--- CORREGIDO: guarda la instancia correctamente
        self.proyecto_actual = proyecto_actual
        self.moneda = moneda
        self.setWindowTitle(f"Ingresos vs Gastos - {proyecto_actual.nombre}")
        self.resize(1400, 800)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.setCentralWidget(splitter)

        # Panel lateral: filtros y árbol de categorías
        lateral_widget = QWidget()
        lateral_layout = QVBoxLayout(lateral_widget)
        lateral_layout.addWidget(QLabel("Cuenta:"))
        self.combo_cuentas = QComboBox()
        cuentas = self.db_manager.obtener_cuentas_por_proyecto(self.proyecto_actual.id)
        self.combo_cuentas.addItem("Todas", None)
        for cuenta in cuentas:
            self.combo_cuentas.addItem(cuenta['nombre'], cuenta['id'])
        lateral_layout.addWidget(self.combo_cuentas)

        lateral_layout.addWidget(QLabel("Filtrar por:"))
        self.combo_filtro_lateral = QComboBox()
        self.combo_filtro_lateral.addItems(["Categoría", "Subcategoría"])
        lateral_layout.addWidget(self.combo_filtro_lateral)

        lateral_layout.addWidget(QLabel("Categorías/Subcategorías:"))
        self.tree_categorias = QTreeWidget()
        self.tree_categorias.setHeaderLabels(["Nombre", "Total"])
        lateral_layout.addWidget(self.tree_categorias, stretch=1)

        splitter.addWidget(lateral_widget)

        # Panel central: filtros, gráfico, tabla
        central_widget = QWidget()
        central_layout = QVBoxLayout(central_widget)

        filtro_layout = QHBoxLayout()
        filtro_layout.addWidget(QLabel("Desde:"))
        self.date_desde = QDateEdit()
        self.date_desde.setCalendarPopup(True)
        filtro_layout.addWidget(self.date_desde)
        filtro_layout.addWidget(QLabel("Hasta:"))
        self.date_hasta = QDateEdit()
        self.date_hasta.setCalendarPopup(True)
        filtro_layout.addWidget(self.date_hasta)
        filtro_layout.addWidget(QLabel("Tipo de Gráfico:"))
        self.combo_tipo_grafico = QComboBox()
        self.combo_tipo_grafico.addItems(["Barra", "Línea", "Pastel"])
        filtro_layout.addWidget(self.combo_tipo_grafico)
        central_layout.addLayout(filtro_layout)

        # Fechas iniciales
        self.date_desde.setDate(QDate.currentDate().addMonths(-6))
        self.date_hasta.setDate(QDate.currentDate())

        # Gráfico
        self.web_view = QWebEngineView()
        central_layout.addWidget(self.web_view, stretch=1)

        # Tabla dinámica
        self.web_tabla = QWebEngineView()
        central_layout.addWidget(self.web_tabla, stretch=1)

        # Botón exportar PDF
        export_layout = QHBoxLayout()
        self.btn_export_pdf = QPushButton("Exportar PDF")
        export_layout.addWidget(self.btn_export_pdf)
        central_layout.addLayout(export_layout)
        splitter.addWidget(central_widget)
        splitter.setStretchFactor(1, 3)

        # Conexiones automáticas
        self.combo_cuentas.currentIndexChanged.connect(self.actualizar_dashboard)
        self.combo_filtro_lateral.currentIndexChanged.connect(self.actualizar_dashboard)
        self.date_desde.dateChanged.connect(self.actualizar_dashboard)
        self.date_hasta.dateChanged.connect(self.actualizar_dashboard)
        self.combo_tipo_grafico.currentIndexChanged.connect(self.actualizar_dashboard)
        self.btn_export_pdf.clicked.connect(self.exportar_reporte_pdf)

        self.figura_actual = None
        self.actualizar_dashboard()

    def obtener_ingresos_agrupados(self):
        cuenta_id = self.combo_cuentas.currentData()
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        params = [self.proyecto_actual.id, fecha_ini, fecha_fin]
        filtro_cuenta = ""
        if cuenta_id:
            filtro_cuenta = "AND t.cuenta_id = ?"
            params.append(cuenta_id)

        query = f"""
            SELECT 
                strftime('%Y-%m', t.fecha) as mes,
                c.nombre as categoria,
                s.nombre as subcategoria,
                SUM(t.monto) as monto
            FROM transacciones t
            JOIN categorias c ON t.categoria_id = c.id
            LEFT JOIN subcategorias s ON t.subcategoria_id = s.id
            WHERE t.proyecto_id = ?
              AND t.tipo = 'Ingreso'
              AND t.fecha BETWEEN ? AND ?
              {filtro_cuenta}
            GROUP BY mes, categoria, subcategoria
            ORDER BY mes, categoria, subcategoria
        """
        print("Consulta ingresos SQL:", query)
        print("Parámetros:", params)
        raw = self.db_manager.fetch_all(query, params)
        print("Raw ingresos:", raw)
        if raw:
            # Si fetch_all devuelve dicts:
            if isinstance(raw[0], dict):
                df = pd.DataFrame(raw)
            else:
                columns = ['mes', 'categoria', 'subcategoria', 'monto']
                df = pd.DataFrame(raw, columns=columns)
        else:
            columns = ['mes', 'categoria', 'subcategoria', 'monto']
            df = pd.DataFrame([], columns=columns)
        print("DataFrame ingresos:", df)
        print("Columnas ingresos:", df.columns)
        return df

    def obtener_gastos_agrupados(self):
        cuenta_id = self.combo_cuentas.currentData()
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        params = [self.proyecto_actual.id, fecha_ini, fecha_fin]
        filtro_cuenta = ""
        if cuenta_id:
            filtro_cuenta = "AND t.cuenta_id = ?"
            params.append(cuenta_id)

        query = f"""
            SELECT 
                strftime('%Y-%m', t.fecha) as mes,
                c.nombre as categoria,
                s.nombre as subcategoria,
                SUM(t.monto) as monto
            FROM transacciones t
            JOIN categorias c ON t.categoria_id = c.id
            LEFT JOIN subcategorias s ON t.subcategoria_id = s.id
            WHERE t.proyecto_id = ?
              AND t.tipo = 'Gasto'
              AND t.fecha BETWEEN ? AND ?
              {filtro_cuenta}
            GROUP BY mes, categoria, subcategoria
            ORDER BY mes, categoria, subcategoria
        """
        print("Consulta gastos SQL:", query)
        print("Parámetros:", params)
        raw = self.db_manager.fetch_all(query, params)
        print("Raw gastos:", raw)
        if raw:
            # Si fetch_all devuelve dicts:
            if isinstance(raw[0], dict):
                df = pd.DataFrame(raw)
            else:
                columns = ['mes', 'categoria', 'subcategoria', 'monto']
                df = pd.DataFrame(raw, columns=columns)
        else:
            columns = ['mes', 'categoria', 'subcategoria', 'monto']
            df = pd.DataFrame([], columns=columns)
        print("DataFrame gastos:", df)
        print("Columnas gastos:", df.columns)
        return df

    def actualizar_dashboard(self):
        df_ingresos = self.obtener_ingresos_agrupados()
        df_gastos = self.obtener_gastos_agrupados()

        # Prepara meses únicos
        meses = sorted(set(df_ingresos['mes'].dropna().tolist() + df_gastos['mes'].dropna().tolist()))
        if not meses:
            # Si no hay meses, muestra gráfico vacío
            fig = px.bar(x=["Sin datos"], y=[0])
            self.web_view.setHtml(fig.to_html(include_plotlyjs='cdn'))
            self.web_tabla.setHtml("<h3>No hay datos en el rango seleccionado.</h3>")
            return

        # Series con el mismo tamaño que meses
        ingresos_por_mes = df_ingresos.groupby('mes')['monto'].sum().reindex(meses, fill_value=0)
        gastos_por_mes = df_gastos.groupby('mes')['monto'].sum().reindex(meses, fill_value=0)

        chart_df = pd.DataFrame({
            "Mes": meses,
            "Ingresos": ingresos_por_mes.values.astype(float),
            "Gastos": gastos_por_mes.values.astype(float)
        })

        chart_type = self.combo_tipo_grafico.currentText()
        if chart_type == "Barra":
            fig = px.bar(
                chart_df,
                x="Mes",
                y=["Ingresos", "Gastos"],
                labels={"value": f"{self.moneda}", "Mes": "Mes"},
                barmode="group"
            )
            fig.update_traces(marker_line_width=0)
            fig.update_layout(showlegend=True)
        elif chart_type == "Línea":
            fig = px.line(
                chart_df,
                x="Mes",
                y=["Ingresos", "Gastos"],
                markers=True
            )
        elif chart_type == "Pastel":
            total_ingresos = ingresos_por_mes.sum()
            total_gastos = gastos_por_mes.sum()
            fig = px.pie(
                names=["Ingresos", "Gastos"],
                values=[total_ingresos, total_gastos],
                hole=0.3
            )
        else:
            fig = px.bar(x=["Sin datos"], y=[0])

        self.figura_actual = fig
        self.web_view.setHtml(fig.to_html(include_plotlyjs='cdn'))

    # ... resto del método (tabla dinámica, árbol, etc) ...

        # Tabla dinámica: mes/categoría/subcategoría
        tabla_html = self.generar_tabla_dinamica(df_ingresos, df_gastos, meses)
        self.web_tabla.setHtml(tabla_html)

        # Árbol de categorías lateral
        self.tree_categorias.clear()
        categorias = set(df_ingresos['categoria'].dropna().tolist() + df_gastos['categoria'].dropna().tolist())
        for cat in categorias:
            total_cat = 0
            if cat in df_ingresos['categoria'].values:
                total_cat += df_ingresos[df_ingresos['categoria'] == cat]['monto'].sum()
            if cat in df_gastos['categoria'].values:
                total_cat += df_gastos[df_gastos['categoria'] == cat]['monto'].sum()
            item_cat = QTreeWidgetItem([str(cat), f"{self.moneda}{total_cat:,.2f}"])
            self.tree_categorias.addTopLevelItem(item_cat)
            # Subcategorías
            subcats = set(
                df_ingresos[df_ingresos['categoria'] == cat]['subcategoria'].dropna().tolist() +
                df_gastos[df_gastos['categoria'] == cat]['subcategoria'].dropna().tolist()
            )
            for subcat in subcats:
                total_subcat = 0
                if subcat in df_ingresos['subcategoria'].values:
                    total_subcat += df_ingresos[(df_ingresos['categoria'] == cat) & (df_ingresos['subcategoria'] == subcat)]['monto'].sum()
                if subcat in df_gastos['subcategoria'].values:
                    total_subcat += df_gastos[(df_gastos['categoria'] == cat) & (df_gastos['subcategoria'] == subcat)]['monto'].sum()
                item_subcat = QTreeWidgetItem([str(subcat), f"{self.moneda}{total_subcat:,.2f}"])
                item_cat.addChild(item_subcat)

    def generar_tabla_dinamica(self, df_ingresos, df_gastos, meses):
        # Usa Arial Narrow si está disponible, si no Arial normal.
        html = """
        <style>
        table { width:100%; font-size:14px; font-family:'Arial Narrow', Arial, sans-serif; border-collapse:collapse; margin-top:24px; }
        th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        th { background: #e3eefd; }
        .ingreso { background: #eafdea; }
        .gasto { background: #fbeaea; }
        .net { background: #fff; }
        </style>
        <table>
        <tr><th></th>
        """
        for m in meses:
            html += f"<th>{m}</th>"
        html += "<th>Average</th><th>Total</th></tr>"

        # Ingresos
        html += "<tr class='ingreso'><td><b>Income</b></td>"
        ingresos_mes = []
        for m in meses:
            val = df_ingresos[df_ingresos['mes'] == m]['monto'].sum()
            html += f"<td>{self.moneda}{val:,.2f}</td>"
            ingresos_mes.append(val)
        avg = sum(ingresos_mes) / len(meses) if meses else 0
        total = sum(ingresos_mes)
        html += f"<td>{self.moneda}{avg:,.2f}</td><td>{self.moneda}{total:,.2f}</td></tr>"

        # Gastos por categoría
        cats = sorted(set(df_gastos['categoria'].dropna().tolist()))
        for cat in cats:
            html += f"<tr class='gasto'><td><b>{cat}</b></td>"
            gastos_mes = []
            for m in meses:
                val = df_gastos[(df_gastos['mes'] == m) & (df_gastos['categoria'] == cat)]['monto'].sum()
                html += f"<td>{-val:,.2f}</td>"
                gastos_mes.append(val)
            avg = sum(gastos_mes) / len(meses) if meses else 0
            total = sum(gastos_mes)
            html += f"<td>{-avg:,.2f}</td><td>{-total:,.2f}</td></tr>"
            # Subcategorías
            subcats = sorted(df_gastos[df_gastos['categoria'] == cat]['subcategoria'].dropna().unique())
            for subcat in subcats:
                html += f"<tr><td style='padding-left:24px;'>{subcat}</td>"
                for m in meses:
                    val = df_gastos[(df_gastos['mes'] == m) & (df_gastos['categoria'] == cat) & (df_gastos['subcategoria'] == subcat)]['monto'].sum()
                    html += f"<td>{-val:,.2f}</td>"
                avg = sum([df_gastos[(df_gastos['mes'] == m) & (df_gastos['categoria'] == cat) & (df_gastos['subcategoria'] == subcat)]['monto'].sum() for m in meses]) / len(meses) if meses else 0
                total = sum([df_gastos[(df_gastos['mes'] == m) & (df_gastos['categoria'] == cat) & (df_gastos['subcategoria'] == subcat)]['monto'].sum() for m in meses])
                html += f"<td>{-avg:,.2f}</td><td>{-total:,.2f}</td></tr>"

        # Totales
        html += "<tr class='gasto'><td><b>Total Expenses</b></td>"
        gastos_mes_total = []
        for m in meses:
            val = df_gastos[df_gastos['mes'] == m]['monto'].sum()
            html += f"<td>{-val:,.2f}</td>"
            gastos_mes_total.append(val)
        avg = sum(gastos_mes_total) / len(meses) if meses else 0
        total = sum(gastos_mes_total)
        html += f"<td>{-avg:,.2f}</td><td>{-total:,.2f}</td></tr>"

        # Net Income
        html += "<tr class='net'><td><b>Net Income</b></td>"
        for i, m in enumerate(meses):
            net = ingresos_mes[i] - gastos_mes_total[i]
            html += f"<td>{self.moneda}{net:,.2f}</td>"
        net_avg = sum([ingresos_mes[i] - gastos_mes_total[i] for i in range(len(meses))]) / len(meses) if meses else 0
        net_total = sum([ingresos_mes[i] - gastos_mes_total[i] for i in range(len(meses))])
        html += f"<td>{self.moneda}{net_avg:,.2f}</td><td>{self.moneda}{net_total:,.2f}</td></tr>"
        html += "</table>"
        return html
    
    def exportar_reporte_pdf(self):
        wkhtml_path = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
        if not os.path.exists(wkhtml_path):
            wkhtml_path = r'C:\Program Files\wkhtmltopdf\wkhtmltopdf.exe'
            if not os.path.exists(wkhtml_path):
                QMessageBox.warning(self, "Error", f"No se encontró wkhtmltopdf.exe en {wkhtml_path}")
                return
        config = pdfkit.configuration(wkhtmltopdf=wkhtml_path)

        filename, _ = QFileDialog.getSaveFileName(self, "Guardar reporte PDF", "reporte_ingresos_vs_gastos.pdf", "Archivo PDF (*.pdf)")
        if not filename:
            return

        # Exporta gráfico como imagen base64
        temp_img = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
        self.figura_actual.write_image(temp_img.name, width=1600, height=900)
        temp_img.close()
        with open(temp_img.name, "rb") as f:
            img_data = f.read()
        img_base64 = base64.b64encode(img_data).decode("utf-8")
        img_src = f"data:image/png;base64,{img_base64}"

        # Prepara tabla dinámica
        df_ingresos = self.obtener_ingresos_agrupados()
        df_gastos = self.obtener_gastos_agrupados()
        meses = sorted(set(df_ingresos['mes'].dropna().tolist() + df_gastos['mes'].dropna().tolist()))
        tabla_html = self.generar_tabla_dinamica(df_ingresos, df_gastos, meses)

        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")

        # Estilo global Arial Narrow y tabla ancha
        html = f"""
        <html>
        <head>
        <meta charset="utf-8"/>
        <style>
        body {{ font-family: 'Arial Narrow', Arial, sans-serif; }}
        h1 {{ font-size:24px; }}
        table {{ border: 1px solid #ccc; border-collapse: collapse; width: 100%; margin-top: 24px; font-family: 'Arial Narrow', Arial, sans-serif; }}
        th, td {{ border: 1px solid #ccc; padding: 6px; text-align: left; }}
        th {{ background: #e3eefd; }}
        </style>
        </head>
        <body>
        <h1>Reporte Ingresos vs Gastos</h1>
        <p>Período: {fecha_ini} a {fecha_fin}</p>
        <img src="{img_src}" style="width:100%;max-width:1400px;"/>
        {tabla_html}
        </body>
        </html>
        """

        # Opciones de PDF: horizontal, legal, márgenes ajustados
        options = {
            'page-size': 'Legal',
            'orientation': 'Landscape',
            'encoding': "UTF-8",
            'margin-top': '0.5in',
            'margin-bottom': '0.5in',
            'margin-left': '0.5in',
            'margin-right': '0.5in',
        }

        try:
            pdfkit.from_string(html, filename, configuration=config, options=options)
            QMessageBox.information(self, "Éxito", "PDF exportado correctamente.")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo exportar PDF: {e}")
        finally:
            try:
                os.remove(temp_img.name)
            except Exception:
                pass