from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox, QDateEdit, QFileDialog, QMessageBox, QTreeWidget, QTreeWidgetItem, QSplitter
from PyQt6.QtCore import Qt, QDate
from PyQt6.QtGui import QFont
from PyQt6.QtWebEngineWidgets import QWebEngineView
import pandas as pd
import plotly.express as px
import pdfkit
import os
import os
import pdfkit
from PyQt6.QtWidgets import QFileDialog, QMessageBox


class DashboardGastosAvanzadoWindow(QMainWindow):
    def __init__(self, db_manager, proyecto_actual, moneda, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.proyecto_actual = proyecto_actual
        self.moneda = moneda
        self.setWindowTitle(f"Gastos Avanzados - {proyecto_actual.nombre}")
        self.resize(1400, 800)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.setCentralWidget(splitter)

        # Panel lateral: filtro de cuenta y árbol de categorías/subcategorías
        lateral_widget = QWidget()
        lateral_layout = QVBoxLayout(lateral_widget)
        lateral_layout.addWidget(QLabel("Cuenta:"))
        self.combo_cuentas = QComboBox()
        cuentas = self.db.obtener_cuentas_por_proyecto(self.proyecto_actual.id)
        self.combo_cuentas.addItem("Todas", None)
        for cuenta in cuentas:
            self.combo_cuentas.addItem(cuenta['nombre'], cuenta['id'])
        lateral_layout.addWidget(self.combo_cuentas)

        # Filtro: Categoría/Subcategoría
        lateral_layout.addWidget(QLabel("Filtrar por:"))
        self.combo_filtro_lateral = QComboBox()
        self.combo_filtro_lateral.addItems(["Categoría", "Subcategoría"])
        lateral_layout.addWidget(self.combo_filtro_lateral)

        lateral_layout.addWidget(QLabel("Categorías/Subcategorías:"))
        self.tree_categorias = QTreeWidget()
        self.tree_categorias.setHeaderLabels(["Nombre", "Total"])
        lateral_layout.addWidget(self.tree_categorias, stretch=1)

        self.btn_select_all = QPushButton("Seleccionar Todo")
        self.btn_clear = QPushButton("Limpiar Selección")
        lateral_layout.addWidget(self.btn_select_all)
        lateral_layout.addWidget(self.btn_clear)
        splitter.addWidget(lateral_widget)

        # Panel central: filtros, resumen, gráfico
        central_widget = QWidget()
        central_layout = QVBoxLayout(central_widget)
        filtro_layout = QHBoxLayout()
        filtro_layout.addWidget(QLabel("Desde:"))
        self.date_desde = QDateEdit()
        self.date_desde.setCalendarPopup(True)
        filtro_layout.addWidget(self.date_desde)
        filtro_layout.addWidget(QLabel("Hasta:"))
        self.date_hasta = QDateEdit()
        self.date_hasta.setCalendarPopup(True)
        filtro_layout.addWidget(self.date_hasta)
        filtro_layout.addWidget(QLabel("Tipo de Gráfico:"))
        self.combo_tipo_grafico = QComboBox()
        self.combo_tipo_grafico.addItems(["Donut", "Pastel", "Barra"])
        filtro_layout.addWidget(self.combo_tipo_grafico)
        central_layout.addLayout(filtro_layout)

        # Establecer fechas iniciales según rango de transacciones
        fecha_ini, fecha_fin = self.obtener_rango_fechas_transacciones()
        if fecha_ini:
            self.date_desde.setDate(QDate.fromString(fecha_ini, "yyyy-MM-dd"))
        else:
            self.date_desde.setDate(QDate.currentDate().addMonths(-1))
        if fecha_fin:
            self.date_hasta.setDate(QDate.fromString(fecha_fin, "yyyy-MM-dd"))
        else:
            self.date_hasta.setDate(QDate.currentDate())

        # Resumen total
        self.label_resumen = QLabel("Total Gastado: RD$ 0.00")
        self.label_resumen.setStyleSheet("font-size:18px;font-weight:bold;")
        central_layout.addWidget(self.label_resumen)

        self.web_view = QWebEngineView()
        central_layout.addWidget(self.web_view, stretch=1)

        export_layout = QHBoxLayout()
        self.btn_export_img = QPushButton("Exportar Imagen")
        export_layout.addWidget(self.btn_export_img)
        central_layout.addLayout(export_layout)
        splitter.addWidget(central_widget)
        splitter.setStretchFactor(1, 3)

        self.btn_export_pdf = QPushButton("Exportar PDF")
        export_layout.addWidget(self.btn_export_pdf)
        self.btn_export_pdf.clicked.connect(self.exportar_reporte_pdf)


        # Conexiones: todo reactivo/automático
        self.combo_cuentas.currentIndexChanged.connect(self.cargar_datos_categorias)
        self.combo_filtro_lateral.currentIndexChanged.connect(self.cargar_datos_categorias)
        self.tree_categorias.itemChanged.connect(self.actualizar_dashboard)
        self.date_desde.dateChanged.connect(self.actualizar_dashboard)
        self.date_hasta.dateChanged.connect(self.actualizar_dashboard)
        self.combo_tipo_grafico.currentIndexChanged.connect(self.actualizar_dashboard)
        self.btn_select_all.clicked.connect(self.seleccionar_todo)
        self.btn_clear.clicked.connect(self.limpiar_seleccion)
        self.btn_export_img.clicked.connect(self.exportar_grafico_imagen)

        self.datos_full = None
        self.cargar_datos_categorias()
   # Centra la ventana en la pantalla principal
        self.center_window()

    def center_window(self):
        frame_geom = self.frameGeometry()
        # Para PyQt6: usa QGuiApplication para obtener la pantalla principal
        from PyQt6.QtGui import QGuiApplication
        screen = QGuiApplication.primaryScreen()
        if screen:
            screen_center = screen.availableGeometry().center()
            frame_geom.moveCenter(screen_center)
            self.move(frame_geom.topLeft())




    def obtener_rango_fechas_transacciones(self):
        query = """
            SELECT MIN(fecha) as fecha_min, MAX(fecha) as fecha_max
            FROM transacciones
            WHERE proyecto_id = ? AND tipo = 'Gasto'
        """
        result = self.db.fetch_all(query, [self.proyecto_actual.id])
        if result and result[0]["fecha_min"]:
            return result[0]["fecha_min"], result[0]["fecha_max"]
        else:
            return None, None

    def cargar_datos_categorias(self):
        self.tree_categorias.clear()
        filtro_tipo = self.combo_filtro_lateral.currentText()
        cuenta_id = self.combo_cuentas.currentData()
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")

        font_bold = QFont()
        font_bold.setBold(True)

        if filtro_tipo == "Categoría":
            query = """
                SELECT c.nombre as nombre,
                       SUM(t.monto) as total_gastado
                FROM transacciones t
                JOIN categorias c ON t.categoria_id = c.id
                WHERE t.proyecto_id = ?
                  AND t.tipo = 'Gasto'
                  AND t.fecha BETWEEN ? AND ?
                  {}
                GROUP BY c.nombre
                ORDER BY total_gastado DESC
            """
            filtro_cuenta = ""
            params = [self.proyecto_actual.id, fecha_ini, fecha_fin]
            if cuenta_id:
                filtro_cuenta = "AND t.cuenta_id = ?"
                params.append(cuenta_id)
            query = query.format(filtro_cuenta)
            raw = self.db.fetch_all(query, params)
            self.datos_full = pd.DataFrame(raw)
            if not self.datos_full.empty:
                for _, row in self.datos_full.iterrows():
                    nombre = row["nombre"]
                    total_cat = row["total_gastado"]
                    cat_item = QTreeWidgetItem([str(nombre), f"RD${total_cat:,.2f}"])
                    cat_item.setFont(0, font_bold)  # NEGRITA
                    cat_item.setFlags(cat_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    cat_item.setCheckState(0, Qt.CheckState.Checked)
                    self.tree_categorias.addTopLevelItem(cat_item)
        else:  # Subcategoría
            query = """
                SELECT c.nombre as categoria, s.nombre as nombre, cu.nombre as cuenta,
                       SUM(t.monto) as total_gastado
                FROM transacciones t
                JOIN categorias c ON t.categoria_id = c.id
                JOIN cuentas cu ON t.cuenta_id = cu.id
                LEFT JOIN subcategorias s ON t.subcategoria_id = s.id
                WHERE t.proyecto_id = ?
                  AND t.tipo = 'Gasto'
                  AND t.fecha BETWEEN ? AND ?
                  {}
                GROUP BY cu.nombre, c.nombre, s.nombre
                ORDER BY cu.nombre, c.nombre, s.nombre
            """
            filtro_cuenta = ""
            params = [self.proyecto_actual.id, fecha_ini, fecha_fin]
            if cuenta_id:
                filtro_cuenta = "AND t.cuenta_id = ?"
                params.append(cuenta_id)
            query = query.format(filtro_cuenta)
            raw = self.db.fetch_all(query, params)
            self.datos_full = pd.DataFrame(raw)
            if not self.datos_full.empty:
                categorias = self.datos_full.groupby(["categoria"])
                for cat, cat_group in categorias:
                    # cat puede ser tupla, asegúrate de string limpio
                    nombre_cat = cat if isinstance(cat, str) else cat[0]
                    if isinstance(nombre_cat, tuple):
                        nombre_cat = nombre_cat[0]
                    if isinstance(nombre_cat, str) and nombre_cat.startswith("("):
                        nombre_cat = nombre_cat.replace("('", "").replace("',)", "")
                    total_cat = cat_group["total_gastado"].sum()
                    cat_item = QTreeWidgetItem([str(nombre_cat), f"RD${total_cat:,.2f}"])
                    cat_item.setFont(0, font_bold)  # NEGRITA SOLO CATEGORÍA
                    cat_item.setFlags(cat_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    cat_item.setCheckState(0, Qt.CheckState.Checked)
                    subcats = cat_group[cat_group["nombre"].notnull()]
                    for _, sub_row in subcats.iterrows():
                        subcat = sub_row["nombre"]
                        total_sub = sub_row["total_gastado"]
                        sub_item = QTreeWidgetItem([str(subcat), f"RD${total_sub:,.2f}"])
                        # sub_item normal, NO negrita
                        sub_item.setFlags(sub_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                        sub_item.setCheckState(0, Qt.CheckState.Checked)
                        cat_item.addChild(sub_item)
                    self.tree_categorias.addTopLevelItem(cat_item)
                    cat_item.setExpanded(True)
        self.tree_categorias.itemChanged.connect(self.actualizar_dashboard)
        self.actualizar_dashboard()

    def actualizar_dashboard(self):
        filtro_tipo = self.combo_filtro_lateral.currentText()
        cuenta_id = self.combo_cuentas.currentData()
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        tipo_grafico = self.combo_tipo_grafico.currentText()
        df = self.datos_full if self.datos_full is not None else pd.DataFrame()

        print("[DEBUG] Columnas del DataFrame en actualizar_dashboard:", df.columns.tolist())

        seleccionadas = []
        if filtro_tipo == "Categoría":
            columna_nombre = "nombre" if "nombre" in df.columns else "categoria"
            if df.empty or columna_nombre not in df.columns:
                print("[DEBUG] DataFrame vacío o no tiene la columna esperada:", columna_nombre)
                self.web_view.setHtml("<h2>No hay datos para mostrar</h2>")
                self.label_resumen.setText(f"Total Gastado: RD$ 0.00")
                self.figura_actual = None
                return
            for i in range(self.tree_categorias.topLevelItemCount()):
                cat_item = self.tree_categorias.topLevelItem(i)
                if cat_item.checkState(0) == Qt.CheckState.Checked:
                    seleccionadas.append(cat_item.text(0))
            print("[DEBUG] Categorías seleccionadas para filtrar:", seleccionadas)
            df_filtrado = df[df[columna_nombre].isin(seleccionadas)]
            nombres = columna_nombre
        else:  # Subcategoría
            nombres = "nombre"
            if df.empty or nombres not in df.columns:
                print("[DEBUG] DataFrame vacío o no tiene la columna esperada:", nombres)
                self.web_view.setHtml("<h2>No hay datos para mostrar</h2>")
                self.label_resumen.setText(f"Total Gastado: RD$ 0.00")
                self.figura_actual = None
                return
            seleccionadas_sub = []
            for i in range(self.tree_categorias.topLevelItemCount()):
                cat_item = self.tree_categorias.topLevelItem(i)
                if cat_item.checkState(0) == Qt.CheckState.Checked:
                    seleccionadas_sub.append(cat_item.text(0))
                for j in range(cat_item.childCount()):
                    sub_item = cat_item.child(j)
                    if sub_item.checkState(0) == Qt.CheckState.Checked:
                        seleccionadas_sub.append(sub_item.text(0))
            print("[DEBUG] Subcategorías seleccionadas para filtrar:", seleccionadas_sub)
            df_filtrado = df[df[nombres].isin(seleccionadas_sub)]
        if cuenta_id and "cuenta" in df_filtrado.columns:
            cuenta_nombre = self.combo_cuentas.currentText()
            df_filtrado = df_filtrado[df_filtrado["cuenta"] == cuenta_nombre]

        print("[DEBUG] DataFrame filtrado:")
        print(df_filtrado)

        total = df_filtrado["total_gastado"].sum() if not df_filtrado.empty else 0
        self.label_resumen.setText(f"Total Gastado: RD$ {total:,.2f}")

        # ... (el gráfico sigue igual)

        # Gráfico
        if not df_filtrado.empty:
            if tipo_grafico == "Donut":
                fig = px.pie(df_filtrado, names=nombres, values="total_gastado", hole=0.55,
                             color_discrete_sequence=px.colors.qualitative.Pastel,
                             title=f"Gastos por {'Categoría' if filtro_tipo == 'Categoría' else 'Subcategoría'}<br><sup>{fecha_ini} a {fecha_fin}</sup>")
            elif tipo_grafico == "Pastel":
                fig = px.pie(df_filtrado, names=nombres, values="total_gastado",
                             color_discrete_sequence=px.colors.qualitative.Pastel,
                             title=f"Gastos por {'Categoría' if filtro_tipo == 'Categoría' else 'Subcategoría'}<br><sup>{fecha_ini} a {fecha_fin}</sup>")
            elif tipo_grafico == "Barra":
                fig = px.bar(df_filtrado, x="total_gastado", y=nombres, orientation="h",
                             color=nombres, color_discrete_sequence=px.colors.qualitative.Pastel,
                             title=f"Gastos por {'Categoría' if filtro_tipo == 'Categoría' else 'Subcategoría'}<br><sup>{fecha_ini} a {fecha_fin}</sup>")
            fig.update_layout(margin=dict(l=30, r=30, t=60, b=30), font=dict(size=15))
            fig.update_traces(textposition='inside', texttemplate='%{label}<br>RD$%{value:,.2f}')
            html = fig.to_html(include_plotlyjs='cdn', full_html=False)
            self.web_view.setHtml(html)
            self.figura_actual = fig
        else:
            self.web_view.setHtml("<h2>No hay datos para mostrar</h2>")
            self.figura_actual = None

    def seleccionar_todo(self):
        for i in range(self.tree_categorias.topLevelItemCount()):
            cat_item = self.tree_categorias.topLevelItem(i)
            cat_item.setCheckState(0, Qt.CheckState.Checked)
            for j in range(cat_item.childCount()):
                sub_item = cat_item.child(j)
                sub_item.setCheckState(0, Qt.CheckState.Checked)

    def limpiar_seleccion(self):
        for i in range(self.tree_categorias.topLevelItemCount()):
            cat_item = self.tree_categorias.topLevelItem(i)
            cat_item.setCheckState(0, Qt.CheckState.Unchecked)
            for j in range(cat_item.childCount()):
                sub_item = cat_item.child(j)
                sub_item.setCheckState(0, Qt.CheckState.Unchecked)

    def exportar_grafico_imagen(self):
        if not hasattr(self, 'figura_actual') or self.figura_actual is None: return
        from datetime import datetime
        fecha_str = datetime.now().strftime("%Y-%m-%d")
        nombre_archivo = f"{self.proyecto_actual.nombre}_Dashboard_Gastos_Avanzado_{fecha_str}.png"
        filepath, _ = QFileDialog.getSaveFileName(self, "Guardar Gráfico Como Imagen...", nombre_archivo, "Imagen PNG (*.png)")
        if filepath:
            self.figura_actual.write_image(filepath, width=1200, height=700)
            QMessageBox.information(self, "Éxito", "Gráfico guardado correctamente.", parent=self)

    def obtener_tabla_reporte(self):
        # Consulta para obtener todas las transacciones de Gasto (según filtros)
        cuenta_id = self.combo_cuentas.currentData()
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        filtro_cuenta = ""
        params = [self.proyecto_actual.id, fecha_ini, fecha_fin]
        if cuenta_id:
            filtro_cuenta = "AND t.cuenta_id = ?"
            params.append(cuenta_id)
        query = f"""
            SELECT c.nombre as categoria, s.nombre as subcategoria, t.monto, t.fecha
            FROM transacciones t
            JOIN categorias c ON t.categoria_id = c.id
            LEFT JOIN subcategorias s ON t.subcategoria_id = s.id
            WHERE t.proyecto_id = ?
            AND t.tipo = 'Gasto'
            AND t.fecha BETWEEN ? AND ?
            {filtro_cuenta}
            ORDER BY c.nombre, s.nombre, t.fecha
        """
        raw = self.db.fetch_all(query, params)
        df = pd.DataFrame(raw)
        return df
    
    def mostrar_reporte_dashboard(self):
        # Genera el gráfico HTML
        fig_html = self.figura_actual.to_html(include_plotlyjs='cdn', full_html=False)
        # Genera tabla resumen
        df_reporte = self.obtener_tabla_reporte()
        if not df_reporte.empty:
            # Agrupa por categoría y subcategoría
            df_reporte['categoria'] = df_reporte['categoria'].fillna("")
            df_reporte['subcategoria'] = df_reporte['subcategoria'].fillna("")
            html_tabla = "<table style='width:100%;font-size:14px;border-collapse:collapse;'>"
            html_tabla += "<tr style='background:#e3eefd'><th>Gasto</th><th>Subcategoría</th><th>Monto</th><th>Fecha</th></tr>"
            for _, row in df_reporte.iterrows():
                cat = f"<b>{row['categoria']}</b>" if row['categoria'] else ""
                subcat = row['subcategoria'] if row['subcategoria'] else ""
                monto = f"RD${row['monto']:,.2f}"
                fecha = row['fecha']
                html_tabla += f"<tr><td>{cat}</td><td>{subcat}</td><td>{monto}</td><td>{fecha}</td></tr>"
            html_tabla += "</table>"
        else:
            html_tabla = "<p>No hay datos para mostrar.</p>"
        # Unir gráfico y tabla
        html_final = f"""
        <div style='width:100%;padding:16px;'>
        {fig_html}
        <div style='margin-top:24px'>{html_tabla}</div>
        </div>
        """
        self.web_view.setHtml(html_final)



    def exportar_reporte_pdf(self):
        import tempfile
        import os
        import pdfkit
        import base64
        from PyQt6.QtWidgets import QFileDialog, QMessageBox

        wkhtml_path = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
        if not os.path.exists(wkhtml_path):
            wkhtml_path = r'C:\Program Files\wkhtmltopdf\wkhtmltopdf.exe'
            if not os.path.exists(wkhtml_path):
                QMessageBox.warning(self, "Error", f"No se encontró wkhtmltopdf.exe en {wkhtml_path}")
                return
        config = pdfkit.configuration(wkhtmltopdf=wkhtml_path)

        filename, _ = QFileDialog.getSaveFileName(self, "Guardar reporte PDF", "reporte_gastos.pdf", "Archivo PDF (*.pdf)")
        if not filename:
            return

        if not hasattr(self, 'figura_actual') or self.figura_actual is None:
            QMessageBox.warning(self, "Sin gráfico", "No hay gráfico para exportar.")
            return
        temp_img = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
        self.figura_actual.write_image(temp_img.name, width=1200, height=700)
        temp_img.close()

        # Convertir la imagen a base64
        with open(temp_img.name, "rb") as f:
            img_data = f.read()
        img_base64 = base64.b64encode(img_data).decode("utf-8")
        img_src = f"data:image/png;base64,{img_base64}"

        df_reporte = self.obtener_tabla_reporte()
        # Fechas para encabezado
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")

        # Tabla de detalle
        if not df_reporte.empty:
            df_reporte['categoria'] = df_reporte['categoria'].fillna("")
            df_reporte['subcategoria'] = df_reporte['subcategoria'].fillna("")
            html_tabla = "<table style='width:100%;font-size:14px;border-collapse:collapse;margin-top:24px;'>"
            html_tabla += "<tr style='background:#e3eefd'><th>Gasto</th><th>Subcategoría</th><th>Monto</th><th>Fecha</th></tr>"
            for _, row in df_reporte.iterrows():
                cat = f"<b>{row['categoria']}</b>" if row['categoria'] else ""
                subcat = row['subcategoria'] if row['subcategoria'] else ""
                monto = f"RD${row['monto']:,.2f}"
                fecha = row['fecha']
                html_tabla += f"<tr><td>{cat}</td><td>{subcat}</td><td>{monto}</td><td>{fecha}</td></tr>"
            html_tabla += "</table>"
        else:
            html_tabla = "<p>No hay datos para mostrar.</p>"

        # Tabla de totales por categoría
        if not df_reporte.empty:
            # Asegúrate que la columna de monto sea numérica
            df_reporte['monto'] = pd.to_numeric(df_reporte['monto'], errors='coerce').fillna(0)
            df_totales = df_reporte.groupby('categoria')['monto'].sum().reset_index()
            html_totales = "<table style='width:60%;font-size:14px;border-collapse:collapse;margin-top:18px;'>"
            html_totales += "<tr style='background:#e3eefd'><th>Gasto</th><th>Total</th></tr>"
            for _, row in df_totales.iterrows():
                cat = f"<b>{row['categoria']}</b>" if row['categoria'] else ""
                total = f"RD${row['monto']:,.2f}"
                html_totales += f"<tr><td>{cat}</td><td>{total}</td></tr>"
            # Total general
            total_general = df_totales['monto'].sum()
            html_totales += f"<tr style='background:#e3eefd'><td><b>TOTAL GENERAL</b></td><td><b>RD${total_general:,.2f}</b></td></tr>"
            html_totales += "</table>"
        else:
            html_totales = ""

        html = f"""
        <html>
        <head>
        <meta charset="utf-8"/>
        <style>
        body {{ font-family: Arial, sans-serif; }}
        h1 {{ font-size:24px; }}
        table {{ border: 1px solid #ccc; border-collapse: collapse; width: 100%; margin-top: 24px; }}
        th, td {{ border: 1px solid #ccc; padding: 6px; text-align: left; }}
        th {{ background: #e3eefd; }}
        </style>
        </head>
        <body>
        <h1>Reporte de Gastos por Categoría</h1>
        <p>Gastos por Categoría<br>{fecha_ini} a {fecha_fin}</p>
        <img src="{img_src}" style="width:100%;max-width:800px;"/>
        {html_tabla}
        {html_totales}
        </body>
        </html>
        """

        try:
            pdfkit.from_string(html, filename, configuration=config)
            QMessageBox.information(self, "Éxito", "PDF exportado correctamente.")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo exportar PDF: {e}")
        finally:
            try:
                os.remove(temp_img.name)
            except Exception:
                pass