from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QMenuBar, QMenu, 
    QFileDialog, QMessageBox, QStatusBar, QToolBar, QComboBox
)
from PyQt6.QtGui import QAction
import logging

logger = logging.getLogger(__name__)
from dialogo_proyecto import ProyectoDialog
from logic import DatabaseManager
from config_manager import leer_ruta_db, guardar_ruta_db, get_theme, set_theme
import sys
import os
from transacciones_widget import TransaccionesWidget
from logic import Proyecto
from gestion_categorias_maestras import GestionCategoriasMaestrasDialog
from gastos_categoria_window import GastosPorCategoriaWindow
from gastos_categoria_window import GastosPorCategoriaWindow
from report_generator import ReportGenerator
from resumen_por_cuenta_window import ResumenPorCuentaWindow
from dashboard_gastos_avanzado import DashboardGastosAvanzadoWindow
from dashboard_ingresos_vs_gastos import DashboardIngresosVsGastosWindow
from dashboard_global_cuentas import DashboardGlobalCuentasWindow
from auditoria_categorias import AuditoriaCategoriasDialog
from importar_categorias_dialog import ImportarCategoriasDialog
from importer_window_qt import ImporterWindowQt
from cashflow_window import CashflowWindow
from accounts_window import AccountsWindow

# Diccionario de temas disponibles
TEMAS_DISPONIBLES = {
    "oscuro": "tema.qss",
    "claro": "tema_claro.qss"
}

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # --- Inicia la base de datos con configuración ---
        db_path = leer_ruta_db()
        if not db_path:
            db_path = self.pedir_ruta_db()
        self.db_path = db_path
        guardar_ruta_db(db_path)
        self.db_manager = DatabaseManager(db_path)
        self.db_manager.crear_tablas_iniciales()
                # Define la moneda. Usa el valor que corresponda a tu sistema.
        self.moneda = "RD$"  # O el símbolo que uses para tus reportes
        self.proyecto_actual = None
        self.setWindowTitle("PROGAIN APP - PyQt6")
        self.setGeometry(100, 100, 800, 500)

        # --- Inicia la base de datos con configuración ---
        db_path = leer_ruta_db()
        if not db_path:
            db_path = self.pedir_ruta_db()
        self.db_path = db_path
        guardar_ruta_db(db_path)
        self.db = DatabaseManager(db_path)
        self.db.crear_tablas_iniciales()

        # Widget central con layout principal
        self.main_widget = QWidget()
        self.main_layout = QVBoxLayout(self.main_widget)
        self.setCentralWidget(self.main_widget)

        # Banda superior fija para proyecto/cuenta principal
        self.info_proyecto_label = QLabel("Proyecto: --- | Cuenta principal: ---")
        self.info_proyecto_label.setStyleSheet("font-weight: bold; font-size: 13pt; margin: 6px;")
        self.main_layout.addWidget(self.info_proyecto_label)

        # Widget de información inicial
        self.info_label = QLabel(f"Bienvenido a PROGAIN APP (PyQt6)\nBase de datos: {db_path}")
        self.main_layout.addWidget(self.info_label)

        # Placeholder para el widget dinámico (ejemplo: transacciones)
        self.dynamic_widget = None

        # Menú principal
        self._crear_menus()
        
        # Toolbar con selector de proyecto
        self._crear_toolbar_proyecto()

        # Status bar
        self.setStatusBar(QStatusBar())

    def _crear_menus(self):
        menu_bar = QMenuBar(self)
        self.setMenuBar(menu_bar)
        archivo_menu = QMenu("Archivo", self)
        menu_bar.addMenu(archivo_menu)
        archivo_menu.addAction(QAction("Seleccionar/Crear Proyecto...", self, triggered=self.mostrar_dialogo_seleccion_proyecto))
        archivo_menu.addAction(QAction("Cambiar Base de Datos...", self, triggered=self.cambiar_ruta_db))
        archivo_menu.addSeparator()
        archivo_menu.addAction(QAction("Salir", self, triggered=self.close))
        
        # Menu Ver (temas y ventanas)
        ver_menu = QMenu("Ver", self)
        menu_bar.addMenu(ver_menu)
        ver_menu.addAction(QAction("Ventana de Cuentas...", self, triggered=self.abrir_ventana_cuentas))
        ver_menu.addSeparator()
        tema_submenu = QMenu("Tema", self)
        ver_menu.addMenu(tema_submenu)
        tema_submenu.addAction(QAction("Tema Oscuro", self, triggered=lambda: self._cambiar_tema("oscuro")))
        tema_submenu.addAction(QAction("Tema Claro", self, triggered=lambda: self._cambiar_tema("claro")))
        
        editar_menu = QMenu("Editar", self)
        menu_bar.addMenu(editar_menu)
        editar_menu.addAction(QAction("Gestionar Cuentas Maestras...", self, triggered=self.abrir_gestion_cuentas_maestras))
        editar_menu.addAction(QAction("Gestionar Categorías Maestras...", self, triggered=self.abrir_gestion_categorias_maestras))
        editar_menu.addAction(QAction("Gestionar Categorías del Proyecto...", self, triggered=self.abrir_gestion_categorias_proyecto))
        editar_menu.addAction(QAction("Gestionar Subcategorías del Proyecto...", self, triggered=self.abrir_gestion_subcategorias))
        editar_menu.addAction(QAction("Gestionar Cuentas del Proyecto...", self, triggered=self.abrir_gestion_cuentas_proyecto))
        editar_menu.addSeparator()
        editar_menu.addAction(QAction("Gestionar Presupuestos...", self, triggered=self.abrir_gestion_presupuestos))
        editar_menu.addAction(QAction("Gestionar Presupuestos por Subcategoría...", self, triggered=self.abrir_gestion_presupuestos_subcategorias))
        
        reportes_menu = QMenu("Reportes", self)
        menu_bar.addMenu(reportes_menu)
        reportes_menu.addAction(QAction("Reporte Detallado por Fecha...", self, triggered=self.abrir_reporte_detallado_fecha))
        reportes_menu.addAction(QAction("Reporte Gastos por Categoría...", self, triggered=self.abrir_gastos_categoria))
        reportes_menu.addSeparator()

        # Botón real, enlazado a la función correcta
        reportes_menu.addAction(QAction(
            "Resumen por Cuenta (Proyecto Actual)...",
            self,
            triggered=self.lanzar_resumen_por_cuenta  # <-- aquí el cambio
        ))
        
        reportes_menu.addSeparator()
        reportes_menu.addAction(QAction(
            "Flujo de Caja...",
            self,
            triggered=self.abrir_flujo_de_caja
        ))

     
        dashboards_menu = QMenu("Dashboards", self)
        menu_bar.addMenu(dashboards_menu)

        dashboards_menu.addAction(QAction(
            "Gastos por Categoría...", 
            self, 
            triggered=self.abrir_dashboard_gastos_categoria  # <-- Conecta la función real
        )) 
 
        dashboards_menu.addAction(QAction(
            "Ingresos vs. Gastos...", 
            self, 
            triggered=self.abrir_dashboard_ingresos_vs_gastos  # <-- Nuevo método real
        ))
        dashboards_menu.addSeparator()

        # ... en tu método de creación de menús:
        dashboards_menu.addAction(QAction(
            "Dashboard Global de Cuentas",
            self,
            triggered=self.abrir_dashboard_global_cuentas
        ))

        herramientas_menu = QMenu("Herramientas", self)
        menu_bar.addMenu(herramientas_menu)

        # Auditoría y otros botones existentes...
        herramientas_menu.addAction(QAction(
            "Auditoría de Categorías/Subcategorías Huérfanas...",
            self,
            triggered=self.abrir_auditoria_categorias_proyecto
        ))

        action_importar_categorias = QAction(
            "Importar Categorías/Subcategorías de otro Proyecto...",
            self,
            triggered=self.abrir_importar_categorias_dialog
        )
        herramientas_menu.addAction(action_importar_categorias)

        # --- NUEVO BOTÓN ---
        action_importar_transacciones = QAction(
            "Importar Transacciones desde Archivo...",
            self,
            triggered=self.abrir_ventana_importador
        )
        herramientas_menu.addAction(action_importar_transacciones)

    def _crear_toolbar_proyecto(self):
        """Crea la toolbar con el selector de proyectos."""
        logger.debug("Creando toolbar de proyectos")
        toolbar = QToolBar("Proyecto", self)
        self.addToolBar(toolbar)
        
        # Label para el selector
        lbl_proyecto = QLabel("Proyecto: ")
        toolbar.addWidget(lbl_proyecto)
        
        # ComboBox de proyectos
        self.proyecto_combo = QComboBox()
        self.proyecto_combo.setMinimumWidth(200)
        self.proyecto_combo.setPlaceholderText("Seleccione un proyecto...")
        toolbar.addWidget(self.proyecto_combo)
        
        # Conectar el cambio de proyecto
        self.proyecto_combo.currentIndexChanged.connect(self._on_project_selected)
        
        # Cargar proyectos
        self._load_projects()

    def _load_projects(self):
        """Carga los proyectos desde la base de datos y los agrega al combo."""
        logger.debug("Cargando proyectos desde la base de datos")
        try:
            self.proyecto_combo.blockSignals(True)  # Evitar disparar el evento mientras cargamos
            self.proyecto_combo.clear()
            self.proyecto_combo.addItem("-- Seleccione un proyecto --", None)
            
            proyectos = self.db.obtener_proyectos() or []
            for p in proyectos:
                # Normalizar: puede ser Row de sqlite3 o dict
                if hasattr(p, 'keys'):
                    proyecto_dict = dict(p)
                else:
                    proyecto_dict = p
                
                nombre = proyecto_dict.get('nombre', 'Sin nombre')
                proyecto_id = proyecto_dict.get('id')
                self.proyecto_combo.addItem(nombre, proyecto_id)
                logger.debug(f"Proyecto añadido: {nombre} (ID: {proyecto_id})")
            
            logger.info(f"Se cargaron {len(proyectos)} proyectos")
        except Exception as e:
            logger.error(f"Error al cargar proyectos: {e}")
        finally:
            self.proyecto_combo.blockSignals(False)

    def _on_project_selected(self, index):
        """Manejador cuando el usuario selecciona un proyecto del combo."""
        if index <= 0:  # "-- Seleccione un proyecto --" o ninguno
            return
        
        proyecto_id = self.proyecto_combo.currentData()
        proyecto_nombre = self.proyecto_combo.currentText()
        
        if proyecto_id is None:
            return
        
        logger.info(f"Proyecto seleccionado: {proyecto_nombre} (ID: {proyecto_id})")
        
        try:
            # Cargar el proyecto
            self.proyecto_actual = Proyecto(self.db, proyecto_id)
            self.proyecto_actual.cargar_datos()
            
            # Actualizar título de ventana
            self.setWindowTitle(f"PROGAIN APP - {proyecto_nombre}")
            
            # Actualizar etiqueta de info
            cuenta_principal = getattr(self.proyecto_actual, 'cuenta_principal', '---') or '---'
            self.info_proyecto_label.setText(f"Proyecto: {proyecto_nombre} | Cuenta principal: {cuenta_principal}")
            
            # Recargar el widget de transacciones
            self._set_dynamic_widget(TransaccionesWidget(self.db, proyecto_actual=self.proyecto_actual))
            
            # Actualizar status bar
            self.statusBar().showMessage(f"Proyecto activo: {proyecto_nombre}")
            
            logger.debug(f"Proyecto {proyecto_nombre} cargado exitosamente")
        except Exception as e:
            logger.error(f"Error al seleccionar proyecto: {e}")
            QMessageBox.warning(self, "Error", f"No se pudo cargar el proyecto: {e}")


    def no_implementado(self):
        QMessageBox.information(self, "Función no implementada", "Esta función será migrada próximamente.")

    def _cambiar_tema(self, nombre_tema):
        """Cambia el tema de la aplicación y lo guarda en la configuración.
        
        Args:
            nombre_tema (str): Nombre del tema ('oscuro' o 'claro').
        """
        if nombre_tema not in TEMAS_DISPONIBLES:
            logger.warning(f"Tema '{nombre_tema}' no disponible")
            return
        
        archivo_tema = TEMAS_DISPONIBLES[nombre_tema]
        try:
            if os.path.exists(archivo_tema):
                with open(archivo_tema, "r") as f:
                    QApplication.instance().setStyleSheet(f.read())
                set_theme(nombre_tema)
                logger.info(f"Tema cambiado a: {nombre_tema}")
                self.statusBar().showMessage(f"Tema aplicado: {nombre_tema.capitalize()}")
            else:
                logger.error(f"Archivo de tema no encontrado: {archivo_tema}")
                QMessageBox.warning(self, "Error", f"Archivo de tema no encontrado: {archivo_tema}")
        except Exception as e:
            logger.error(f"Error al cambiar tema: {e}")
            QMessageBox.warning(self, "Error", f"No se pudo aplicar el tema: {e}")

    def pedir_ruta_db(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Selecciona tu archivo de Base de Datos", "progain_database.db", "Archivos DB (*.db);;Todos los archivos (*)")
        if not ruta:
            QMessageBox.warning(self, "Sin base de datos", "No se seleccionó ninguna base de datos. El programa se cerrará.")
            sys.exit()
        return ruta

    def cambiar_ruta_db(self):
        ruta, _ = QFileDialog.getSaveFileName(self, "Selecciona tu archivo de Base de Datos", "progain_database.db", "Archivos DB (*.db);;Todos los archivos (*)")
        if ruta:
            guardar_ruta_db(ruta)
            self.db_path = ruta
            self.db = DatabaseManager(ruta)
            self.db.crear_tablas_iniciales()
            self.info_label.setText(f"Base de datos cambiada a:\n{ruta}")
            self.statusBar().showMessage(f"Base de datos cambiada a: {ruta}")
            self.info_proyecto_label.setText("Proyecto: --- | Cuenta principal: ---")
            self.setWindowTitle("PROGAIN APP - PyQt6")
            # Recargar el combo de proyectos con la nueva base de datos
            self._load_projects()
            logger.info(f"Base de datos cambiada a: {ruta}")

    def mostrar_dialogo_seleccion_proyecto(self):
        proyectos = self.db.obtener_proyectos() or []
        proyectos_existentes = [p['nombre'] for p in proyectos]

        dialogo = ProyectoDialog(proyectos_existentes, self)
        if dialogo.exec():
            resultado = dialogo.resultado
            if resultado:
                accion = resultado[0]
                if accion == "abrir":
                    nombre = resultado[1]
                    proyecto_row = next((p for p in proyectos if p['nombre'] == nombre), None)
                    if proyecto_row:
                        self.proyecto_actual = Proyecto(self.db, proyecto_row['id'])
                        self.proyecto_actual.cargar_datos()
                        cuenta_principal = self.proyecto_actual.cuenta_principal if hasattr(self.proyecto_actual, "cuenta_principal") else "---"
                        self.info_proyecto_label.setText(f"Proyecto: {nombre} | Cuenta principal: {cuenta_principal}")
                        self.setWindowTitle(f"PROGAIN APP - {nombre}")
                        # Cambia el widget dinámico
                        self._set_dynamic_widget(TransaccionesWidget(self.db, proyecto_actual=self.proyecto_actual))
                        self.statusBar().showMessage(f"Proyecto seleccionado: {nombre} | Cuenta principal: {cuenta_principal}")
                        # Sincronizar el combo de proyectos
                        self._sync_proyecto_combo(proyecto_row['id'])
                elif accion == "crear":
                    # Si se creó un nuevo proyecto, recargar la lista
                    self._load_projects()

    def _sync_proyecto_combo(self, proyecto_id):
        """Sincroniza el combo para seleccionar el proyecto por su ID."""
        for i in range(self.proyecto_combo.count()):
            if self.proyecto_combo.itemData(i) == proyecto_id:
                self.proyecto_combo.blockSignals(True)
                self.proyecto_combo.setCurrentIndex(i)
                self.proyecto_combo.blockSignals(False)
                break

    def _set_dynamic_widget(self, widget):
        # Borra el anterior si existe
        if self.dynamic_widget is not None:
            self.main_layout.removeWidget(self.dynamic_widget)
            self.dynamic_widget.deleteLater()
        self.dynamic_widget = widget
        self.main_layout.addWidget(self.dynamic_widget)

    def abrir_gestion_cuentas_maestras(self):
        from gestion_cuentas_maestras import GestionCuentasMaestrasDialog
        dialogo = GestionCuentasMaestrasDialog(self.db, self)
        dialogo.exec()

    def abrir_gestion_cuentas_proyecto(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para gestionar cuentas.")
            return
        from gestion_cuentas_proyecto import GestionCuentasProyectoDialog
        dialogo = GestionCuentasProyectoDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()

    def abrir_gestion_categorias_maestras(self):
        dialogo = GestionCategoriasMaestrasDialog(self.db, self)
        dialogo.exec()

    def abrir_gestion_categorias_proyecto(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para gestionar categorías.")
            return
        from gestion_categorias_proyecto import GestionCategoriasProyectoDialog
        dialogo = GestionCategoriasProyectoDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()

    def abrir_gestion_subcategorias(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para gestionar subcategorías.")
            return
        from gestion_subcategorias_proyecto import GestionSubcategoriasProyectoDialog
        dialogo = GestionSubcategoriasProyectoDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()

    def abrir_gestion_presupuestos(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para gestionar presupuestos.")
            return
        from gestion_presupuestos import GestionPresupuestosDialog
        dialogo = GestionPresupuestosDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()

    def abrir_gestion_presupuestos_subcategorias(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para gestionar presupuestos por subcategoría.")
            return
        from gestion_presupuestos_subcategorias import GestionPresupuestosSubcategoriasDialog
        dialogo = GestionPresupuestosSubcategoriasDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()

    def abrir_reporte_detallado_fecha(self):
        if not self.proyecto_actual:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para ver el reporte.")
            return
        from reporte_detallado_fecha import ReporteDetalladoFechaDialog
        dialogo = ReporteDetalladoFechaDialog(self.db, self.proyecto_actual, self)
        dialogo.exec()


    def obtener_transacciones_actuales(self):
        # Ejemplo: self.db_path y self.proyecto.id definidos en tu clase
        from db_utils import obtener_transacciones_por_proyecto
        transacciones = obtener_transacciones_por_proyecto(self.db_path, self.proyecto.id)
        return transacciones

    def abrir_gastos_categoria(self):
        from gastos_categoria_window import GastosPorCategoriaWindow
        # Asegúrate de tener acceso a self.db, self.proyecto_actual
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Sin proyecto", "Debes seleccionar un proyecto activo primero.")
            return
        # Mantén la referencia para evitar que la ventana se cierre inmediatamente
        self.win_gastos_categoria = GastosPorCategoriaWindow(
            db_manager=self.db,
            proyecto_id=self.proyecto_actual.id,
            proyecto_nombre=self.proyecto_actual.nombre,
            moneda=self.proyecto_actual.moneda
        )
        self.win_gastos_categoria.show()


    def cargar_transacciones_iniciales(self):
        # Solo si tienes self.proyecto_actual
        if self.proyecto_actual:
            datos = self.db.obtener_transacciones_por_proyecto(self.proyecto_actual.id)
            import pandas as pd
            return pd.DataFrame([dict(row) for row in datos])
        else:
            return None

    def lanzar_resumen_por_cuenta(self):
        if not self.proyecto_actual:
            QMessageBox.information(self, "Sin Datos", "Debes seleccionar un proyecto activo.")
            return

        datos_crudos = self.db.resumen_por_cuenta(self.proyecto_actual.id)
        if not datos_crudos:
            QMessageBox.information(self, "Sin Datos", "No hay transacciones en este proyecto para generar el resumen.")
            return

        import pandas as pd
        df = pd.DataFrame([dict(fila) for fila in datos_crudos])
        df['Balance'] = df['total_ingresos'] - df['total_gastos']

        columnas_para_reporte = {
            'cuenta': 'Cuenta',
            'total_ingresos': 'Ingresos',
            'total_gastos': 'Gastos',
            'Balance': 'Balance'
        }

        titulo = f"Resumen por Cuenta - {self.proyecto_actual.nombre}"
        report_obj = ReportGenerator(
            data=df.to_dict('records'),
            title=titulo,
            project_name=self.proyecto_actual.nombre,
            date_range="Total del Proyecto",
            currency_symbol=self.proyecto_actual.moneda,
            column_map=columnas_para_reporte
        )

        # Abre la ventana de resumen moderna
        win = ResumenPorCuentaWindow(
            df=report_obj.df,
            report_obj=report_obj,
            titulo=titulo,
            moneda=self.proyecto_actual.moneda,
            parent=self
        )
        win.show()

    def abrir_flujo_de_caja(self):
        """Abre la ventana de Flujo de Caja para el proyecto actual."""
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Sin Proyecto", "Debes seleccionar un proyecto activo primero.")
            return
        
        # Crear o reutilizar la ventana de flujo de caja
        if not hasattr(self, 'cashflow_window') or self.cashflow_window is None:
            self.cashflow_window = CashflowWindow(self.db, parent=None)
        
        # Establecer el proyecto y período
        self.cashflow_window.set_project(self.proyecto_actual.id, self.proyecto_actual.nombre)
        
        # Establecer período por defecto (desde la primera transacción hasta hoy)
        fecha_primera = self.db.obtener_fecha_primera_transaccion(self.proyecto_actual.id)
        if fecha_primera:
            self.cashflow_window.set_period(fecha_primera, None)
        
        # Actualizar y mostrar
        self.cashflow_window.refresh()
        self.cashflow_window.show()
        self.cashflow_window.raise_()
        self.cashflow_window.activateWindow()
        logger.info(f"Ventana de Flujo de Caja abierta para proyecto: {self.proyecto_actual.nombre}")

    def abrir_ventana_cuentas(self, cuenta_id=None):
        """Abre la Super Ventana de Cuentas para el proyecto actual.
        
        Args:
            cuenta_id: ID de la cuenta a seleccionar (opcional)
        """
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Sin Proyecto", "Debes seleccionar un proyecto activo primero.")
            return
        
        # Crear o reutilizar la ventana de cuentas
        if not hasattr(self, 'accounts_window') or self.accounts_window is None:
            self.accounts_window = AccountsWindow(self.db, parent=None)
        
        # Establecer el proyecto
        self.accounts_window.set_project(self.proyecto_actual.id, self.proyecto_actual.nombre)
        
        # Seleccionar cuenta si se especificó
        if cuenta_id:
            self.accounts_window.select_account(cuenta_id)
        
        # Mostrar ventana
        self.accounts_window.show()
        self.accounts_window.raise_()
        self.accounts_window.activateWindow()
        logger.info(f"Ventana de Cuentas abierta para proyecto: {self.proyecto_actual.nombre}")


    def abrir_dashboard_gastos_categoria(self):
        # Asegúrate de tener acceso a self.db, self.proyecto_actual y su moneda
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Sin Proyecto", "Debes seleccionar un proyecto primero.")
            return
        win = DashboardGastosAvanzadoWindow(
            db_manager=self.db,
            proyecto_actual=self.proyecto_actual,
            moneda=self.proyecto_actual.moneda,
            parent=self
        )
        win.show()

    def abrir_dashboard_ingresos_vs_gastos(self):
        ventana = DashboardIngresosVsGastosWindow(self.db_manager, self.proyecto_actual, self.moneda)
        ventana.show()

    def abrir_dashboard_global_cuentas(self):
        # Si usas self.db_manager como la lógica principal (adaptado de tu estructura)
        ventana = DashboardGlobalCuentasWindow(self.db_manager)
        ventana.show()


    def abrir_auditoria_categorias_proyecto(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "No hay un proyecto activo.")
            return
        # Importa aquí si no lo tienes en la cabecera
        from auditoria_categorias import AuditoriaCategoriasDialog
        dlg = AuditoriaCategoriasDialog(self.db, self.proyecto_actual, self)
        dlg.exec()


    def abrir_importar_categorias_dialog(self):
        # self.db es tu DatabaseManager, self.proyecto_actual es el proyecto destino
        dlg = ImportarCategoriasDialog(self.db, self.proyecto_actual, self, recargar_callback=self._cargar_categorias)
        dlg.exec()
        # Si quieres recargar la vista de categorías/subcategorías después de importar:
        # self._cargar_categorias()   # Se llama en el dialog si recargar_callback se pasa
 
    def _cargar_categorias(self):
        # Ejemplo si usas QListWidget
        if hasattr(self, "mi_widget_categorias") and self.proyecto_actual:
            categorias = self.db.obtener_categorias_por_proyecto(self.proyecto_actual.id)
            self.mi_widget_categorias.clear()
            for cat in categorias:
                self.mi_widget_categorias.addItem(cat['nombre'])

    def abrir_ventana_importador(self):
        if not self.proyecto_actual:
            QMessageBox.warning(self, "Error", "Debes tener un proyecto activo para importar transacciones.", parent=self)
            return

        ventana_importador = ImporterWindowQt(self, self.db, self.proyecto_actual)
        ventana_importador.exec()

        # Refresca la vista de transacciones después de importar
        self.proyecto_actual.cargar_datos()
        self._set_dynamic_widget(TransaccionesWidget(self.db, proyecto_actual=self.proyecto_actual))
        QMessageBox.information(self, "Datos Refrescados", "La vista del proyecto ha sido actualizada.", parent=self)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # --- Cargar tema guardado o el tema por defecto ---
    tema_guardado = get_theme()
    if tema_guardado and tema_guardado in TEMAS_DISPONIBLES:
        archivo_tema = TEMAS_DISPONIBLES[tema_guardado]
    else:
        # Tema por defecto: oscuro
        archivo_tema = "tema.qss"
    
    try:
        if os.path.exists(archivo_tema):
            with open(archivo_tema, "r") as f:
                app.setStyleSheet(f.read())
            logger.info(f"Tema cargado: {archivo_tema}")
        else:
            logger.warning(f"Archivo de tema no encontrado: {archivo_tema}")
    except Exception as e:
        logger.error(f"Error al cargar tema: {e}")

    ventana = MainWindow()
    ventana.show()
    sys.exit(app.exec())