from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QLineEdit, QPushButton,
    QMessageBox, QInputDialog
)

class ProyectoDialog(QDialog):
    def __init__(self, proyectos_existentes, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Seleccionar/Crear Proyecto")
        self.setFixedSize(400, 340)
        self.resultado = None

        layout = QVBoxLayout(self)

        # --- Lista de proyectos ---
        layout.addWidget(QLabel("Proyectos existentes:"))
        self.list_widget = QListWidget()
        self.list_widget.addItems(proyectos_existentes)
        layout.addWidget(self.list_widget)

        # --- Campo para nuevo proyecto ---
        layout.addWidget(QLabel("Crear proyecto nuevo:"))
        self.nuevo_nombre = QLineEdit()
        self.nuevo_nombre.setPlaceholderText("Nombre del nuevo proyecto")
        layout.addWidget(self.nuevo_nombre)

        # --- Botones ---
        btn_layout = QHBoxLayout()
        btn_abrir = QPushButton("Abrir Seleccionado")
        btn_crear = QPushButton("Crear Nuevo")
        btn_eliminar = QPushButton("Eliminar Seleccionado")
        btn_salir = QPushButton("Salir")
        btn_layout.addWidget(btn_abrir)
        btn_layout.addWidget(btn_crear)
        btn_layout.addWidget(btn_eliminar)
        btn_layout.addWidget(btn_salir)
        layout.addLayout(btn_layout)

        # --- Conexiones ---
        btn_abrir.clicked.connect(self.abrir_seleccionado)
        btn_crear.clicked.connect(self.crear_nuevo)
        btn_eliminar.clicked.connect(self.eliminar_seleccionado)
        btn_salir.clicked.connect(self.reject)

    def abrir_seleccionado(self):
        items = self.list_widget.selectedItems()
        if not items:
            QMessageBox.warning(self, "Sin Selección", "Selecciona un proyecto existente.")
            return
        self.resultado = ("abrir", items[0].text())
        self.accept()

    def crear_nuevo(self):
        nombre = self.nuevo_nombre.text().strip()
        if not nombre:
            QMessageBox.warning(self, "Campo vacío", "Debes escribir el nombre del nuevo proyecto.")
            return
        # Opcional: pedir moneda, cuenta principal, etc.
        moneda, ok = QInputDialog.getText(self, "Moneda", "Símbolo de moneda:", text="RD$")
        if not ok or not moneda:
            return
        self.resultado = ("crear", nombre, moneda)
        self.accept()

    def eliminar_seleccionado(self):
        items = self.list_widget.selectedItems()
        if not items:
            QMessageBox.warning(self, "Sin Selección", "Selecciona un proyecto para eliminar.")
            return
        nombre = items[0].text()
        confirm = QMessageBox.question(
            self, "Confirmar Eliminación",
            f"¿Estás seguro de eliminar el proyecto '{nombre}'?\nEsta acción es permanente.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            self.resultado = ("eliminar", nombre)
            self.accept()