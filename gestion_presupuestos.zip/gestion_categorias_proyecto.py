from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QListWidget, QPushButton, QMessageBox, QHBoxLayout, QInputDialog
)

class GestionCategoriasProyectoDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Gestionar Categorías del Proyecto: {proyecto.nombre}")
        self.setFixedSize(400, 540)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Selecciona las categorías que estarán activas en este proyecto:"))

        self.lista_categorias = QListWidget()
        self.lista_categorias.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        layout.addWidget(self.lista_categorias)

        # Botones de gestión
        btn_cat_layout = QHBoxLayout()
        btn_agregar_cat = QPushButton("Agregar")
        btn_editar_cat = QPushButton("Renombrar")
        btn_borrar_cat = QPushButton("Borrar")
        btn_cat_layout.addWidget(btn_agregar_cat)
        btn_cat_layout.addWidget(btn_editar_cat)
        btn_cat_layout.addWidget(btn_borrar_cat)
        layout.addLayout(btn_cat_layout)

        # Botones de guardar/cancelar
        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar Cambios")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        self.seleccion_categoria = set()
        self._cargar_categorias()

        # Conexiones
        btn_guardar.clicked.connect(self._guardar)
        btn_cancelar.clicked.connect(self.reject)
        self.lista_categorias.itemSelectionChanged.connect(self._guardar_seleccion_temporal)
        btn_agregar_cat.clicked.connect(self._agregar_categoria)
        btn_editar_cat.clicked.connect(self._renombrar_categoria)
        btn_borrar_cat.clicked.connect(self._borrar_categoria)

    def _cargar_categorias(self):
        todas = self.db.obtener_categorias() or []
        activas = self.db.obtener_categorias_por_proyecto(self.proyecto.id) or []
        ids_activas = {cat['id'] for cat in activas}
        self.categorias = todas
        self.lista_categorias.clear()
        for cat in todas:
            self.lista_categorias.addItem(cat['nombre'])
        # Seleccionar las activas
        for i in range(self.lista_categorias.count()):
            nombre = self.lista_categorias.item(i).text()
            cat_obj = next((c for c in todas if c['nombre'] == nombre), None)
            if cat_obj and cat_obj['id'] in ids_activas:
                self.lista_categorias.item(i).setSelected(True)
                self.seleccion_categoria.add(cat_obj['id'])  # Inicializa la selección temporal

    def _guardar_seleccion_temporal(self):
        # Guarda la selección temporal actual
        seleccion = set()
        for i in range(self.lista_categorias.count()):
            nombre = self.lista_categorias.item(i).text()
            cat_obj = next((c for c in self.categorias if c['nombre'] == nombre), None)
            if cat_obj and self.lista_categorias.item(i).isSelected():
                seleccion.add(cat_obj['id'])
        self.seleccion_categoria = seleccion

    def _agregar_categoria(self):
        nombre, ok = QInputDialog.getText(self, "Nueva Categoría", "Nombre de la categoría:")
        if ok and nombre.strip():
            self.db.agregar_categoria(nombre.strip())
            self._cargar_categorias()

    def _renombrar_categoria(self):
        sel = self.lista_categorias.currentRow()
        if sel < 0:
            QMessageBox.warning(self, "Sin selección", "Selecciona una categoría para renombrar.")
            return
        cat = self.categorias[sel]
        nuevo_nombre, ok = QInputDialog.getText(self, "Renombrar Categoría", "Nuevo nombre:", text=cat['nombre'])
        if ok and nuevo_nombre.strip():
            self.db.editar_categoria(cat['id'], nuevo_nombre.strip())
            self._cargar_categorias()

    def _borrar_categoria(self):
        sel = self.lista_categorias.currentRow()
        if sel < 0:
            QMessageBox.warning(self, "Sin selección", "Selecciona una categoría para borrar.")
            return
        cat = self.categorias[sel]
        if QMessageBox.question(self, "Confirmar", f"¿Borrar la categoría '{cat['nombre']}'?", 
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.db.eliminar_categoria(cat['id'])
            self._cargar_categorias()

    def _guardar(self):
        # Finaliza la selección antes de guardar
        self._guardar_seleccion_temporal()
        if not self.seleccion_categoria:
            QMessageBox.warning(self, "Error", "Debes seleccionar al menos una categoría para el proyecto.")
            return
        exito = self.db.asignar_categorias_a_proyecto(self.proyecto.id, list(self.seleccion_categoria))
        if exito:
            QMessageBox.information(self, "Guardado", "Categorías del proyecto actualizadas correctamente.")
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "No se pudieron guardar los cambios.")