from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem,
    QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt
from datetime import datetime


class ResumenPorCuentaWindow(QMainWindow):
    def __init__(self, df, report_obj, titulo, moneda, parent=None):
        super().__init__(parent)
        self.setWindowTitle(titulo)
        self.resize(800, 500)
        self.df = df
        self.report_obj = report_obj
        self.moneda = moneda

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        layout.addWidget(QLabel(titulo))

        self.table = QTableWidget()
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)
        layout.addWidget(self.table, stretch=1)

        # Rellenar la tabla
        self.table.setRowCount(len(df))
        for i, row in df.iterrows():
            for j, col in enumerate(df.columns):
                valor = row[col]
                if isinstance(valor, (float, int)) and col != "Cuenta":
                    valor = f"{self.moneda} {valor:,.2f}"
                item = QTableWidgetItem(str(valor))
                item.setTextAlignment(Qt.AlignmentFlag.AlignRight if col in ["Ingresos", "Gastos", "Balance"] else Qt.AlignmentFlag.AlignLeft)
                self.table.setItem(i, j, item)

        export_layout = QHBoxLayout()
        self.btn_pdf = QPushButton("Exportar PDF")
        self.btn_excel = QPushButton("Exportar Excel")
        export_layout.addWidget(self.btn_pdf)
        export_layout.addWidget(self.btn_excel)
        layout.addLayout(export_layout)

        self.btn_pdf.clicked.connect(self.exportar_pdf)
        self.btn_excel.clicked.connect(self.exportar_excel)


    def exportar_pdf(self):
        fecha_actual = datetime.now().strftime("%Y-%m-%d")
        nombre_archivo = f"{self.report_obj.project_name}_Resumen_Cuenta_{fecha_actual}.pdf"
        ruta_archivo, _ = QFileDialog.getSaveFileName(self, "Guardar PDF", nombre_archivo, "Archivos PDF (*.pdf)")
        if not ruta_archivo:
            return
        ok, msg = self.report_obj.to_pdf_resumen_por_cuenta(ruta_archivo)
        if ok:
            QMessageBox.information(self, "Exportación", "Resumen exportado a PDF correctamente.")
        else:
            QMessageBox.warning(self, "Error PDF", f"No se pudo exportar PDF: {msg}")

    def exportar_excel(self):
        fecha_actual = datetime.now().strftime("%Y-%m-%d")
        nombre_archivo = f"{self.report_obj.project_name}_Resumen_Cuenta_{fecha_actual}.xlsx"
        ruta_archivo, _ = QFileDialog.getSaveFileName(self, "Guardar Excel", nombre_archivo, "Archivos Excel (*.xlsx)")
        if not ruta_archivo:
            return
        ok, msg = self.report_obj.to_excel_resumen_por_cuenta(ruta_archivo)
        if ok:
            QMessageBox.information(self, "Exportación", "Resumen exportado a Excel correctamente.")
        else:
            QMessageBox.warning(self, "Error Excel", f"No se pudo exportar Excel: {msg}")