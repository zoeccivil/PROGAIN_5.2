import sqlite3

def ensure_presupuesto_column(db_path):
    conn = sqlite3.connect(db_path)
    try:
        # Verificar columnas existentes
        cur = conn.execute('PRAGMA table_info(proyecto_subcategorias)')
        columnas = [row[1] for row in cur.fetchall()]
        if 'presupuesto' not in columnas:
            print("Agregando columna 'presupuesto' a la tabla 'proyecto_subcategorias'...")
            conn.execute("ALTER TABLE proyecto_subcategorias ADD COLUMN presupuesto REAL DEFAULT 0;")
            conn.commit()
            print("Columna agregada correctamente.")
        else:
            print("La columna 'presupuesto' ya existe en la tabla 'proyecto_subcategorias'.")
    except Exception as e:
        print("Error:", e)
    finally:
        conn.close()

if __name__ == "__main__":
    # Cambia el path si tu base de datos está en otro lugar o con otro nombre
    db_path = "D:/Dropbox/PROGAIN/PROGAIN PyQT6/progain_database-PyQT6.db"
    ensure_presupuesto_column(db_path)