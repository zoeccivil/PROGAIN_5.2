from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QListWidget, QPushButton, QMessageBox, QHBoxLayout, QComboBox, QInputDialog
)

class GestionSubcategoriasProyectoDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Gestionar Subcategorías del Proyecto: {proyecto.nombre}")
        self.setFixedSize(500, 560)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Selecciona la categoría y marca las subcategorías que estarán activas en este proyecto:"))

        self.combo_categoria = QComboBox()
        layout.addWidget(self.combo_categoria)

        self.lista_subcategorias = QListWidget()
        self.lista_subcategorias.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        layout.addWidget(self.lista_subcategorias)

        # Botones de gestión de subcategoría
        btn_sub_layout = QHBoxLayout()
        btn_agregar_sub = QPushButton("Agregar")
        btn_editar_sub = QPushButton("Renombrar")
        btn_borrar_sub = QPushButton("Borrar")
        btn_sub_layout.addWidget(btn_agregar_sub)
        btn_sub_layout.addWidget(btn_editar_sub)
        btn_sub_layout.addWidget(btn_borrar_sub)
        layout.addLayout(btn_sub_layout)

        # Botones de guardar/cancelar
        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar Cambios")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        self.categorias = []
        self.seleccion_por_categoria = {}  # cat_id -> set(subcat_id)
        self.cat_id_actual = None

        self._cargar_categorias()
        self.combo_categoria.currentIndexChanged.connect(self._cambiar_categoria)
        btn_guardar.clicked.connect(self._guardar)
        btn_cancelar.clicked.connect(self.reject)
        btn_agregar_sub.clicked.connect(self._agregar_subcategoria)
        btn_editar_sub.clicked.connect(self._renombrar_subcategoria)
        btn_borrar_sub.clicked.connect(self._borrar_subcategoria)

    def _cargar_categorias(self):
        categorias = self.db.obtener_categorias_por_proyecto(self.proyecto.id) or []
        self.categorias = categorias
        self.combo_categoria.clear()
        for cat in categorias:
            self.combo_categoria.addItem(cat['nombre'], cat['id'])
        if categorias:
            self._cambiar_categoria()

    def _guardar_seleccion_actual(self):
        # Guarda la selección de la categoría actual en el diccionario
        if self.cat_id_actual is not None:
            subcats_actual = self.db.obtener_subcategorias_por_categoria(self.cat_id_actual) or []
            seleccionadas = set()
            for i in range(self.lista_subcategorias.count()):
                nombre = self.lista_subcategorias.item(i).text()
                sub_obj = next((s for s in subcats_actual if s['nombre'] == nombre), None)
                if sub_obj and self.lista_subcategorias.item(i).isSelected():
                    seleccionadas.add(sub_obj['id'])
            self.seleccion_por_categoria[self.cat_id_actual] = seleccionadas

    def _cambiar_categoria(self):
        # Antes de cambiar de categoría, guarda la selección actual
        self._guardar_seleccion_actual()

        idx = self.combo_categoria.currentIndex()
        if idx < 0 or not self.categorias:
            self.lista_subcategorias.clear()
            self.cat_id_actual = None
            return

        cat_id = self.combo_categoria.currentData()
        self.cat_id_actual = cat_id
        subcats = self.db.obtener_subcategorias_por_categoria(cat_id) or []
        self.lista_subcategorias.clear()
        for sub in subcats:
            self.lista_subcategorias.addItem(sub['nombre'])

        # Recupera selección previa si existe
        seleccionadas_ids = self.seleccion_por_categoria.get(cat_id, set())
        for i in range(self.lista_subcategorias.count()):
            nombre = self.lista_subcategorias.item(i).text()
            sub_obj = next((s for s in subcats if s['nombre'] == nombre), None)
            if sub_obj and sub_obj['id'] in seleccionadas_ids:
                self.lista_subcategorias.item(i).setSelected(True)

    def _agregar_subcategoria(self):
        if self.cat_id_actual is None:
            QMessageBox.warning(self, "Sin categoría", "Selecciona una categoría primero.")
            return
        nombre, ok = QInputDialog.getText(self, "Nueva Subcategoría", "Nombre de la subcategoría:")
        if ok and nombre.strip():
            self.db.agregar_subcategoria(nombre.strip(), self.cat_id_actual)
            self._cambiar_categoria()

    def _renombrar_subcategoria(self):
        sel = self.lista_subcategorias.currentRow()
        if sel < 0:
            QMessageBox.warning(self, "Sin selección", "Selecciona una subcategoría para renombrar.")
            return
        subcats = self.db.obtener_subcategorias_por_categoria(self.cat_id_actual) or []
        if sel >= len(subcats):
            return
        sub = subcats[sel]
        nuevo_nombre, ok = QInputDialog.getText(self, "Renombrar Subcategoría", "Nuevo nombre:", text=sub['nombre'])
        if ok and nuevo_nombre.strip():
            self.db.editar_subcategoria(sub['id'], nuevo_nombre.strip())
            self._cambiar_categoria()

    def _borrar_subcategoria(self):
        sel = self.lista_subcategorias.currentRow()
        if sel < 0:
            QMessageBox.warning(self, "Sin selección", "Selecciona una subcategoría para borrar.")
            return
        subcats = self.db.obtener_subcategorias_por_categoria(self.cat_id_actual) or []
        if sel >= len(subcats):
            return
        sub = subcats[sel]
        if QMessageBox.question(self, "Confirmar", f"¿Borrar la subcategoría '{sub['nombre']}'?", 
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.db.eliminar_subcategoria(sub['id'])
            self._cambiar_categoria()

    def _guardar(self):
        # Guarda la selección de la categoría actual antes de guardar
        self._guardar_seleccion_actual()

        todas_seleccionadas_ids = set()
        for cat_id, subcat_ids in self.seleccion_por_categoria.items():
            todas_seleccionadas_ids.update(subcat_ids)

        if not todas_seleccionadas_ids:
            QMessageBox.warning(self, "Error", "Debes seleccionar al menos una subcategoría.")
            return

        exito = self.db.asignar_subcategorias_a_proyecto(self.proyecto.id, list(todas_seleccionadas_ids))
        if exito:
            QMessageBox.information(self, "Guardado", "Subcategorías del proyecto actualizadas correctamente.")
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "No se pudieron guardar los cambios.")