"""
Super Ventana de Cuentas.

Esta ventana muestra todas las cuentas del proyecto y las transacciones
de la cuenta seleccionada, incluyendo transferencias.
"""
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QSplitter, QPushButton,
    QComboBox, QLineEdit, QDateEdit, QFileDialog, QMessageBox, QMenu
)
from PyQt6.QtCore import Qt, QDate, QTimer
from PyQt6.QtGui import QFont, QAction
import logging
import csv

logger = logging.getLogger(__name__)


class AccountsWindow(QMainWindow):
    """Super Ventana de Cuentas - Vista detallada de cuentas y sus transacciones."""
    
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.proyecto_id = None
        self.proyecto_nombre = None
        self.cuenta_seleccionada_id = None
        self.transacciones_crudas = []
        self.transacciones_filtradas = []
        
        # Timer para debounce de búsqueda
        self.search_timer = QTimer()
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._aplicar_filtros)
        
        self.setWindowTitle("Gestión de Cuentas")
        self.setGeometry(100, 100, 1100, 700)
        
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # --- Encabezado ---
        header_layout = QHBoxLayout()
        self.lbl_proyecto = QLabel("Proyecto: ---")
        self.lbl_proyecto.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        header_layout.addWidget(self.lbl_proyecto)
        header_layout.addStretch()
        main_layout.addLayout(header_layout)
        
        # --- Splitter principal ---
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)
        
        # --- Panel izquierdo: Lista de cuentas ---
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        
        left_layout.addWidget(QLabel("Cuentas del Proyecto:"))
        self.lista_cuentas = QListWidget()
        self.lista_cuentas.currentItemChanged.connect(self._on_cuenta_seleccionada)
        left_layout.addWidget(self.lista_cuentas)
        
        # Resumen de cuenta seleccionada
        self.resumen_cuenta_group = QGroupBox("Resumen de Cuenta")
        resumen_layout = QVBoxLayout()
        self.lbl_cuenta_ingresos = QLabel("Ingresos: RD$ 0.00")
        self.lbl_cuenta_gastos = QLabel("Gastos: RD$ 0.00")
        self.lbl_cuenta_balance = QLabel("Balance: RD$ 0.00")
        self.lbl_cuenta_balance.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        resumen_layout.addWidget(self.lbl_cuenta_ingresos)
        resumen_layout.addWidget(self.lbl_cuenta_gastos)
        resumen_layout.addWidget(self.lbl_cuenta_balance)
        self.resumen_cuenta_group.setLayout(resumen_layout)
        left_layout.addWidget(self.resumen_cuenta_group)
        
        splitter.addWidget(left_panel)
        
        # --- Panel derecho: Transacciones de la cuenta ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # Filtros
        filtros_layout = QHBoxLayout()
        filtros_layout.addWidget(QLabel("Desde:"))
        self.fecha_inicio = QDateEdit()
        self.fecha_inicio.setCalendarPopup(True)
        self.fecha_inicio.setDate(QDate.currentDate().addYears(-1))
        self.fecha_inicio.dateChanged.connect(self._on_filtro_cambiado)
        filtros_layout.addWidget(self.fecha_inicio)
        
        filtros_layout.addWidget(QLabel("Hasta:"))
        self.fecha_fin = QDateEdit()
        self.fecha_fin.setCalendarPopup(True)
        self.fecha_fin.setDate(QDate.currentDate())
        self.fecha_fin.dateChanged.connect(self._on_filtro_cambiado)
        filtros_layout.addWidget(self.fecha_fin)
        
        filtros_layout.addWidget(QLabel("Buscar:"))
        self.buscar_edit = QLineEdit()
        self.buscar_edit.setPlaceholderText("Buscar en descripción...")
        self.buscar_edit.textChanged.connect(self._on_buscar_cambiado)
        filtros_layout.addWidget(self.buscar_edit)
        
        self.btn_limpiar = QPushButton("Limpiar")
        self.btn_limpiar.clicked.connect(self._limpiar_filtros)
        filtros_layout.addWidget(self.btn_limpiar)
        
        filtros_layout.addStretch()
        
        self.btn_exportar = QPushButton("Exportar CSV")
        self.btn_exportar.clicked.connect(self._exportar_csv)
        filtros_layout.addWidget(self.btn_exportar)
        
        right_layout.addLayout(filtros_layout)
        
        # Título de transacciones
        self.lbl_transacciones = QLabel("Transacciones de la cuenta:")
        self.lbl_transacciones.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        right_layout.addWidget(self.lbl_transacciones)
        
        # Tabla de transacciones
        self.tabla = QTableWidget(0, 7)
        self.tabla.setHorizontalHeaderLabels([
            "Fecha", "Tipo", "Descripción", "Categoría", "Monto", "Comentario", "Transferencia"
        ])
        header = self.tabla.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        self.tabla.setColumnWidth(0, 100)
        self.tabla.setColumnWidth(1, 90)
        self.tabla.setColumnWidth(2, 200)
        self.tabla.setColumnWidth(3, 120)
        self.tabla.setColumnWidth(4, 100)
        self.tabla.setColumnWidth(5, 150)
        
        # Configurar menú contextual
        self.tabla.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabla.customContextMenuRequested.connect(self._mostrar_menu_contextual)
        self.tabla.doubleClicked.connect(self._on_doble_click)
        
        right_layout.addWidget(self.tabla)
        
        splitter.addWidget(right_panel)
        
        # Proporciones del splitter
        splitter.setSizes([300, 800])
        
        logger.debug("AccountsWindow inicializada")
    
    def set_project(self, project_id, project_name):
        """Establece el proyecto para mostrar las cuentas.
        
        Args:
            project_id: ID del proyecto
            project_name: Nombre del proyecto
        """
        self.proyecto_id = project_id
        self.proyecto_nombre = project_name
        self.setWindowTitle(f"Gestión de Cuentas - {project_name}")
        self.lbl_proyecto.setText(f"Proyecto: {project_name}")
        logger.info(f"Proyecto establecido: {project_name} (ID: {project_id})")
        self._cargar_cuentas()
    
    def select_account(self, cuenta_id):
        """Selecciona una cuenta específica.
        
        Args:
            cuenta_id: ID de la cuenta a seleccionar
        """
        for i in range(self.lista_cuentas.count()):
            item = self.lista_cuentas.item(i)
            if item.data(Qt.ItemDataRole.UserRole) == cuenta_id:
                self.lista_cuentas.setCurrentItem(item)
                break
    
    def refresh(self):
        """Recarga las cuentas y transacciones."""
        self._cargar_cuentas()
        if self.cuenta_seleccionada_id:
            self._cargar_transacciones_cuenta()
    
    def _cargar_cuentas(self):
        """Carga las cuentas del proyecto en la lista."""
        self.lista_cuentas.clear()
        if not self.proyecto_id:
            return
        
        try:
            cuentas = self.db.obtener_cuentas_por_proyecto(self.proyecto_id) or []
            for cuenta in cuentas:
                item = QListWidgetItem(cuenta.get('nombre', 'Sin nombre'))
                item.setData(Qt.ItemDataRole.UserRole, cuenta.get('id'))
                if cuenta.get('is_principal'):
                    item.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
                    item.setText(f"★ {cuenta.get('nombre', 'Sin nombre')}")
                self.lista_cuentas.addItem(item)
            
            logger.debug(f"Se cargaron {len(cuentas)} cuentas")
        except Exception as e:
            logger.error(f"Error al cargar cuentas: {e}")
    
    def _on_cuenta_seleccionada(self, current, previous):
        """Manejador cuando se selecciona una cuenta."""
        if not current:
            return
        
        self.cuenta_seleccionada_id = current.data(Qt.ItemDataRole.UserRole)
        cuenta_nombre = current.text().replace("★ ", "")
        self.lbl_transacciones.setText(f"Transacciones de: {cuenta_nombre}")
        self._cargar_transacciones_cuenta()
    
    def _cargar_transacciones_cuenta(self):
        """Carga las transacciones de la cuenta seleccionada."""
        if not self.cuenta_seleccionada_id or not self.proyecto_id:
            self.tabla.setRowCount(0)
            return
        
        try:
            # Obtener transacciones con filtros de fecha
            filtros = {
                'cuenta_id': self.cuenta_seleccionada_id,
                'fecha_inicio': self.fecha_inicio.date().toString("yyyy-MM-dd"),
                'fecha_fin': self.fecha_fin.date().toString("yyyy-MM-dd")
            }
            self.transacciones_crudas = self.db.obtener_transacciones_por_proyecto(
                self.proyecto_id, filtros
            ) or []
            
            logger.debug(f"Se obtuvieron {len(self.transacciones_crudas)} transacciones")
            self._aplicar_filtros()
        except Exception as e:
            logger.error(f"Error al cargar transacciones: {e}")
    
    def _on_filtro_cambiado(self):
        """Manejador cuando cambia un filtro de fecha."""
        self._cargar_transacciones_cuenta()
    
    def _on_buscar_cambiado(self, text):
        """Manejador para búsqueda con debounce."""
        self.search_timer.start(300)
    
    def _limpiar_filtros(self):
        """Limpia los filtros de búsqueda."""
        self.buscar_edit.clear()
        self.fecha_inicio.setDate(QDate.currentDate().addYears(-1))
        self.fecha_fin.setDate(QDate.currentDate())
        self._cargar_transacciones_cuenta()
    
    def _aplicar_filtros(self):
        """Aplica el filtro de búsqueda a las transacciones."""
        texto_busqueda = self.buscar_edit.text().strip().lower()
        
        if texto_busqueda:
            self.transacciones_filtradas = [
                t for t in self.transacciones_crudas
                if texto_busqueda in str(t.get('descripcion', '')).lower() or
                   texto_busqueda in str(t.get('comentario', '')).lower()
            ]
        else:
            self.transacciones_filtradas = self.transacciones_crudas.copy()
        
        self._mostrar_transacciones()
    
    def _mostrar_transacciones(self):
        """Muestra las transacciones filtradas en la tabla."""
        self.tabla.setRowCount(0)
        ingresos = 0.0
        gastos = 0.0
        
        for fila, t in enumerate(self.transacciones_filtradas):
            self.tabla.insertRow(fila)
            
            # Fecha
            self.tabla.setItem(fila, 0, QTableWidgetItem(str(t.get('fecha', ''))))
            
            # Tipo
            tipo = t.get('tipo', '')
            tipo_item = QTableWidgetItem(tipo)
            if tipo == 'Ingreso':
                tipo_item.setForeground(Qt.GlobalColor.darkGreen)
            elif tipo == 'Gasto':
                tipo_item.setForeground(Qt.GlobalColor.red)
            self.tabla.setItem(fila, 1, tipo_item)
            
            # Descripción
            descripcion = str(t.get('descripcion', ''))
            self.tabla.setItem(fila, 2, QTableWidgetItem(descripcion))
            
            # Categoría
            self.tabla.setItem(fila, 3, QTableWidgetItem(str(t.get('categoria_nombre', ''))))
            
            # Monto
            monto = t.get('monto', 0)
            monto_item = QTableWidgetItem(f"RD$ {monto:,.2f}")
            if tipo == 'Ingreso':
                monto_item.setForeground(Qt.GlobalColor.darkGreen)
                ingresos += monto
            elif tipo == 'Gasto':
                monto_item.setForeground(Qt.GlobalColor.red)
                gastos += monto
            self.tabla.setItem(fila, 4, monto_item)
            
            # Comentario
            self.tabla.setItem(fila, 5, QTableWidgetItem(str(t.get('comentario', ''))))
            
            # Indicador de transferencia
            es_transferencia = 'Transferencia' in descripcion
            if es_transferencia:
                # Intentar extraer información de la cuenta origen/destino
                if 'Transferencia desde' in descripcion:
                    info_transfer = "← Entrada"
                elif 'Transferencia a' in descripcion:
                    info_transfer = "→ Salida"
                else:
                    info_transfer = "↔ Transferencia"
                transfer_item = QTableWidgetItem(info_transfer)
                transfer_item.setForeground(Qt.GlobalColor.blue)
            else:
                transfer_item = QTableWidgetItem("")
            self.tabla.setItem(fila, 6, transfer_item)
        
        # Actualizar resumen
        balance = ingresos - gastos
        self.lbl_cuenta_ingresos.setText(f"Ingresos: RD$ {ingresos:,.2f}")
        self.lbl_cuenta_gastos.setText(f"Gastos: RD$ {gastos:,.2f}")
        self.lbl_cuenta_balance.setText(f"Balance: RD$ {balance:,.2f}")
        
        if balance >= 0:
            self.lbl_cuenta_balance.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.lbl_cuenta_balance.setStyleSheet("color: red; font-weight: bold;")
    
    def _mostrar_menu_contextual(self, pos):
        """Muestra el menú contextual para una transacción."""
        item = self.tabla.itemAt(pos)
        if not item:
            return
        
        fila = item.row()
        if fila < 0 or fila >= len(self.transacciones_filtradas):
            return
        
        menu = QMenu(self)
        
        action_editar = QAction("Editar transacción...", self)
        action_editar.triggered.connect(lambda: self._editar_transaccion(fila))
        menu.addAction(action_editar)
        
        menu.addSeparator()
        
        action_copiar = QAction("Copiar descripción", self)
        action_copiar.triggered.connect(lambda: self._copiar_descripcion(fila))
        menu.addAction(action_copiar)
        
        menu.exec(self.tabla.mapToGlobal(pos))
    
    def _on_doble_click(self, index):
        """Manejador de doble clic para editar transacción."""
        fila = index.row()
        if fila >= 0 and fila < len(self.transacciones_filtradas):
            self._editar_transaccion(fila)
    
    def _editar_transaccion(self, fila):
        """Abre el diálogo de edición de transacción."""
        if fila >= len(self.transacciones_filtradas):
            return
        
        transaccion_dict = self.transacciones_filtradas[fila]
        transaccion_id = transaccion_dict.get('id')
        
        QMessageBox.information(
            self, "Editar Transacción",
            f"Funcionalidad de edición para transacción ID: {transaccion_id}\n"
            f"Descripción: {transaccion_dict.get('descripcion', '')}\n\n"
            "(Esta función se conectará al diálogo de edición existente)"
        )
    
    def _copiar_descripcion(self, fila):
        """Copia la descripción de la transacción al portapapeles."""
        if fila >= len(self.transacciones_filtradas):
            return
        
        from PyQt6.QtWidgets import QApplication
        descripcion = self.transacciones_filtradas[fila].get('descripcion', '')
        QApplication.clipboard().setText(descripcion)
    
    def _exportar_csv(self):
        """Exporta las transacciones de la cuenta a CSV."""
        if not self.transacciones_filtradas:
            QMessageBox.warning(self, "Sin datos", "No hay transacciones para exportar.")
            return
        
        # Obtener nombre de cuenta
        cuenta_nombre = "cuenta"
        current_item = self.lista_cuentas.currentItem()
        if current_item:
            cuenta_nombre = current_item.text().replace("★ ", "").replace(" ", "_")
        
        default_name = f"transacciones_{cuenta_nombre}_{QDate.currentDate().toString('yyyyMMdd')}.csv"
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Exportar Transacciones", default_name, "Archivos CSV (*.csv)"
        )
        
        if not filepath:
            return
        
        try:
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(["Fecha", "Tipo", "Descripción", "Categoría", "Monto", "Comentario"])
                
                for t in self.transacciones_filtradas:
                    writer.writerow([
                        t.get('fecha', ''),
                        t.get('tipo', ''),
                        t.get('descripcion', ''),
                        t.get('categoria_nombre', ''),
                        t.get('monto', 0),
                        t.get('comentario', '')
                    ])
            
            QMessageBox.information(self, "Éxito", f"Transacciones exportadas a:\n{filepath}")
            logger.info(f"Transacciones exportadas a: {filepath}")
        
        except Exception as e:
            logger.error(f"Error al exportar CSV: {e}")
            QMessageBox.warning(self, "Error", f"No se pudo exportar el archivo:\n{e}")
