from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTreeWidget, QTreeWidgetItem,
    QDateEdit, QComboBox, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt, QDate
import pandas as pd

class GastosPorCategoriaWindow(QMainWindow):
    def __init__(self, db_manager, proyecto_id, proyecto_nombre, moneda="RD$", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gastos por Categoría")
        self.resize(900, 600)
        self.db = db_manager
        self.proyecto_id = proyecto_id
        self.proyecto_nombre = proyecto_nombre
        self.moneda = moneda

        # --- Central widget & layout principal ---
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # --- Filtros de fecha y categoría ---
        filtro_layout = QHBoxLayout()
        filtro_layout.addWidget(QLabel("Desde:"))
        self.date_desde = QDateEdit()
        self.date_desde.setCalendarPopup(True)
        self.date_desde.setDate(QDate.currentDate().addMonths(-1))
        filtro_layout.addWidget(self.date_desde)

        self.date_hasta = QDateEdit()
        self.date_hasta.setCalendarPopup(True)
        self.date_hasta.setDate(QDate.currentDate())
        filtro_layout.addWidget(self.date_hasta)
        filtro_layout.addWidget(QLabel("Categoría:"))
        self.combo_categoria = QComboBox()
        filtro_layout.addWidget(self.combo_categoria)
        self.btn_filtrar = QPushButton("Filtrar")
        filtro_layout.addWidget(self.btn_filtrar)
        layout.addLayout(filtro_layout)

        # --- Proyecto ---
        layout.addWidget(QLabel(f"Proyecto: {self.proyecto_nombre}"))

        # --- Árbol de categorías/subcategorías ---
        self.tree = QTreeWidget()
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Categoría / Subcategoría", f"Monto ({self.moneda})"])
        self.tree.setAlternatingRowColors(True)
        layout.addWidget(self.tree, stretch=1)

        # --- Botones de exportación ---
        export_layout = QHBoxLayout()
        self.btn_exportar_excel = QPushButton("Exportar Excel")
        self.btn_exportar_pdf = QPushButton("Exportar PDF")
        export_layout.addWidget(self.btn_exportar_excel)
        export_layout.addWidget(self.btn_exportar_pdf)
        layout.addLayout(export_layout)

        # --- Conexiones ---
        self.btn_filtrar.clicked.connect(self.actualizar_tree)
        self.btn_exportar_excel.clicked.connect(self.exportar_excel)
        self.btn_exportar_pdf.clicked.connect(self.exportar_pdf)

        self._cargar_categorias()
        self.actualizar_tree()

    def _cargar_categorias(self):
        # Llena el ComboBox SOLO con categorías del proyecto
        self.combo_categoria.clear()
        self.combo_categoria.addItem("Todas")
        cats = self.db.obtener_categorias_por_proyecto(self.proyecto_id)
        for c in cats:
            self.combo_categoria.addItem(c["nombre"])

    def actualizar_tree(self):
        fecha_ini = self.date_desde.date().toString("yyyy-MM-dd")
        fecha_fin = self.date_hasta.date().toString("yyyy-MM-dd")
        categoria_filtro = self.combo_categoria.currentText()

        # Obtener solo subcategorías del proyecto
        cats = self.db.obtener_categorias_por_proyecto(self.proyecto_id)
        cats_nombres = set(c['nombre'] for c in cats)
        subcats = self.db.obtener_subcategorias_por_proyecto(self.proyecto_id)
        subcats_map = {}
        for s in subcats:
            subcats_map.setdefault(s['categoria_nombre'], []).append(s['nombre'])

        datos = self.db.obtener_gastos_por_categoria_y_subcategoria(self.proyecto_id, fecha_ini, fecha_fin)
        self.tree.clear()
        if not datos:
            return

        from collections import defaultdict
        cat_map = defaultdict(list)
        for d in datos:
            # Filtrar SOLO las categorías/subcategorías del proyecto
            if not d['categoria'] or d['categoria'] not in cats_nombres:
                continue
            if d['subcategoria'] and d['subcategoria'] not in subcats_map.get(d['categoria'], []):
                continue
            cat_map[d['categoria']].append(d)

        total_general = 0.0
        for cat, subcats in cat_map.items():
            if categoria_filtro != "Todas" and cat != categoria_filtro:
                continue
            total_cat = sum(s['total_gasto'] or 0.0 for s in subcats)
            total_general += total_cat
            cat_item = QTreeWidgetItem([cat, f"{self.moneda} {total_cat:,.2f}"])
            cat_item.setFont(0, self._font_bold())
            for s in subcats:
                sub_item = QTreeWidgetItem([f"   {s['subcategoria']}", f"{self.moneda} {s['total_gasto']:,.2f}"])
                sub_item.setFont(0, self._font_normal())
                cat_item.addChild(sub_item)
            self.tree.addTopLevelItem(cat_item)
        # Total general
        total_item = QTreeWidgetItem(["TOTAL GENERAL", f"{self.moneda} {total_general:,.2f}"])
        total_item.setFont(0, self._font_bold())
        total_item.setFont(1, self._font_bold())
        self.tree.addTopLevelItem(total_item)

    def exportar_excel(self):
        if self.tree.topLevelItemCount() == 0:
            QMessageBox.warning(self, "Sin datos", "No hay datos para exportar.")
            return
        rows = []
        for i in range(self.tree.topLevelItemCount()):
            cat_item = self.tree.topLevelItem(i)
            cat = cat_item.text(0)
            monto_cat = cat_item.text(1)
            if cat == "TOTAL GENERAL":
                rows.append({"Nivel":"Total","Nombre":cat,"Monto":monto_cat})
                continue
            rows.append({"Nivel":"Categoria","Nombre":cat,"Monto":monto_cat})
            for j in range(cat_item.childCount()):
                sub_item = cat_item.child(j)
                rows.append({"Nivel":"Subcategoria","Nombre":sub_item.text(0).strip(),"Monto":sub_item.text(1)})
        df = pd.DataFrame(rows)
        ruta_archivo, _ = QFileDialog.getSaveFileName(self, "Guardar Excel", f"{self.proyecto_nombre}_gastos_categoria.xlsx", "Archivos Excel (*.xlsx)")
        if not ruta_archivo:
            return
        try:
            df.to_excel(ruta_archivo, index=False, sheet_name="Gastos por Categoría")
            QMessageBox.information(self, "Exportación", "Datos exportados a Excel correctamente.")
        except Exception as e:
            QMessageBox.warning(self, "Error Excel", f"No se pudo exportar Excel: {e}")

    def exportar_pdf(self):
        if self.tree.topLevelItemCount() == 0:
            QMessageBox.warning(self, "Sin datos", "No hay datos para exportar.")
            return
        rows = []
        total_general = 0.0
        for i in range(self.tree.topLevelItemCount()):
            cat_item = self.tree.topLevelItem(i)
            cat = cat_item.text(0)
            monto_cat = cat_item.text(1)
            # Salta el "TOTAL GENERAL" en el loop principal
            if cat == "TOTAL GENERAL":
                continue
            # Fila de la categoría (con total)
            monto_cat_val = float(monto_cat.replace("RD$", "").replace(",", ""))
            rows.append({
                "Categoría": cat,
                "Subcategoría": None,
                "Monto": monto_cat_val
            })
            total_general += monto_cat_val
            # Filas de subcategoría (solo si tienen nombre)
            for j in range(cat_item.childCount()):
                sub_item = cat_item.child(j)
                nombre_sub = sub_item.text(0).strip()
                monto_sub = sub_item.text(1)
                if nombre_sub:
                    rows.append({
                        "Categoría": cat,
                        "Subcategoría": nombre_sub,
                        "Monto": float(monto_sub.replace("RD$", "").replace(",", ""))
                    })
        # Al final agrega el total general como fila especial:
        rows.append({
            "Categoría": "TOTAL GENERAL",
            "Subcategoría": None,
            "Monto": total_general
        })
        df = pd.DataFrame(rows)
        ruta_archivo, _ = QFileDialog.getSaveFileName(self, "Guardar PDF", f"{self.proyecto_nombre}_gastos_categoria.pdf", "Archivos PDF (*.pdf)")
        if not ruta_archivo:
            return
        try:
            from report_generator import ReportGenerator
            column_map = {"Categoría": "Categoría", "Subcategoría": "Subcategoría", "Monto": "Monto"}
            date_range = f"{self.date_desde.date().toString('dd/MM/yyyy')} - {self.date_hasta.date().toString('dd/MM/yyyy')}"
            rg = ReportGenerator(
                data=df.to_dict(orient="records"),
                title=f"Gastos por Categoría",
                project_name=self.proyecto_nombre,
                date_range=date_range,
                currency_symbol=self.moneda,
                column_map=column_map
            )
            ok, msg = rg.to_pdf_gastos_por_categoria(ruta_archivo)
            if ok:
                QMessageBox.information(self, "Exportación", "Datos exportados a PDF correctamente.")
            else:
                QMessageBox.warning(self, "Error PDF", f"No se pudo exportar PDF: {msg}")
        except Exception as e:
            QMessageBox.warning(self, "Error PDF", f"No se pudo exportar PDF: {e}")


    def _font_bold(self):
        from PyQt6.QtGui import QFont
        f = QFont()
        f.setBold(True)
        return f

    def _font_normal(self):
        from PyQt6.QtGui import QFont
        return QFont()