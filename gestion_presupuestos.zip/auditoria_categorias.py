from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QLabel, QPushButton,
    QComboBox, QGroupBox, QMessageBox
)

class AuditoriaCategoriasDialog(QDialog):
    def __init__(self, db, proyecto_actual, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto_actual = proyecto_actual
        self.setWindowTitle(f"Auditoría: Reasignar Transacciones Huérfanas en '{proyecto_actual.nombre}'")
        self.resize(1100, 750)

        layout = QVBoxLayout(self)

        # --- Datos ---
        categorias_activas_ids = set(c['id'] for c in self.db.obtener_categorias_por_proyecto(self.proyecto_actual.id) or [])
        subcategorias_activas_ids = set(s['id'] for s in self.db.obtener_subcategorias_por_proyecto(self.proyecto_actual.id) or [])
        todas_trans = self.db.obtener_transacciones_por_proyecto(self.proyecto_actual.id) or []

        # Usar métodos robustos de consulta:
        trans_no_categoria = self.db.obtener_transacciones_sin_categoria_activa(self.proyecto_actual.id)
        trans_no_subcategoria = self.db.obtener_transacciones_sin_subcategoria_activa(self.proyecto_actual.id)

        info_text = f"Se encontraron {len(trans_no_categoria)} transacciones con categoría inactiva y {len(trans_no_subcategoria)} con subcategoría inactiva."
        layout.addWidget(QLabel(info_text))

        # --- Panel de Categoría Inactiva ---
        cat_group = QGroupBox("Transacciones con Categoría Inactiva")
        cat_layout = QVBoxLayout(cat_group)
        self.table_cat = QTableWidget(len(trans_no_categoria), 6)
        self.table_cat.setHorizontalHeaderLabels(["Fecha", "Descripción", "Categoría", "Subcategoría", "Cuenta", "Monto"])
        for i, t in enumerate(trans_no_categoria):
            self.table_cat.setItem(i, 0, QTableWidgetItem(str(t['fecha'])))
            self.table_cat.setItem(i, 1, QTableWidgetItem(str(t['descripcion'])))
            self.table_cat.setItem(i, 2, QTableWidgetItem(str(t['categoria_nombre'])))
            self.table_cat.setItem(i, 3, QTableWidgetItem(str(t.get('subcategoria_nombre', ''))))
            self.table_cat.setItem(i, 4, QTableWidgetItem(str(t['cuenta_nombre'])))
            self.table_cat.setItem(i, 5, QTableWidgetItem(f"{self.proyecto_actual.moneda} {t['monto']:,.2f}"))
        self.table_cat.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        cat_layout.addWidget(self.table_cat)
        layout.addWidget(cat_group)

        # --- Panel de Subcategoría Inactiva ---
        sub_group = QGroupBox("Transacciones con Subcategoría Inactiva")
        sub_layout = QVBoxLayout(sub_group)
        self.table_sub = QTableWidget(len(trans_no_subcategoria), 6)
        self.table_sub.setHorizontalHeaderLabels(["Fecha", "Descripción", "Categoría", "Subcategoría", "Cuenta", "Monto"])
        for i, t in enumerate(trans_no_subcategoria):
            self.table_sub.setItem(i, 0, QTableWidgetItem(str(t['fecha'])))
            self.table_sub.setItem(i, 1, QTableWidgetItem(str(t['descripcion'])))
            self.table_sub.setItem(i, 2, QTableWidgetItem(str(t['categoria_nombre'])))
            self.table_sub.setItem(i, 3, QTableWidgetItem(str(t.get('subcategoria_nombre', ''))))
            self.table_sub.setItem(i, 4, QTableWidgetItem(str(t['cuenta_nombre'])))
            self.table_sub.setItem(i, 5, QTableWidgetItem(f"{self.proyecto_actual.moneda} {t['monto']:,.2f}"))
        self.table_sub.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        sub_layout.addWidget(self.table_sub)
        layout.addWidget(sub_group)

        # --- Panel de reasignación ---
        reasig_group = QGroupBox("Destino de Reasignación")
        reasig_layout = QHBoxLayout(reasig_group)
        reasig_layout.addWidget(QLabel("Nueva Categoría:"))
        self.combo_cat_destino = QComboBox()
        categorias_destino_data = self.db.obtener_categorias_por_proyecto(self.proyecto_actual.id) or []
        self.cat_destino_map = {c['nombre']: c['id'] for c in categorias_destino_data}
        self.combo_cat_destino.addItems(sorted(self.cat_destino_map.keys()))
        reasig_layout.addWidget(self.combo_cat_destino)

        reasig_layout.addWidget(QLabel("Nueva Subcategoría:"))
        self.combo_sub_destino = QComboBox()
        reasig_layout.addWidget(self.combo_sub_destino)
        layout.addWidget(reasig_group)

        def update_subcats():
            cat_nombre = self.combo_cat_destino.currentText()
            cat_id = self.cat_destino_map.get(cat_nombre)
            if not cat_id:
                self.combo_sub_destino.clear()
                return
            subcategorias_data = self.db.obtener_subcategorias_por_categoria(cat_id) or []
            self.combo_sub_destino.clear()
            self.combo_sub_destino.addItems(sorted([s['nombre'] for s in subcategorias_data]))
        self.combo_cat_destino.currentIndexChanged.connect(update_subcats)
        update_subcats()

        # --- Botones de reasignación por selección ---
        btn_layout = QHBoxLayout()
        btn_cat = QPushButton("Reasignar Seleccionados de Categoría")
        btn_sub = QPushButton("Reasignar Seleccionados de Subcategoría")
        btn_layout.addWidget(btn_cat)
        btn_layout.addWidget(btn_sub)
        layout.addLayout(btn_layout)

        # --- Botones de reasignación masiva ---
        btn_masivo_cat = QPushButton("Reasignar TODAS las transacciones de Categoría Inactiva")
        btn_masivo_sub = QPushButton("Reasignar TODAS las transacciones de Subcategoría Inactiva")
        layout.addWidget(btn_masivo_cat)
        layout.addWidget(btn_masivo_sub)

        def reasignar_seleccion(table, tipo):
            selected_rows = table.selectionModel().selectedRows()
            if not selected_rows:
                QMessageBox.warning(self, "Sin Selección", "Por favor, selecciona al menos una transacción.")
                return
            cat_destino_nombre = self.combo_cat_destino.currentText()
            sub_destino_nombre = self.combo_sub_destino.currentText()
            if not cat_destino_nombre or not sub_destino_nombre:
                QMessageBox.warning(self, "Destino Requerido", "Debes seleccionar una nueva categoría y subcategoría de destino.")
                return
            cat_destino_id = self.cat_destino_map.get(cat_destino_nombre)
            sub_destino_id = self.db.obtener_o_crear_id('subcategorias', sub_destino_nombre, 'categoria_id', cat_destino_id)
            seleccionados = []
            for idx in selected_rows:
                row = idx.row()
                trans_id = trans_no_categoria[row]['id'] if tipo == 'cat' else trans_no_subcategoria[row]['id']
                if trans_id:
                    seleccionados.append(trans_id)
            if not seleccionados:
                QMessageBox.warning(self, "Sin Selección", "No se encontraron IDs de transacciones seleccionadas.")
                return
            ok = self.db.reasignar_multiples_transacciones(seleccionados, cat_destino_id, sub_destino_id)
            if ok:
                QMessageBox.information(self, "Éxito", f"{len(seleccionados)} transacciones han sido reasignadas.")
                for idx in reversed(selected_rows):
                    table.removeRow(idx.row())
            else:
                QMessageBox.critical(self, "Error", "Ocurrió un error al reasignar las transacciones.")

        btn_cat.clicked.connect(lambda: reasignar_seleccion(self.table_cat, 'cat'))
        btn_sub.clicked.connect(lambda: reasignar_seleccion(self.table_sub, 'sub'))

        def reasignar_todas_categoria():
            cat_destino_nombre = self.combo_cat_destino.currentText()
            sub_destino_nombre = self.combo_sub_destino.currentText()
            if not cat_destino_nombre or not sub_destino_nombre:
                QMessageBox.warning(self, "Destino Requerido", "Selecciona nueva categoría y subcategoría.")
                return
            categoria_destino_id = self.cat_destino_map.get(cat_destino_nombre)
            subcategoria_destino_id = self.db.obtener_o_crear_id('subcategorias', sub_destino_nombre, 'categoria_id', categoria_destino_id)
            # Reasigna por grupo
            for t in trans_no_categoria:
                self.db.reasignar_transacciones_por_categoria(
                    self.proyecto_actual.id,
                    t['categoria_id'],
                    categoria_destino_id,
                    subcategoria_destino_id
                )
            QMessageBox.information(self, "Éxito", "Todas las transacciones han sido reasignadas.")
            self.table_cat.setRowCount(0)

        def reasignar_todas_subcategoria():
            cat_destino_nombre = self.combo_cat_destino.currentText()
            sub_destino_nombre = self.combo_sub_destino.currentText()
            if not cat_destino_nombre or not sub_destino_nombre:
                QMessageBox.warning(self, "Destino Requerido", "Selecciona nueva categoría y subcategoría.")
                return
            categoria_destino_id = self.cat_destino_map.get(cat_destino_nombre)
            subcategoria_destino_id = self.db.obtener_o_crear_id('subcategorias', sub_destino_nombre, 'categoria_id', categoria_destino_id)
            # Reasigna por grupo
            for t in trans_no_subcategoria:
                self.db.reasignar_transacciones_por_subcategoria(
                    self.proyecto_actual.id,
                    t['subcategoria_id'],
                    categoria_destino_id,
                    subcategoria_destino_id
                )
            QMessageBox.information(self, "Éxito", "Todas las transacciones han sido reasignadas.")
            self.table_sub.setRowCount(0)

        btn_masivo_cat.clicked.connect(reasignar_todas_categoria)
        btn_masivo_sub.clicked.connect(reasignar_todas_subcategoria)

        # --- Botón Cerrar ---
        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.close)
        layout.addWidget(btn_cerrar)

# En tu clase principal, agrega este método:
def abrir_auditoria_categorias_proyecto(self):
    if not self.proyecto_actual:
        QMessageBox.warning(self, "Error", "No hay un proyecto activo.")
        return
    dlg = AuditoriaCategoriasDialog(self.db, self.proyecto_actual, self)
    dlg.exec()