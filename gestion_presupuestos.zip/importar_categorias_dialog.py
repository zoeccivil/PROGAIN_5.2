from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QComboBox, QPushButton, QMessageBox
)

class ImportarCategoriasDialog(QDialog):
    def __init__(self, db, proyecto_actual, parent=None, recargar_callback=None):
        super().__init__(parent)
        self.db = db
        self.proyecto_actual = proyecto_actual
        self.recargar_callback = recargar_callback

        self.setWindowTitle("Importar Categorías/Subcategorías desde otro Proyecto")
        self.resize(500, 200)
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel(f"Proyecto destino: {proyecto_actual.nombre}"))

        # --- Selección de proyecto origen ---
        layout.addWidget(QLabel("Selecciona el Proyecto Origen:"))
        self.combo_origen = QComboBox()
        proyectos = self.db.obtener_proyectos()
        self.proyectos_map = {p['nombre']: p['id'] for p in proyectos if p['id'] != proyecto_actual.id}
        self.combo_origen.addItems(sorted(self.proyectos_map.keys()))
        layout.addWidget(self.combo_origen)

        # --- Botón de importar ---
        self.btn_importar = QPushButton("Importar Categorías y Subcategorías")
        layout.addWidget(self.btn_importar)

        self.btn_importar.clicked.connect(self.importar)

    def importar(self):
        if not self.combo_origen.currentText():
            QMessageBox.warning(self, "Proyecto requerido", "Debes seleccionar un proyecto origen.")
            return

        proyecto_origen_id = self.proyectos_map[self.combo_origen.currentText()]
        proyecto_destino_id = self.proyecto_actual.id

        ok = self.db.importar_categorias_y_subcategorias_de_proyecto(proyecto_origen_id, proyecto_destino_id)
        if ok:
            QMessageBox.information(self, "Éxito", "¡Categorías y subcategorías importadas correctamente!")
            if self.recargar_callback:
                self.recargar_callback()
            self.accept()
        else:
            QMessageBox.critical(self, "Error", "Ocurrió un error al importar. Verifica la base de datos.")

# --- Ejemplo de uso en tu ventana principal (Método) ---
def abrir_importar_categorias_dialog(self):
    # self.db = DatabaseManager, self.proyecto_actual = proyecto destino
    # recargar_callback = método para refrescar la vista de categorías/subcategorías, puede ser self._cargar_categorias
    dlg = ImportarCategoriasDialog(self.db, self.proyecto_actual, self, recargar_callback=self._cargar_categorias)
    dlg.exec()