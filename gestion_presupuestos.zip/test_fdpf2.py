from fpdf import FPDF

def create_test_pdf():
    pdf = FPDF()
    pdf.add_page()

    # Set fill color to blue and text color to white for the header
    pdf.set_fill_color(44, 62, 80)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Arial", "B", 13)
    pdf.cell(100, 10, "ALQUILERES", border=1, align='L', fill=True)
    pdf.cell(50, 10, "RD$ 0.00", border=1, align='R', fill=True)
    pdf.ln()

    # Set fill color to light gray and text color to dark blue for subcategory
    pdf.set_fill_color(236, 240, 241)
    pdf.set_text_color(44, 62, 80)
    pdf.set_font("Arial", "", 11)
    pdf.cell(100, 10, "BOBCAT", border=1, align='L', fill=True)
    pdf.cell(50, 10, "RD$ 0.00", border=1, align='R', fill=True)
    pdf.ln()

    # Set fill color to green and text color to white for total
    pdf.set_fill_color(39, 174, 96)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Arial", "B", 13)
    pdf.cell(100, 10, "TOTAL GENERAL", border=1, align='L', fill=True)
    pdf.cell(50, 10, "RD$ 1,000.00", border=1, align='R', fill=True)
    pdf.ln()

    pdf.output("test_color.pdf")

if __name__ == "__main__":
    create_test_pdf()