from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QLineEdit, QPushButton, QMessageBox, QInputDialog
)

class GestionCuentasMaestrasDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gestionar Cuentas Maestras")
        self.setFixedSize(400, 400)
        self.db = db

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Cuentas maestras:"))
        self.list_widget = QListWidget()
        self._actualizar_lista()
        layout.addWidget(self.list_widget)

        self.nuevo_nombre = QLineEdit()
        self.nuevo_nombre.setPlaceholderText("Nombre de la nueva cuenta")
        layout.addWidget(self.nuevo_nombre)

        btn_layout = QHBoxLayout()
        btn_agregar = QPushButton("Agregar")
        btn_editar = QPushButton("Editar")
        btn_eliminar = QPushButton("Eliminar")
        btn_layout.addWidget(btn_agregar)
        btn_layout.addWidget(btn_editar)
        btn_layout.addWidget(btn_eliminar)
        layout.addLayout(btn_layout)

        btn_agregar.clicked.connect(self.agregar_cuenta)
        btn_editar.clicked.connect(self.editar_cuenta)
        btn_eliminar.clicked.connect(self.eliminar_cuenta)

    def _actualizar_lista(self):
        self.list_widget.clear()
        cuentas = self.db.obtener_cuentas_maestras() or []
        for cuenta in cuentas:
            self.list_widget.addItem(cuenta['nombre'])

    def agregar_cuenta(self):
        nombre = self.nuevo_nombre.text().strip()
        if not nombre:
            QMessageBox.warning(self, "Error", "Debes escribir un nombre.")
            return
        self.db.agregar_cuenta_maestra(nombre)
        self._actualizar_lista()
        self.nuevo_nombre.clear()

    def editar_cuenta(self):
        items = self.list_widget.selectedItems()
        if not items:
            QMessageBox.warning(self, "Error", "Selecciona una cuenta para editar.")
            return
        nombre_actual = items[0].text()
        nuevo_nombre, ok = QInputDialog.getText(self, "Editar cuenta", "Nuevo nombre:", text=nombre_actual)
        if ok and nuevo_nombre.strip():
            self.db.editar_cuenta_maestra(nombre_actual, nuevo_nombre.strip())
            self._actualizar_lista()

    def eliminar_cuenta(self):
        items = self.list_widget.selectedItems()
        if not items:
            QMessageBox.warning(self, "Error", "Selecciona una cuenta para eliminar.")
            return
        nombre = items[0].text()
        confirm = QMessageBox.question(self, "¿Eliminar?", f"¿Seguro que quieres borrar '{nombre}'?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm == QMessageBox.StandardButton.Yes:
            self.db.eliminar_cuenta_maestra(nombre)
            self._actualizar_lista()