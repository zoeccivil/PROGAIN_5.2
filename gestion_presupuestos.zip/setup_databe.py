from PyQt6.QtWidgets import QApplication, QFileDialog, QMessageBox
import sqlite3
import sys

# Definición de las tablas necesarias (sin la columna presupuesto en proyecto_categorias)
TABLAS = {
    "proyectos": """
        CREATE TABLE IF NOT EXISTS proyectos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE,
            cuenta_principal TEXT
        );
    """,
    "cuentas": """
        CREATE TABLE IF NOT EXISTS cuentas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        );
    """,
    "proyecto_cuentas": """
        CREATE TABLE IF NOT EXISTS proyecto_cuentas (
            proyecto_id INTEGER,
            cuenta_id INTEGER,
            is_principal INTEGER DEFAULT 0,
            FOREIGN KEY (proyecto_id) REFERENCES proyectos(id),
            FOREIGN KEY (cuenta_id) REFERENCES cuentas(id)
        );
    """,
    "categorias": """
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        );
    """,
    "subcategorias": """
        CREATE TABLE IF NOT EXISTS subcategorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            categoria_id INTEGER,
            FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        );
    """,
    "proyecto_categorias": """
        CREATE TABLE IF NOT EXISTS proyecto_categorias (
            proyecto_id INTEGER,
            categoria_id INTEGER,
            is_principal INTEGER DEFAULT 0
            -- presupuesto se agrega aparte si falta
        );
    """,
    "proyecto_subcategorias": """
        CREATE TABLE IF NOT EXISTS proyecto_subcategorias (
            proyecto_id INTEGER,
            subcategoria_id INTEGER,
            FOREIGN KEY (proyecto_id) REFERENCES proyectos(id),
            FOREIGN KEY (subcategoria_id) REFERENCES subcategorias(id)
        );
    """,
    "transacciones": """
        CREATE TABLE IF NOT EXISTS transacciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            proyecto_id INTEGER,
            cuenta_id INTEGER,
            categoria_id INTEGER,
            subcategoria_id INTEGER,
            monto REAL,
            tipo TEXT,
            fecha TEXT,
            descripcion TEXT,
            FOREIGN KEY (proyecto_id) REFERENCES proyectos(id),
            FOREIGN KEY (cuenta_id) REFERENCES cuentas(id),
            FOREIGN KEY (categoria_id) REFERENCES categorias(id),
            FOREIGN KEY (subcategoria_id) REFERENCES subcategorias(id)
        );
    """,
    "transferencias": """
        CREATE TABLE IF NOT EXISTS transferencias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            proyecto_id INTEGER,
            cuenta_origen_id INTEGER,
            cuenta_destino_id INTEGER,
            monto REAL,
            fecha TEXT,
            descripcion TEXT,
            FOREIGN KEY (proyecto_id) REFERENCES proyectos(id),
            FOREIGN KEY (cuenta_origen_id) REFERENCES cuentas(id),
            FOREIGN KEY (cuenta_destino_id) REFERENCES cuentas(id)
        );
    """
}

# Columnas requeridas por tabla (solo caso especial presupuesto)
COLUMNAS_REQUERIDAS = {
    "proyecto_categorias": {
        "presupuesto": "ALTER TABLE proyecto_categorias ADD COLUMN presupuesto REAL DEFAULT 0"
    }
}

def crear_tablas_y_columnas(db_path):
    conn = sqlite3.connect(db_path)
    try:
        # Crear tablas si faltan
        for tabla, sql in TABLAS.items():
            conn.execute(sql)
        # Revisar y agregar columnas faltantes
        for tabla, columnas in COLUMNAS_REQUERIDAS.items():
            # Obtener columnas actuales
            cur = conn.execute(f'PRAGMA table_info({tabla})')
            existentes = {row[1] for row in cur.fetchall()}
            for col, alter_sql in columnas.items():
                if col not in existentes:
                    print(f"Agregando columna '{col}' a la tabla '{tabla}'...")
                    conn.execute(alter_sql)
        conn.commit()
        return True, "¡Tablas y columnas verificadas/creadas exitosamente!"
    except Exception as e:
        return False, f"Error: {e}"
    finally:
        conn.close()

def main():
    app = QApplication(sys.argv)
    file_path, _ = QFileDialog.getSaveFileName(
        None,
        "Selecciona o crea el archivo de base de datos",
        "progain_database.db",
        "Archivos DB (*.db);;Todos los archivos (*)"
    )

    if not file_path:
        QMessageBox.critical(None, "Error", "No se seleccionó ningún archivo de base de datos.")
        sys.exit(1)

    ok, msg = crear_tablas_y_columnas(file_path)
    if ok:
        QMessageBox.information(None, "Éxito", msg)
    else:
        QMessageBox.critical(None, "Error", msg)

if __name__ == "__main__":
    main()