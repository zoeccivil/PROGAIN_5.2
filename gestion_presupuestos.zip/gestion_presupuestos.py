from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QPushButton,
    QMessageBox, QHBoxLayout, QHeaderView, QLineEdit
)
from PyQt6.QtCore import Qt

class GestionPresupuestosDialog(QDialog):
    def __init__(self, db, proyecto, parent=None):
        super().__init__(parent)
        self.db = db
        self.proyecto = proyecto
        self.setWindowTitle(f"Gestionar Presupuestos del Proyecto: {proyecto.nombre}")
        self.setFixedSize(700, 600)

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Asigna el presupuesto y observa los gastos por categoría:"))

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels([
            "Categoría", "Presupuesto", "Gastado", "Diferencia", "Observaciones"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)

        # Suma total de presupuesto/gastos
        self.label_totales = QLabel("")
        layout.addWidget(self.label_totales)

        btn_layout = QHBoxLayout()
        btn_guardar = QPushButton("Guardar Cambios")
        btn_cancelar = QPushButton("Cancelar")
        btn_layout.addWidget(btn_guardar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        self._cargar_presupuestos()
        btn_guardar.clicked.connect(self._guardar)
        btn_cancelar.clicked.connect(self.reject)

    def _cargar_presupuestos(self):
        presupuestos = self.db.obtener_presupuestos_por_proyecto(self.proyecto.id) or []

        # Para cada categoría, buscamos gasto actual
        self.table.setRowCount(len(presupuestos))
        total_presupuesto = 0
        total_gasto = 0

        for i, item in enumerate(presupuestos):
            categoria_id = item["categoria_id"]
            nombre = item["categoria_nombre"]
            presupuesto = item.get("presupuesto", 0)

            # Busca el gasto actual en la categoría
            gasto = self.db.obtener_gasto_por_categoria_en_proyecto(self.proyecto.id, categoria_id) if hasattr(self.db, "obtener_gasto_por_categoria_en_proyecto") else 0
            diferencia = presupuesto - gasto

            self.table.setItem(i, 0, QTableWidgetItem(nombre))
            self.table.setItem(i, 1, QTableWidgetItem(str(presupuesto)))
            self.table.setItem(i, 2, QTableWidgetItem(str(gasto)))
            item_dif = QTableWidgetItem(str(diferencia))
            if diferencia < 0:
                item_dif.setForeground(Qt.GlobalColor.red)
            self.table.setItem(i, 3, item_dif)
            self.table.setItem(i, 4, QTableWidgetItem(""))  # Observaciones (editable)

            total_presupuesto += presupuesto
            total_gasto += gasto

        self.label_totales.setText(
            f"Total presupuesto asignado: {total_presupuesto:.2f} | Total gastado: {total_gasto:.2f} | Saldo: {total_presupuesto-total_gasto:.2f}"
        )

        # Permitir editar solo presupuesto y observaciones
        for i in range(self.table.rowCount()):
            self.table.item(i, 1).setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsEditable)
            self.table.item(i, 4).setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsEditable)

    def _guardar(self):
        filas_invalidas = []
        for i in range(self.table.rowCount()):
            categoria_nombre = self.table.item(i, 0).text()
            presupuesto_str = self.table.item(i, 1).text().replace(",", "")
            try:
                presupuesto = float(presupuesto_str)
            except Exception:
                filas_invalidas.append(i+1)
                continue
            categoria_id = None
            # Busca el id por nombre
            for cat in self.db.obtener_presupuestos_por_proyecto(self.proyecto.id):
                if cat["categoria_nombre"] == categoria_nombre:
                    categoria_id = cat["categoria_id"]
                    break
            if categoria_id is not None:
                self.db.actualizar_presupuesto_categoria(self.proyecto.id, categoria_id, presupuesto)
                # Observaciones no guardadas en la BD, puedes agregar si tienes columna

        if filas_invalidas:
            QMessageBox.warning(self, "Error", f"Presupuesto inválido en las filas: {', '.join(map(str, filas_invalidas))}")
            return

        QMessageBox.information(self, "Presupuestos", "Presupuestos actualizados correctamente.")
        self.accept()