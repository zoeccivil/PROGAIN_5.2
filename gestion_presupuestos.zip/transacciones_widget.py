from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QDateEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox, QLineEdit, QMenu, QMessageBox,
    QApplication
)
from PyQt6.QtCore import Qt, QDate, QTimer
from PyQt6.QtGui import QAction
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Nombres de los meses en español
MESES = [
    "Todos", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
]

class TransaccionesWidget(QWidget):
    def __init__(self, db_manager, proyecto_actual=None, parent=None):
        super().__init__(parent)
        self.db = db_manager
        self.proyecto_actual = proyecto_actual
        
        # Lista cruda de transacciones (sin filtrar)
        self.transacciones_crudas = []
        # Lista filtrada para mostrar
        self.transacciones_filtradas = []
        
        # Timer para debounce de búsqueda
        self.search_timer = QTimer()
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self._aplicar_filtros_cliente)

        layout = QVBoxLayout(self)

        # --- Filtros superiores (primera fila) ---
        filtros_layout = QHBoxLayout()
        self.cuenta_filtro = QComboBox()
        self.tipo_filtro = QComboBox()
        self.categoria_filtro = QComboBox()
        self.subcategoria_filtro = QComboBox()
        self.fecha_inicio = QDateEdit()
        self.fecha_fin = QDateEdit()
        self.fecha_inicio.setCalendarPopup(True)
        self.fecha_fin.setCalendarPopup(True)

        # --- Inicializa fechas correctamente: desde la primera transacción ---
        fecha_ini_str = None
        if self.proyecto_actual:
            fecha_ini_str = self.db.obtener_fecha_primera_transaccion(self.proyecto_actual.id)
        if fecha_ini_str:
            año, mes, dia = map(int, fecha_ini_str.split('-'))
            self.fecha_inicio.setDate(QDate(año, mes, dia))
        else:
            self.fecha_inicio.setDate(QDate.currentDate().addMonths(-1))
        self.fecha_fin.setDate(QDate.currentDate())

        filtros_layout.addWidget(QLabel("Cuenta:"))
        filtros_layout.addWidget(self.cuenta_filtro)
        filtros_layout.addWidget(QLabel("Tipo:"))
        filtros_layout.addWidget(self.tipo_filtro)
        filtros_layout.addWidget(QLabel("Categoría:"))
        filtros_layout.addWidget(self.categoria_filtro)
        filtros_layout.addWidget(QLabel("Subcategoría:"))
        filtros_layout.addWidget(self.subcategoria_filtro)
        filtros_layout.addWidget(QLabel("Desde:"))
        filtros_layout.addWidget(self.fecha_inicio)
        filtros_layout.addWidget(QLabel("Hasta:"))
        filtros_layout.addWidget(self.fecha_fin)

        layout.addLayout(filtros_layout)
        
        # --- Filtros secundarios (mes, año, búsqueda) ---
        filtros_secundarios_layout = QHBoxLayout()
        
        # Filtro por mes
        filtros_secundarios_layout.addWidget(QLabel("Mes:"))
        self.mes_filtro = QComboBox()
        self.mes_filtro.addItems(MESES)
        self.mes_filtro.setCurrentIndex(0)  # "Todos"
        filtros_secundarios_layout.addWidget(self.mes_filtro)
        
        # Filtro por año
        filtros_secundarios_layout.addWidget(QLabel("Año:"))
        self.anio_filtro = QComboBox()
        self._cargar_anios_disponibles()
        filtros_secundarios_layout.addWidget(self.anio_filtro)
        
        # Campo de búsqueda dinámica
        filtros_secundarios_layout.addWidget(QLabel("Buscar:"))
        self.buscar_edit = QLineEdit()
        self.buscar_edit.setPlaceholderText("Buscar en descripción o comentario...")
        self.buscar_edit.setMinimumWidth(200)
        filtros_secundarios_layout.addWidget(self.buscar_edit)
        
        # Botón limpiar filtros
        self.btn_limpiar_filtros = QPushButton("Limpiar Filtros")
        filtros_secundarios_layout.addWidget(self.btn_limpiar_filtros)
        
        filtros_secundarios_layout.addStretch()
        
        layout.addLayout(filtros_secundarios_layout)

        # --- Botones de acción ---
        botones_layout = QHBoxLayout()
        self.btn_anadir = QPushButton("Añadir Transacción")
        self.btn_editar = QPushButton("Editar Seleccionada")
        self.btn_eliminar = QPushButton("Eliminar Seleccionada")
        self.btn_transferir = QPushButton("Transferencia")
        botones_layout.addWidget(self.btn_anadir)
        botones_layout.addWidget(self.btn_editar)
        botones_layout.addWidget(self.btn_eliminar)
        botones_layout.addWidget(self.btn_transferir)
        layout.addLayout(botones_layout)

        # --- Tabla de transacciones ---
        self.tabla = QTableWidget(0, 8)
        self.tabla.setHorizontalHeaderLabels([
            "Cuenta", "Tipo", "Categoría", "Subcategoría", "Descripción",
            "Monto", "Fecha", "Comentario"
        ])

        # --- Configuración avanzada de columnas ---
        header = self.tabla.horizontalHeader()
        # Anchos iniciales personalizados
        column_widths = [120, 90, 110, 110, 240, 90, 110, 180]
        for i, ancho in enumerate(column_widths):
            self.tabla.setColumnWidth(i, ancho)
        # Permitir mover y redimensionar columnas
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        header.setSectionsMovable(True)
        
        # Configurar menú contextual y doble clic
        self.tabla.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tabla.customContextMenuRequested.connect(self._mostrar_menu_contextual)
        self.tabla.doubleClicked.connect(self._on_doble_click)

        layout.addWidget(self.tabla)

        # --- Resumen inferior ---
        resumen_group = QGroupBox("Resumen")
        resumen_layout = QHBoxLayout()
        self.lbl_ingresos = QLabel("Ingresos: RD$ 0.00")
        self.lbl_gastos = QLabel("Gastos: RD$ 0.00")
        self.lbl_balance = QLabel("Balance: RD$ 0.00")
        resumen_layout.addWidget(self.lbl_ingresos)
        resumen_layout.addWidget(self.lbl_gastos)
        resumen_layout.addWidget(self.lbl_balance)
        resumen_group.setLayout(resumen_layout)
        layout.addWidget(resumen_group)

        # --- Inicialización de filtros y datos ---
        self._actualizar_filtros()
        self._actualizar_tabla()

        # --- Conexiones de botones y filtros ---
        self.btn_anadir.clicked.connect(self.abrir_dialogo_anadir)
        self.btn_editar.clicked.connect(self.abrir_dialogo_editar)
        self.btn_eliminar.clicked.connect(self.eliminar_transaccion_seleccionada)
        self.btn_transferir.clicked.connect(self.abrir_dialogo_transferencia)
        self.cuenta_filtro.currentIndexChanged.connect(self._actualizar_tabla)
        self.tipo_filtro.currentIndexChanged.connect(self._actualizar_tabla)
        self.categoria_filtro.currentIndexChanged.connect(self._actualizar_tabla)
        self.subcategoria_filtro.currentIndexChanged.connect(self._actualizar_tabla)
        self.fecha_inicio.dateChanged.connect(self._actualizar_tabla)
        self.fecha_fin.dateChanged.connect(self._actualizar_tabla)
        
        # Conexiones para filtros secundarios (mes, año, búsqueda)
        self.mes_filtro.currentIndexChanged.connect(self._aplicar_filtros_cliente)
        self.anio_filtro.currentIndexChanged.connect(self._aplicar_filtros_cliente)
        self.buscar_edit.textChanged.connect(self._on_buscar_text_changed)
        self.btn_limpiar_filtros.clicked.connect(self._limpiar_filtros)

    def _cargar_anios_disponibles(self):
        """Carga los años disponibles basándose en las transacciones."""
        self.anio_filtro.clear()
        self.anio_filtro.addItem("Todos")
        
        # Obtener años desde las transacciones o usar un rango por defecto
        if self.proyecto_actual:
            try:
                transacciones = self.db.obtener_transacciones_por_proyecto(self.proyecto_actual.id) or []
                anios = set()
                for t in transacciones:
                    if t.get('fecha'):
                        fecha_str = str(t['fecha'])
                        if '-' in fecha_str:
                            anio = int(fecha_str.split('-')[0])
                            anios.add(anio)
                
                for anio in sorted(anios, reverse=True):
                    self.anio_filtro.addItem(str(anio))
            except Exception as e:
                logger.error(f"Error al cargar años disponibles: {e}")
        
        # Si no hay años, agregar el año actual
        if self.anio_filtro.count() == 1:
            self.anio_filtro.addItem(str(datetime.now().year))

    def _on_buscar_text_changed(self, text):
        """Manejador con debounce para la búsqueda dinámica."""
        # Reiniciar el timer para debounce (300ms)
        self.search_timer.start(300)

    def _limpiar_filtros(self):
        """Limpia todos los filtros secundarios."""
        self.mes_filtro.setCurrentIndex(0)  # "Todos"
        self.anio_filtro.setCurrentIndex(0)  # "Todos"
        self.buscar_edit.clear()
        self._aplicar_filtros_cliente()

    def _actualizar_filtros(self):
        # Cuenta
        self.cuenta_filtro.clear()
        cuentas = self.db.obtener_cuentas_por_proyecto(self.proyecto_actual.id) if self.proyecto_actual else []
        self.cuentas_map = {"Todas": None}
        self.cuenta_filtro.addItem("Todas")
        for c in cuentas:
            self.cuentas_map[c['nombre']] = c['id']
            self.cuenta_filtro.addItem(c['nombre'])

        # Tipo
        self.tipo_filtro.clear()
        self.tipo_filtro.addItems(["Todos", "Ingreso", "Gasto", "Transferencia"])

        # Categoría
        self.categoria_filtro.clear()
        categorias = self.db.obtener_categorias_por_proyecto(self.proyecto_actual.id) if self.proyecto_actual else []
        self.categorias_map = {"Todas": None}
        self.categoria_filtro.addItem("Todas")
        for cat in categorias:
            self.categorias_map[cat['nombre']] = cat['id']
            self.categoria_filtro.addItem(cat['nombre'])

        # Subcategoría
        self.subcategoria_filtro.clear()
        subcats = self.db.obtener_subcategorias_por_proyecto(self.proyecto_actual.id) if self.proyecto_actual else []
        self.subcategorias_map = {"Todas": None}
        self.subcategoria_filtro.addItem("Todas")
        for s in subcats:
            self.subcategorias_map[s['nombre']] = s['id']
            self.subcategoria_filtro.addItem(s['nombre'])

    def _actualizar_tabla(self):
        """Obtiene las transacciones de la BD y aplica los filtros cliente."""
        if not self.proyecto_actual:
            self.tabla.setRowCount(0)
            return

        # --- Leer filtros seleccionados (para consulta a BD) ---
        filtros = {}
        cuenta_nombre = self.cuenta_filtro.currentText()
        if cuenta_nombre != "Todas":
            filtros['cuenta_id'] = self.cuentas_map[cuenta_nombre]

        tipo = self.tipo_filtro.currentText()
        if tipo != "Todos":
            filtros['tipo'] = tipo

        categoria_nombre = self.categoria_filtro.currentText()
        if categoria_nombre != "Todas":
            filtros['categoria_id'] = self.categorias_map[categoria_nombre]

        subcat_nombre = self.subcategoria_filtro.currentText()
        if subcat_nombre != "Todas":
            filtros['subcategoria_id'] = self.subcategorias_map[subcat_nombre]

        fecha_inicio = self.fecha_inicio.date().toString("yyyy-MM-dd")
        fecha_fin = self.fecha_fin.date().toString("yyyy-MM-dd")
        filtros['fecha_inicio'] = fecha_inicio
        filtros['fecha_fin'] = fecha_fin

        # --- Consultar transacciones filtradas desde la BD ---
        self.transacciones_crudas = self.db.obtener_transacciones_por_proyecto(self.proyecto_actual.id, filtros) or []
        
        # Actualizar años disponibles si es necesario
        self._cargar_anios_disponibles()
        
        # Aplicar filtros cliente (mes, año, búsqueda)
        self._aplicar_filtros_cliente()

    def _aplicar_filtros_cliente(self):
        """Aplica los filtros de mes, año y búsqueda en memoria."""
        if not self.proyecto_actual:
            return
        
        # Obtener valores de filtros secundarios
        mes_seleccionado = self.mes_filtro.currentIndex()  # 0 = Todos, 1 = Enero, etc.
        anio_seleccionado = self.anio_filtro.currentText()
        texto_busqueda = self.buscar_edit.text().strip().lower()
        
        # Filtrar transacciones
        self.transacciones_filtradas = []
        for t in self.transacciones_crudas:
            fecha_str = str(t.get('fecha', ''))
            
            # Filtrar por mes
            if mes_seleccionado > 0 and fecha_str:
                try:
                    partes = fecha_str.split('-')
                    if len(partes) >= 2:
                        mes_transaccion = int(partes[1])
                        if mes_transaccion != mes_seleccionado:
                            continue
                except (ValueError, IndexError):
                    pass
            
            # Filtrar por año
            if anio_seleccionado != "Todos" and fecha_str:
                try:
                    anio_transaccion = fecha_str.split('-')[0]
                    if anio_transaccion != anio_seleccionado:
                        continue
                except (IndexError):
                    pass
            
            # Filtrar por texto de búsqueda (descripción o comentario)
            if texto_busqueda:
                descripcion = str(t.get('descripcion', '')).lower()
                comentario = str(t.get('comentario', '')).lower()
                if texto_busqueda not in descripcion and texto_busqueda not in comentario:
                    continue
            
            self.transacciones_filtradas.append(t)
        
        # Actualizar la tabla con las transacciones filtradas
        self._mostrar_transacciones(self.transacciones_filtradas)

    def _mostrar_transacciones(self, transacciones):
        """Muestra las transacciones en la tabla y calcula los totales."""
        self.tabla.setRowCount(0)
        ingresos = gastos = 0
        
        for fila, t in enumerate(transacciones):
            self.tabla.insertRow(fila)
            self.tabla.setItem(fila, 0, QTableWidgetItem(str(t['cuenta_nombre'])))
            self.tabla.setItem(fila, 1, QTableWidgetItem(str(t['tipo'])))
            self.tabla.setItem(fila, 2, QTableWidgetItem(str(t['categoria_nombre'])))
            self.tabla.setItem(fila, 3, QTableWidgetItem(str(t.get('subcategoria_nombre', ""))))
            self.tabla.setItem(fila, 4, QTableWidgetItem(str(t['descripcion'])))
            self.tabla.setItem(fila, 5, QTableWidgetItem(f"RD$ {t['monto']:,.2f}"))
            self.tabla.setItem(fila, 6, QTableWidgetItem(str(t['fecha'])))
            self.tabla.setItem(fila, 7, QTableWidgetItem(str(t.get('comentario', ""))))
            
            # Calcular totales
            if t['tipo'] == "Ingreso":
                ingresos += t['monto']
            elif t['tipo'] == "Gasto":
                gastos += t['monto']
        
        balance = ingresos - gastos
        self.lbl_ingresos.setText(f"Ingresos: RD$ {ingresos:,.2f}")
        self.lbl_gastos.setText(f"Gastos: RD$ {gastos:,.2f}")
        self.lbl_balance.setText(f"Balance: RD$ {balance:,.2f}")
        
        logger.debug(f"Mostrando {len(transacciones)} transacciones")

    def no_implementado(self):
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.information(self, "Función no implementada", "Esta función será migrada próximamente.")

    def abrir_dialogo_anadir(self):
        # Obtén los nombres de cuentas y categorías para los combos
        cuentas = [c['nombre'] for c in self.db.obtener_cuentas() or []]
        categorias = [c['nombre'] for c in self.db.obtener_categorias() or []]
        from dialogo_transaccion import DialogoTransaccion
        dialogo = DialogoTransaccion(self.db, self.proyecto_actual, cuentas, categorias, self)
        if dialogo.exec():
            self.proyecto_actual.cargar_datos()
            self._actualizar_tabla()

    def abrir_dialogo_editar(self):
        fila = self.tabla.currentRow()
        if fila < 0:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Sin selección", "Selecciona una transacción para editar.")
            return
        
        # Obtener la transacción de la lista filtrada
        if fila >= len(self.transacciones_filtradas):
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "No se pudo encontrar la transacción.")
            return
        
        transaccion_dict = self.transacciones_filtradas[fila]
        transaccion_id = transaccion_dict.get('id')
        
        # Buscar el objeto Transaccion correspondiente
        transaccion = None
        for t in (self.proyecto_actual.transacciones or []):
            if t.id == transaccion_id:
                transaccion = t
                break
        
        if not transaccion:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "No se pudo encontrar la transacción.")
            return
        
        cuentas = [c['nombre'] for c in self.db.obtener_cuentas() or []]
        categorias = [c['nombre'] for c in self.db.obtener_categorias() or []]
        from dialogo_transaccion import DialogoTransaccion
        dialogo = DialogoTransaccion(self.db, self.proyecto_actual, cuentas, categorias, self, transaccion=transaccion)
        if dialogo.exec():
            self.proyecto_actual.cargar_datos()
            self._actualizar_tabla()

    def eliminar_transaccion_seleccionada(self):
        fila = self.tabla.currentRow()
        if fila < 0:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Sin selección", "Selecciona una transacción para eliminar.")
            return
        
        # Obtener la transacción de la lista filtrada
        if fila >= len(self.transacciones_filtradas):
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Error", "No se pudo encontrar la transacción.")
            return
        
        transaccion_dict = self.transacciones_filtradas[fila]
        transaccion_id = transaccion_dict.get('id')
        descripcion = transaccion_dict.get('descripcion', '')
        
        from PyQt6.QtWidgets import QMessageBox
        confirm = QMessageBox.question(
            self,
            "Confirmar eliminación",
            f"¿Estás seguro de eliminar esta transacción?\n\n{descripcion}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm == QMessageBox.StandardButton.Yes:
            exito = self.proyecto_actual.eliminar_transaccion(transaccion_id)
            if exito:
                self.proyecto_actual.cargar_datos()
                self._actualizar_tabla()
                QMessageBox.information(self, "Eliminado", "Transacción eliminada correctamente.")
            else:
                QMessageBox.warning(self, "Error", "No se pudo eliminar la transacción.")

    def abrir_dialogo_transferencia(self):
        cuentas = [c['nombre'] for c in self.db.obtener_cuentas() or []]
        from dialogo_transferencia import DialogoTransferencia
        dialogo = DialogoTransferencia(self.db, self.proyecto_actual, cuentas, self)
        if dialogo.exec():
            self.proyecto_actual.cargar_datos()
            self._actualizar_tabla()

    def _on_doble_click(self, index):
        """Manejador de doble clic para editar transacción."""
        fila = index.row()
        if fila >= 0 and fila < len(self.transacciones_filtradas):
            self.abrir_dialogo_editar()

    def _mostrar_menu_contextual(self, pos):
        """Muestra el menú contextual para una transacción."""
        item = self.tabla.itemAt(pos)
        if not item:
            return
        
        fila = item.row()
        if fila < 0 or fila >= len(self.transacciones_filtradas):
            return
        
        # Seleccionar la fila
        self.tabla.selectRow(fila)
        
        menu = QMenu(self)
        
        # Opción de editar
        action_editar = QAction("Editar transacción...", self)
        action_editar.triggered.connect(self.abrir_dialogo_editar)
        menu.addAction(action_editar)
        
        # Separador
        menu.addSeparator()
        
        # Opción de eliminar
        action_eliminar = QAction("Eliminar transacción", self)
        action_eliminar.triggered.connect(self.eliminar_transaccion_seleccionada)
        menu.addAction(action_eliminar)
        
        menu.addSeparator()
        
        # Opción de copiar descripción
        action_copiar = QAction("Copiar descripción", self)
        action_copiar.triggered.connect(lambda: self._copiar_descripcion(fila))
        menu.addAction(action_copiar)
        
        menu.exec(self.tabla.mapToGlobal(pos))

    def _copiar_descripcion(self, fila):
        """Copia la descripción de la transacción al portapapeles."""
        if fila >= len(self.transacciones_filtradas):
            return
        
        descripcion = self.transacciones_filtradas[fila].get('descripcion', '')
        QApplication.clipboard().setText(descripcion)
        logger.debug(f"Descripción copiada al portapapeles: {descripcion[:50]}...")