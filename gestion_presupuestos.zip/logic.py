import sqlite3
import os
import uuid
import datetime
from dialogo_proyecto import ProyectoDialog
from transacciones_widget import TransaccionesWidget
class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self._conectar()

    def cerrar(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    # --- CREACION DE TABLAS ---
    def crear_tablas_iniciales(self):
        print("[INFO] Verificando tablas...")
        # Aquí puedes añadir el campo tipo a cuentas si lo quieres para cuentas maestras
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS cuentas("
            "id INTEGER PRIMARY KEY,"
            "nombre TEXT NOT NULL UNIQUE,"
            "tipo TEXT DEFAULT 'normal'"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS proyectos("
            "id INTEGER PRIMARY KEY,"
            "nombre TEXT NOT NULL UNIQUE,"
            "moneda TEXT NOT NULL,"
            "cuenta_principal TEXT"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS categorias("
            "id INTEGER PRIMARY KEY,"
            "nombre TEXT NOT NULL UNIQUE"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS subcategorias("
            "id INTEGER PRIMARY KEY,"
            "nombre TEXT NOT NULL,"
            "categoria_id INTEGER NOT NULL,"
            "FOREIGN KEY(categoria_id)REFERENCES categorias(id)ON DELETE CASCADE,"
            "UNIQUE(nombre,categoria_id)"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS transacciones("
            "id TEXT PRIMARY KEY,"
            "proyecto_id INTEGER NOT NULL,"
            "cuenta_id INTEGER NOT NULL,"
            "categoria_id INTEGER NOT NULL,"
            "subcategoria_id INTEGER,"
            "tipo TEXT NOT NULL,"
            "descripcion TEXT NOT NULL,"
            "comentario TEXT,"
            "monto REAL NOT NULL,"
            "fecha DATE NOT NULL,"
            "FOREIGN KEY(proyecto_id)REFERENCES proyectos(id)ON DELETE CASCADE,"
            "FOREIGN KEY(cuenta_id)REFERENCES cuentas(id),"
            "FOREIGN KEY(categoria_id)REFERENCES categorias(id),"
            "FOREIGN KEY(subcategoria_id)REFERENCES subcategorias(id)"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS presupuestos("
            "id INTEGER PRIMARY KEY,"
            "proyecto_id INTEGER NOT NULL,"
            "subcategoria_id INTEGER NOT NULL,"
            "monto REAL NOT NULL,"
            "FOREIGN KEY(proyecto_id)REFERENCES proyectos(id)ON DELETE CASCADE,"
            "FOREIGN KEY(subcategoria_id)REFERENCES subcategorias(id)ON DELETE CASCADE,"
            "UNIQUE(proyecto_id,subcategoria_id)"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS proyecto_cuentas("
            "proyecto_id INTEGER NOT NULL,"
            "cuenta_id INTEGER NOT NULL,"
            "is_principal INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(proyecto_id, cuenta_id),"
            "FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,"
            "FOREIGN KEY(cuenta_id) REFERENCES cuentas(id) ON DELETE CASCADE"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS proyecto_categorias("
            "proyecto_id INTEGER NOT NULL,"
            "categoria_id INTEGER NOT NULL,"
            "PRIMARY KEY(proyecto_id, categoria_id),"
            "FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,"
            "FOREIGN KEY(categoria_id) REFERENCES categorias(id) ON DELETE CASCADE"
            ");"
        )
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS proyecto_subcategorias("
            "proyecto_id INTEGER NOT NULL,"
            "subcategoria_id INTEGER NOT NULL,"
            "PRIMARY KEY(proyecto_id, subcategoria_id),"
            "FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,"
            "FOREIGN KEY(subcategoria_id) REFERENCES subcategorias(id) ON DELETE CASCADE"
            ");"
        )
        self.conn.commit()
        print("[INFO] Tablas verificadas.")

    # --- CUENTAS MAESTRAS ---
    def obtener_cuentas_maestras(self):
        cursor = self.conn.execute("SELECT id, nombre FROM cuentas ORDER BY nombre")
        return [dict(row) for row in cursor.fetchall()]
    def agregar_cuenta_maestra(self, nombre):
        cursor = self.conn.execute("INSERT INTO cuentas (nombre, tipo) VALUES (?, 'maestra')", (nombre,))
        self.conn.commit()
        return cursor.lastrowid

    def editar_cuenta_maestra(self, nombre_actual, nuevo_nombre):
        self.conn.execute("UPDATE cuentas SET nombre=? WHERE nombre=? AND tipo='maestra'", (nuevo_nombre, nombre_actual))
        self.conn.commit()

    def eliminar_cuenta_maestra(self, nombre):
        self.conn.execute("DELETE FROM cuentas WHERE nombre=? AND tipo='maestra'", (nombre,))
        self.conn.commit()

    # --- CUENTAS COMUNES ---
    def obtener_cuentas(self):
        return self.conn.execute("SELECT * FROM cuentas WHERE tipo!='maestra' ORDER BY nombre").fetchall()

    def agregar_cuenta(self, nombre):
        return self.conn.execute("INSERT INTO cuentas (nombre) VALUES (?)", (nombre,)).lastrowid

    def editar_cuenta(self, id, nuevo_nombre):
        self.conn.execute("UPDATE cuentas SET nombre = ? WHERE id = ?", (nuevo_nombre, id))
        self.conn.commit()

    def eliminar_cuenta(self, id):
        self.conn.execute("DELETE FROM cuentas WHERE id = ?", (id,))
        self.conn.commit()

    # --- CATEGORÍAS ---
    # --- Métodos de consulta robustos y de reasignación ---

    def obtener_categorias(self):
        self._conectar()
        cursor = self.conn.execute("SELECT * FROM categorias ORDER BY nombre")
        return [dict(row) for row in cursor.fetchall()]

    def obtener_categorias_por_proyecto(self, proyecto_id):
        self._conectar()
        query = """
            SELECT C.* FROM categorias C
            JOIN proyecto_categorias PC ON C.id = PC.categoria_id
            WHERE PC.proyecto_id = ?
            ORDER BY C.nombre
        """
        cursor = self.conn.execute(query, (proyecto_id,))
        return [dict(row) for row in cursor.fetchall()]

    def asignar_categorias_a_proyecto(self, proyecto_id, lista_categorias_ids):
        """
        Asocia una lista de categorías al proyecto, reemplazando las actuales.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM proyecto_categorias WHERE proyecto_id = ?", (proyecto_id,))
            for cat_id in lista_categorias_ids:
                cursor.execute(
                    "INSERT INTO proyecto_categorias (proyecto_id, categoria_id) VALUES (?, ?)",
                    (proyecto_id, cat_id)
                )
            self.conn.commit()
            return True
        except Exception as e:
            print(f"[ERROR] al asignar categorías a proyecto: {e}")
            self.conn.rollback()
            return False
    def agregar_categoria(self, nombre):
        """
        Agrega una nueva categoría maestra.
        """
        cursor = self.conn.execute("INSERT INTO categorias (nombre) VALUES (?)", (nombre,))
        self.conn.commit()
        return cursor.lastrowid

    def editar_categoria(self, id, nuevo_nombre):
        """
        Renombra una categoría maestra.
        """
        self.conn.execute("UPDATE categorias SET nombre = ? WHERE id = ?", (nuevo_nombre, id))
        self.conn.commit()

    def eliminar_categoria(self, id):
        """
        Elimina una categoría maestra (si no está en uso en transacciones).
        """
        self.conn.execute("DELETE FROM categorias WHERE id = ?", (id,))
        self.conn.commit()
    # --- SUBCATEGORÍAS ---
    def obtener_subcategorias_por_categoria(self, categoria_id):
        self._conectar()
        cursor = self.conn.execute("SELECT * FROM subcategorias WHERE categoria_id = ? ORDER BY nombre", (categoria_id,))
        return [dict(row) for row in cursor.fetchall()]

    def obtener_subcategorias_por_proyecto(self, proyecto_id):
        self._conectar()
        query = """
            SELECT S.*, C.nombre as categoria_nombre
            FROM subcategorias S
            JOIN proyecto_subcategorias PS ON S.id = PS.subcategoria_id
            JOIN categorias C ON S.categoria_id = C.id
            WHERE PS.proyecto_id = ?
            ORDER BY C.nombre, S.nombre
        """
        cursor = self.conn.execute(query, (proyecto_id,))
        return [dict(row) for row in cursor.fetchall()]

    def asignar_subcategorias_a_proyecto(self, proyecto_id, lista_subcategorias_ids):
        """
        Asocia una lista de subcategorías al proyecto, reemplazando las actuales.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM proyecto_subcategorias WHERE proyecto_id = ?", (proyecto_id,))
            for subcat_id in lista_subcategorias_ids:
                cursor.execute(
                    "INSERT INTO proyecto_subcategorias (proyecto_id, subcategoria_id) VALUES (?, ?)",
                    (proyecto_id, subcat_id)
                )
            self.conn.commit()
            return True
        except Exception as e:
            print(f"[ERROR] al asignar subcategorías a proyecto: {e}")
            self.conn.rollback()
            return False

    def agregar_subcategoria(self, nombre, categoria_id):
        """
        Agrega una nueva subcategoría maestra a una categoría global.
        """
        cursor = self.conn.execute("INSERT INTO subcategorias (nombre, categoria_id) VALUES (?, ?)", (nombre, categoria_id))
        self.conn.commit()
        return cursor.lastrowid

    def editar_subcategoria(self, id, nuevo_nombre):
        """
        Renombra una subcategoría maestra.
        """
        self.conn.execute("UPDATE subcategorias SET nombre = ? WHERE id = ?", (nuevo_nombre, id))
        self.conn.commit()

    def eliminar_subcategoria(self, id):
        """
        Elimina una subcategoría maestra (si no está en uso).
        """
        self.conn.execute("DELETE FROM subcategorias WHERE id = ?", (id,))
        self.conn.commit()

    # --- PROYECTOS ---
    def crear_proyecto(self, nombre, moneda, cuenta_principal):
        cursor = self.conn.execute("INSERT INTO proyectos (nombre, moneda, cuenta_principal) VALUES (?, ?, ?)", (nombre, moneda, cuenta_principal))
        self.conn.commit()
        return cursor.lastrowid

    def obtener_proyectos(self):
        return self.conn.execute("SELECT * FROM proyectos ORDER BY nombre").fetchall()

    def obtener_proyecto_por_id(self, proyecto_id):
        return self.conn.execute("SELECT * FROM proyectos WHERE id = ?", (proyecto_id,)).fetchone()

    # --- TRANSACCIONES ---
    def obtener_transacciones_por_proyecto(self, proyecto_id, filtros=None):
        self._conectar()
        query = """
            SELECT T.*, C.nombre AS categoria_nombre, S.nombre AS subcategoria_nombre, CU.nombre AS cuenta_nombre
            FROM transacciones T
            JOIN categorias C ON T.categoria_id = C.id
            JOIN cuentas CU ON T.cuenta_id = CU.id
            LEFT JOIN subcategorias S ON T.subcategoria_id = S.id
            WHERE T.proyecto_id = :proyecto_id
        """
        params = {'proyecto_id': proyecto_id}
        if filtros:
            if filtros.get('tipo'):
                query += " AND T.tipo = :tipo"
                params['tipo'] = filtros['tipo']
            if filtros.get('cuenta_id'):
                query += " AND T.cuenta_id = :cuenta_id"
                params['cuenta_id'] = filtros['cuenta_id']
            if filtros.get('categoria_id'):
                query += " AND T.categoria_id = :categoria_id"
                params['categoria_id'] = filtros['categoria_id']
            if filtros.get('subcategoria_id'):
                query += " AND T.subcategoria_id = :subcategoria_id"
                params['subcategoria_id'] = filtros['subcategoria_id']
            if filtros.get('fecha_inicio'):
                query += " AND T.fecha >= :fecha_inicio"
                params['fecha_inicio'] = filtros['fecha_inicio']
            if filtros.get('fecha_fin'):
                query += " AND T.fecha <= :fecha_fin"
                params['fecha_fin'] = filtros['fecha_fin']
        query += " ORDER BY T.fecha DESC, T.id DESC"
        cursor = self.conn.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]

    def agregar_transaccion(self, datos_transaccion):
        query = """
            INSERT INTO transacciones (
                id, proyecto_id, cuenta_id, categoria_id, subcategoria_id, 
                tipo, descripcion, comentario, monto, fecha
            ) VALUES (
                :id, :proyecto_id, :cuenta_id, :categoria_id, :subcategoria_id, 
                :tipo, :descripcion, :comentario, :monto, :fecha
            )
        """
        self.conn.execute(query, datos_transaccion)
        self.conn.commit()
        return True

    def editar_transaccion(self, transaccion_id, datos):
        query = "UPDATE transacciones SET cuenta_id = :cuenta_id, categoria_id = :categoria_id, subcategoria_id = :subcategoria_id, tipo = :tipo, descripcion = :descripcion, comentario = :comentario, monto = :monto, fecha = :fecha WHERE id = :id"
        datos['id'] = transaccion_id
        self.conn.execute(query, datos)
        self.conn.commit()
        return True

    def eliminar_transaccion(self, transaccion_id):
        self.conn.execute("DELETE FROM transacciones WHERE id = ?", (transaccion_id,))
        self.conn.commit()
        return True

    # --- UTILITY ---
    def obtener_o_crear_id(self, tabla, nombre, extra_col=None, extra_val=None):
        self._conectar()
        if not nombre: return None
        if extra_col and extra_val is None: return None
        if extra_col:
            query_select = f"SELECT id FROM {tabla} WHERE nombre = ? AND {extra_col} = ?"
            params_select = (nombre, extra_val)
        else:
            query_select = f"SELECT id FROM {tabla} WHERE nombre = ?"
            params_select = (nombre,)
        resultado = self.conn.execute(query_select, params_select).fetchone()
        if resultado: return resultado['id']
        if extra_col:
            query_insert = f"INSERT INTO {tabla} (nombre, {extra_col}) VALUES (?, ?)"
            params_insert = (nombre, extra_val)
        else:
            query_insert = f"INSERT INTO {tabla} (nombre) VALUES (?)"
            params_insert = (nombre,)
        cursor = self.conn.execute(query_insert, params_insert)
        self.conn.commit()
        return cursor.lastrowid

    def mostrar_dialogo_seleccion_proyecto(self):
        proyectos = self.db.obtener_proyectos() or []
        proyectos_existentes = [p['nombre'] for p in proyectos]

        dialogo = ProyectoDialog(proyectos_existentes, self)
        if dialogo.exec():
            resultado = dialogo.resultado
            if resultado:
                accion = resultado[0]
                if accion == "abrir":
                    nombre = resultado[1]
                    proyecto_row = next((p for p in proyectos if p['nombre'] == nombre), None)
                    self.info_label.setText(f"Proyecto seleccionado: {nombre}")
                    if proyecto_row:
                        self.proyecto_actual = Proyecto(self.db, proyecto_row['id'])  # <--- AQUÍ ASIGNAS EL PROYECTO
                        self.proyecto_actual.cargar_datos()
                        widget = TransaccionesWidget(self.db, proyecto_actual=self.proyecto_actual)
                        self.setCentralWidget(widget)

    def obtener_cuentas_por_proyecto(self, proyecto_id):
        """
        Devuelve todas las cuentas asociadas a un proyecto, con indicación de cuál es principal.
        """
        query = """
            SELECT C.id, C.nombre, PC.is_principal
            FROM cuentas C
            JOIN proyecto_cuentas PC ON C.id = PC.cuenta_id
            WHERE PC.proyecto_id = ?
            ORDER BY PC.is_principal DESC, C.nombre ASC;
        """
        cursor = self.conn.execute(query, (proyecto_id,))
        return [dict(row) for row in cursor.fetchall()]


    def actualizar_cuentas_de_proyecto(self, proyecto_id, lista_cuentas_ids, id_cuenta_principal):
        """
        Borra y re-inserta todas las cuentas para un proyecto, marcando la principal.
        Esto se hace en una transacción para asegurar la integridad de los datos.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute("BEGIN TRANSACTION;")
            
            # 1. Borrar todas las asociaciones existentes para este proyecto
            cursor.execute("DELETE FROM proyecto_cuentas WHERE proyecto_id = ?", (proyecto_id,))
            
            # 2. Re-insertar las nuevas asociaciones
            for cuenta_id in lista_cuentas_ids:
                is_principal = 1 if cuenta_id == id_cuenta_principal else 0
                cursor.execute(
                    "INSERT INTO proyecto_cuentas (proyecto_id, cuenta_id, is_principal) VALUES (?, ?, ?)",
                    (proyecto_id, cuenta_id, is_principal)
                )

            # 3. Actualiza el campo cuenta_principal en la tabla proyectos
            cuenta_principal_nombre_row = cursor.execute("SELECT nombre FROM cuentas WHERE id = ?", (id_cuenta_principal,)).fetchone()
            if cuenta_principal_nombre_row:
                cursor.execute("UPDATE proyectos SET cuenta_principal = ? WHERE id = ?", (cuenta_principal_nombre_row['nombre'], proyecto_id))

            self.conn.commit()
            return True
        except Exception as e:
            print(f"[ERROR] Falló la actualización de cuentas del proyecto: {e}")
            self.conn.rollback()
            return False

    def obtener_presupuestos_por_proyecto(self, proyecto_id):
        """
        Devuelve los presupuestos asignados por categoría del proyecto.
        """
        query = """
            SELECT PC.categoria_id, C.nombre AS categoria_nombre, PC.presupuesto
            FROM proyecto_categorias PC
            JOIN categorias C ON PC.categoria_id = C.id
            WHERE PC.proyecto_id = ?
            ORDER BY C.nombre
        """
        cursor = self.conn.execute(query, (proyecto_id,))
        return [dict(row) for row in cursor.fetchall()]

    def actualizar_presupuesto_categoria(self, proyecto_id, categoria_id, nuevo_presupuesto):
        """
        Actualiza el presupuesto asignado para una categoría del proyecto.
        """
        self.conn.execute(
            "UPDATE proyecto_categorias SET presupuesto = ? WHERE proyecto_id = ? AND categoria_id = ?",
            (nuevo_presupuesto, proyecto_id, categoria_id)
        )
        self.conn.commit()

    def obtener_gasto_por_categoria_en_proyecto(self, proyecto_id, categoria_id):
        """
        Devuelve el gasto total registrado en la categoría dentro del proyecto.
        """
        query = """
            SELECT SUM(t.monto) as total
            FROM transacciones t
            WHERE t.proyecto_id = ? AND t.categoria_id = ?
        """
        result = self.conn.execute(query, (proyecto_id, categoria_id)).fetchone()
        return result["total"] if result and result["total"] is not None else 0

    def obtener_presupuestos_por_subcategoria(self, proyecto_id):
        """
        Devuelve los presupuestos asignados por subcategoría del proyecto.
        """
        query = """
            SELECT PSC.subcategoria_id, S.nombre AS subcategoria_nombre, C.nombre AS categoria_nombre, PSC.presupuesto
            FROM proyecto_subcategorias PSC
            JOIN subcategorias S ON PSC.subcategoria_id = S.id
            JOIN categorias C ON S.categoria_id = C.id
            WHERE PSC.proyecto_id = ?
            ORDER BY C.nombre, S.nombre
        """
        cursor = self.conn.execute(query, (proyecto_id,))
        return [dict(row) for row in cursor.fetchall()]

    def actualizar_presupuesto_subcategoria(self, proyecto_id, subcategoria_id, nuevo_presupuesto):
        """
        Actualiza el presupuesto asignado para una subcategoría del proyecto.
        """
        self.conn.execute(
            "UPDATE proyecto_subcategorias SET presupuesto = ? WHERE proyecto_id = ? AND subcategoria_id = ?",
            (nuevo_presupuesto, proyecto_id, subcategoria_id)
        )
        self.conn.commit()

    def obtener_gasto_por_subcategoria_en_proyecto(self, proyecto_id, subcategoria_id):
        """
        Devuelve el gasto total registrado en la subcategoría dentro del proyecto.
        """
        query = """
            SELECT SUM(t.monto) as total
            FROM transacciones t
            WHERE t.proyecto_id = ? AND t.subcategoria_id = ?
        """
        result = self.conn.execute(query, (proyecto_id, subcategoria_id)).fetchone()
        return result["total"] if result and result["total"] is not None else 0


    def obtener_transacciones_por_fecha(self, proyecto_id, fecha_ini, fecha_fin):
        """
        Devuelve las transacciones del proyecto entre dos fechas, con categoría y subcategoría.
        """
        query = """
            SELECT t.tipo, t.monto, t.fecha, t.descripcion,
                c.nombre AS categoria_nombre, s.nombre AS subcategoria_nombre
            FROM transacciones t
            LEFT JOIN categorias c ON t.categoria_id = c.id
            LEFT JOIN subcategorias s ON t.subcategoria_id = s.id
            WHERE t.proyecto_id = ? AND t.fecha BETWEEN ? AND ?
            ORDER BY t.fecha ASC
        """
        cursor = self.conn.execute(query, (proyecto_id, fecha_ini, fecha_fin))
        return [dict(row) for row in cursor.fetchall()]

    def obtener_gastos_por_categoria_y_subcategoria(self, proyecto_id, fecha_inicio=None, fecha_fin=None):
        """
        Devuelve dicts con categoría, subcategoría y total gastado en el proyecto y rango de fechas.
        """
        query = """
            SELECT
                c.id as categoria_id,
                c.nombre as categoria,
                s.id as subcategoria_id,
                s.nombre as subcategoria,
                SUM(CASE WHEN t.tipo='Gasto' THEN t.monto ELSE 0 END) as total_gasto
            FROM categorias c
            JOIN subcategorias s ON s.categoria_id = c.id
            LEFT JOIN transacciones t
                ON t.proyecto_id = ?
                AND t.categoria_id = c.id
                AND t.subcategoria_id = s.id
                {}
            GROUP BY c.id, s.id
            ORDER BY c.nombre, s.nombre
        """
        filtro_fecha = ""
        params = [proyecto_id]
        if fecha_inicio:
            filtro_fecha += "AND t.fecha >= ? "
            params.append(fecha_inicio)
        if fecha_fin:
            filtro_fecha += "AND t.fecha <= ? "
            params.append(fecha_fin)
        query = query.format(filtro_fecha)
        cur = self.conn.execute(query, params)
        return [dict(row) for row in cur.fetchall()]


    def reporte_gastos_por_categoria(db, proyecto_id, fecha_inicio, fecha_fin):
        query = """
        SELECT
            c.nombre AS categoria,
            s.nombre AS subcategoria,
            SUM(t.monto) AS total_gastado
        FROM transacciones t
        JOIN categorias c ON t.categoria_id = c.id
        JOIN subcategorias s ON t.subcategoria_id = s.id
        WHERE t.proyecto_id = ?
        AND t.tipo = 'Gasto'
        AND t.fecha BETWEEN ? AND ?
        GROUP BY c.nombre, s.nombre
        ORDER BY c.nombre, s.nombre;
        """
        cur = db.cursor()
        cur.execute(query, (proyecto_id, fecha_inicio, fecha_fin))
        return [dict(row) for row in cur.fetchall()]

    def resumen_por_cuenta(self, proyecto_id):
        query = """
            SELECT
                CU.nombre AS cuenta,
                SUM(CASE WHEN T.tipo = 'Ingreso' THEN T.monto ELSE 0 END) AS total_ingresos,
                SUM(CASE WHEN T.tipo = 'Gasto' THEN T.monto ELSE 0 END) AS total_gastos
            FROM transacciones T
            JOIN cuentas CU ON T.cuenta_id = CU.id
            WHERE T.proyecto_id = ?
            GROUP BY CU.id
            ORDER BY cuenta ASC
        """
        return self.fetch_all(query, (proyecto_id,))


    def fetch_all(self, query, params=()):
        cur = self.conn.cursor()
        cur.execute(query, params)
        columns = [desc[0] for desc in cur.description]
        results = [dict(zip(columns, row)) for row in cur.fetchall()]
        cur.close()
        return results

    def reporte_gastos_por_categoria(self, proyecto_id, fecha_inicio, fecha_fin):
        query = """
        SELECT
            c.nombre AS categoria,
            SUM(t.monto) AS total_gastado
        FROM transacciones t
        JOIN categorias c ON t.categoria_id = c.id
        WHERE t.proyecto_id = ?
        AND t.tipo = 'Gasto'
        AND t.fecha BETWEEN ? AND ?
        GROUP BY c.nombre
        ORDER BY total_gastado DESC;
        """
        cur = self.conn.execute(query, (proyecto_id, fecha_inicio, fecha_fin))
        return [dict(row) for row in cur.fetchall()]

    def balances_globales_todas_cuentas(self):
        query = """
            SELECT
                CU.nombre AS cuenta,
                SUM(CASE WHEN T.tipo = 'Ingreso' THEN T.monto ELSE 0 END) AS total_ingresos,
                SUM(CASE WHEN T.tipo = 'Gasto' THEN T.monto ELSE 0 END) AS total_gastos
            FROM transacciones T
            JOIN cuentas CU ON T.cuenta_id = CU.id
            GROUP BY CU.nombre
            ORDER BY CU.nombre;
        """
        return self._ejecutar_consulta(query, fetchall=True)

    def obtener_todas_las_transacciones(self):
        query = """
            SELECT
                T.fecha, T.tipo, T.monto,
                P.nombre AS proyecto,
                CU.nombre AS cuenta,
                C.nombre AS categoria,
                S.nombre AS subcategoria
            FROM transacciones T
            JOIN proyectos P ON T.proyecto_id = P.id
            JOIN cuentas CU ON T.cuenta_id = CU.id
            JOIN categorias C ON T.categoria_id = C.id
            LEFT JOIN subcategorias S ON T.subcategoria_id = S.id
            ORDER BY T.fecha DESC;
        """
        return self._ejecutar_consulta(query, fetchall=True)

    def balance_consolidado_por_cuenta_nombre(self, nombre_cuenta):
        query = """
            SELECT
                SUM(CASE WHEN T.tipo = 'Ingreso' THEN T.monto ELSE 0 END) AS total_ingresos,
                SUM(CASE WHEN T.tipo = 'Gasto' THEN T.monto ELSE 0 END) AS total_gastos
            FROM transacciones T
            JOIN cuentas CU ON T.cuenta_id = CU.id
            WHERE CU.nombre = ?;
        """
        return self._ejecutar_consulta(query, (nombre_cuenta,), fetchone=True)
    
    def _ejecutar_consulta(self, query, params=(), commit=False, fetchone=False, fetchall=False):
        try:
            self._conectar()
            cursor = self.conn.cursor()
            cursor.execute(query, params)
            if commit:
                self.conn.commit()
                return cursor.lastrowid
            if fetchone:
                return cursor.fetchone()
            if fetchall:
                return cursor.fetchall()
        except sqlite3.Error as e:
            print(f"[ERROR] SQL: {e}\n > Q: {query}\n > P: {params}")
        finally:
            self._cerrar()

    def _conectar(self):
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA foreign_keys = ON;")

    def _cerrar(self):
        if self.conn:
            self.conn.close()
            self.conn = None


    def reasignar_multiples_transacciones(self, transaccion_ids, nueva_categoria_id, nueva_subcategoria_id):
        self._conectar()
        if not transaccion_ids:
            return False
        placeholders = ','.join(['?'] * len(transaccion_ids))
        query = f"""
            UPDATE transacciones
            SET categoria_id = ?, subcategoria_id = ?
            WHERE id IN ({placeholders})
        """
        params = [nueva_categoria_id, nueva_subcategoria_id] + list(transaccion_ids)
        try:
            self.conn.execute(query, params)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error al reasignar transacciones: {e}")
            return False
        
    def obtener_transacciones_por_categoria(self, proyecto_id, categoria_id):
        self._conectar()
        query = """
            SELECT T.*, C.nombre AS categoria_nombre, S.nombre AS subcategoria_nombre, CU.nombre AS cuenta_nombre
            FROM transacciones T
            JOIN categorias C ON T.categoria_id = C.id
            JOIN cuentas CU ON T.cuenta_id = CU.id
            LEFT JOIN subcategorias S ON T.subcategoria_id = S.id
            WHERE T.proyecto_id = ? AND T.categoria_id = ?
            ORDER BY T.fecha DESC, T.id DESC
        """
        cursor = self.conn.execute(query, (proyecto_id, categoria_id))
        return [dict(row) for row in cursor.fetchall()]

    def obtener_transacciones_por_subcategoria(self, proyecto_id, subcategoria_id):
        self._conectar()
        query = """
            SELECT T.*, C.nombre AS categoria_nombre, S.nombre AS subcategoria_nombre, CU.nombre AS cuenta_nombre
            FROM transacciones T
            JOIN categorias C ON T.categoria_id = C.id
            JOIN cuentas CU ON T.cuenta_id = CU.id
            LEFT JOIN subcategorias S ON T.subcategoria_id = S.id
            WHERE T.proyecto_id = ? AND T.subcategoria_id = ?
            ORDER BY T.fecha DESC, T.id DESC
        """
        cursor = self.conn.execute(query, (proyecto_id, subcategoria_id))
        return [dict(row) for row in cursor.fetchall()]

    def obtener_transacciones_sin_categoria_activa(self, proyecto_id):
        self._conectar()
        categorias_activas_ids = set(c['id'] for c in self.obtener_categorias_por_proyecto(proyecto_id) or [])
        todas_trans = self.obtener_transacciones_por_proyecto(proyecto_id) or []
        return [dict(t) for t in todas_trans if t['categoria_id'] not in categorias_activas_ids]

    def obtener_transacciones_sin_subcategoria_activa(self, proyecto_id):
        self._conectar()
        subcategorias_activas_ids = set(s['id'] for s in self.obtener_subcategorias_por_proyecto(proyecto_id) or [])
        todas_trans = self.obtener_transacciones_por_proyecto(proyecto_id) or []
        return [dict(t) for t in todas_trans if t['subcategoria_id'] and t['subcategoria_id'] not in subcategorias_activas_ids]


    def reasignar_transacciones_por_categoria(self, proyecto_id, categoria_origen_id, categoria_destino_id, subcategoria_destino_id=None):
        self._conectar()
        query = "UPDATE transacciones SET categoria_id = ?, subcategoria_id = ? WHERE proyecto_id = ? AND categoria_id = ?"
        params = [categoria_destino_id, subcategoria_destino_id, proyecto_id, categoria_origen_id]
        self.conn.execute(query, params)
        self.conn.commit()
        return True

    def reasignar_transacciones_por_subcategoria(self, proyecto_id, subcategoria_origen_id, categoria_destino_id, subcategoria_destino_id):
        self._conectar()
        query = "UPDATE transacciones SET categoria_id = ?, subcategoria_id = ? WHERE proyecto_id = ? AND subcategoria_id = ?"
        params = [categoria_destino_id, subcategoria_destino_id, proyecto_id, subcategoria_origen_id]
        self.conn.execute(query, params)
        self.conn.commit()
        return True
    

    def importar_categorias_y_subcategorias_de_proyecto(self, proyecto_origen_id, proyecto_destino_id):
        """
        Importa todas las categorías y subcategorías activas de un proyecto origen a otro destino.
        No duplica asociaciones existentes.
        """
        self._conectar()
        # 1. Obtener categorías activas en el proyecto origen
        categorias_origen = self.obtener_categorias_por_proyecto(proyecto_origen_id)
        categorias_destino = self.obtener_categorias_por_proyecto(proyecto_destino_id)
        categorias_destino_ids = set(c['id'] for c in categorias_destino)

        # 2. Insertar categorías en proyecto destino si no existen
        for cat in categorias_origen:
            if cat['id'] not in categorias_destino_ids:
                self.conn.execute(
                    "INSERT INTO proyecto_categorias (proyecto_id, categoria_id) VALUES (?, ?)",
                    (proyecto_destino_id, cat['id'])
                )

        # 3. Subcategorías activas en el proyecto origen
        subcategorias_origen = self.obtener_subcategorias_por_proyecto(proyecto_origen_id)
        subcategorias_destino = self.obtener_subcategorias_por_proyecto(proyecto_destino_id)
        subcategorias_destino_ids = set(s['id'] for s in subcategorias_destino)

        # 4. Insertar subcategorías en proyecto destino si no existen
        for sub in subcategorias_origen:
            if sub['id'] not in subcategorias_destino_ids:
                self.conn.execute(
                    "INSERT INTO proyecto_subcategorias (proyecto_id, subcategoria_id) VALUES (?, ?)",
                    (proyecto_destino_id, sub['id'])
                )

        self.conn.commit()
        return True

    def obtener_fecha_primera_transaccion(self, proyecto_id):
        self._conectar()
        query = "SELECT MIN(fecha) as primera_fecha FROM transacciones WHERE proyecto_id = ?"
        row = self.conn.execute(query, (proyecto_id,)).fetchone()
        return row["primera_fecha"] if row and row["primera_fecha"] else None


# ---------------------------------------------------
# Clase Transaccion (igual que tu versión)
class Transaccion:
    def __init__(self, **kwargs):
        self.id = kwargs.get('id')
        self.proyecto_id = kwargs.get('proyecto_id')
        self.cuenta_id = kwargs.get('cuenta_id')
        self.categoria_id = kwargs.get('categoria_id')
        self.subcategoria_id = kwargs.get('subcategoria_id')
        self.tipo = kwargs.get('tipo')
        self.descripcion = kwargs.get('descripcion')
        self.comentario = kwargs.get('comentario')
        self.monto = float(kwargs.get('monto', 0))
        fecha = kwargs.get('fecha')
        self.cuenta_nombre = kwargs.get('cuenta_nombre', '')
        self.categoria_nombre = kwargs.get('categoria_nombre', '')
        self.subcategoria_nombre = kwargs.get('subcategoria_nombre', '')
        if isinstance(fecha, str):
            self.fecha = datetime.datetime.strptime(fecha, '%Y-%m-%d').date()
        else:
            self.fecha = fecha

    def __repr__(self):
        return f"<Transaccion(id='{self.id}', desc='{self.descripcion[:20]}')>"

# ---------------------------------------------------
# Clase Proyecto (igual que tu versión, solo cambiar db_manager a db_path si quieres)
class Proyecto:
    def __init__(self, db_manager: DatabaseManager, proyecto_id: int):
        self.db = db_manager
        self.id = proyecto_id
        self.nombre = ""
        self.moneda = "RD$"
        self.cuenta_principal = ""
        self.transacciones = []

    def cargar_datos(self):
        datos_proyecto = self.db.obtener_proyecto_por_id(self.id)
        if not datos_proyecto:
            return False
        self.nombre = datos_proyecto['nombre']
        self.moneda = datos_proyecto['moneda']
        self.cuenta_principal = datos_proyecto['cuenta_principal']
        datos_trans = self.db.obtener_transacciones_por_proyecto(self.id)
        self.transacciones = [Transaccion(**dict(fila)) for fila in datos_trans] if datos_trans else []
        return True

    def agregar_transaccion(self, datos_transaccion: dict):
        if 'id' not in datos_transaccion or not datos_transaccion['id']:
            datos_transaccion['id'] = str(uuid.uuid4())
        datos_transaccion['proyecto_id'] = self.id
        if self.db.agregar_transaccion(datos_transaccion):
            self.cargar_datos()
            return True
        return False

    def editar_transaccion(self, transaccion_id, nuevos_datos: dict):
        if self.db.editar_transaccion(transaccion_id, nuevos_datos):
            self.cargar_datos()
            return True
        return False

    def eliminar_transaccion(self, transaccion_id):
        if self.db.eliminar_transaccion(transaccion_id):
            self.transacciones = [t for t in self.transacciones if t.id != transaccion_id]
            return True
        return False