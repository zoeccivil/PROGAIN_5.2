import configparser
import os

CONFIG_FILE = 'progain_app.ini'
DB_SECTION = 'Database'
DB_KEY = 'path'
THEME_SECTION = 'Theme'
THEME_KEY = 'name'

def leer_ruta_db():
    config = configparser.ConfigParser()
    if os.path.exists(CONFIG_FILE):
        config.read(CONFIG_FILE)
        if config.has_section(DB_SECTION):
            db_path = config.get(DB_SECTION, DB_KEY, fallback="")
            if db_path and os.path.exists(db_path):
                return db_path
    return None

def guardar_ruta_db(ruta_db):
    config = configparser.ConfigParser()
    if os.path.exists(CONFIG_FILE):
        config.read(CONFIG_FILE)
    if not config.has_section(DB_SECTION):
        config.add_section(DB_SECTION)
    config.set(DB_SECTION, DB_KEY, ruta_db)
    with open(CONFIG_FILE, 'w') as f:
        config.write(f)

def get_theme():
    """Obtiene el nombre del tema guardado en la configuración.
    
    Returns:
        str | None: Nombre del tema o None si no hay uno guardado.
    """
    config = configparser.ConfigParser()
    if os.path.exists(CONFIG_FILE):
        config.read(CONFIG_FILE)
        if config.has_section(THEME_SECTION):
            return config.get(THEME_SECTION, THEME_KEY, fallback=None)
    return None

def set_theme(theme_name):
    """Guarda el nombre del tema en la configuración.
    
    Args:
        theme_name (str): Nombre del tema a guardar.
    """
    config = configparser.ConfigParser()
    if os.path.exists(CONFIG_FILE):
        config.read(CONFIG_FILE)
    if not config.has_section(THEME_SECTION):
        config.add_section(THEME_SECTION)
    config.set(THEME_SECTION, THEME_KEY, theme_name)
    with open(CONFIG_FILE, 'w') as f:
        config.write(f)