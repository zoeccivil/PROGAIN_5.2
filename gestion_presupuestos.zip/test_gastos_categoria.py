import sqlite3

DB_PATH = "D:/Dropbox/PROGAIN/PROGAIN PyQT6/tu_base_de_datos.db"  # Cambia aquí la ruta

def crear_tablas(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cuentas(
            id INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL UNIQUE,
            tipo TEXT DEFAULT 'normal'
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proyectos(
            id INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL UNIQUE,
            moneda TEXT NOT NULL,
            cuenta_principal TEXT
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS categorias(
            id INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL UNIQUE
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS subcategorias(
            id INTEGER PRIMARY KEY,
            nombre TEXT NOT NULL,
            categoria_id INTEGER NOT NULL,
            FOREIGN KEY(categoria_id)REFERENCES categorias(id)ON DELETE CASCADE,
            UNIQUE(nombre,categoria_id)
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS transacciones(
            id TEXT PRIMARY KEY,
            proyecto_id INTEGER NOT NULL,
            cuenta_id INTEGER NOT NULL,
            categoria_id INTEGER NOT NULL,
            subcategoria_id INTEGER,
            tipo TEXT NOT NULL,
            descripcion TEXT NOT NULL,
            comentario TEXT,
            monto REAL NOT NULL,
            fecha DATE NOT NULL,
            FOREIGN KEY(proyecto_id)REFERENCES proyectos(id)ON DELETE CASCADE,
            FOREIGN KEY(cuenta_id)REFERENCES cuentas(id),
            FOREIGN KEY(categoria_id)REFERENCES categorias(id),
            FOREIGN KEY(subcategoria_id)REFERENCES subcategorias(id)
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS presupuestos(
            id INTEGER PRIMARY KEY,
            proyecto_id INTEGER NOT NULL,
            subcategoria_id INTEGER NOT NULL,
            monto REAL NOT NULL,
            FOREIGN KEY(proyecto_id)REFERENCES proyectos(id)ON DELETE CASCADE,
            FOREIGN KEY(subcategoria_id)REFERENCES subcategorias(id)ON DELETE CASCADE,
            UNIQUE(proyecto_id,subcategoria_id)
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proyecto_cuentas(
            proyecto_id INTEGER NOT NULL,
            cuenta_id INTEGER NOT NULL,
            is_principal INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(proyecto_id, cuenta_id),
            FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
            FOREIGN KEY(cuenta_id) REFERENCES cuentas(id) ON DELETE CASCADE
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proyecto_categorias(
            proyecto_id INTEGER NOT NULL,
            categoria_id INTEGER NOT NULL,
            PRIMARY KEY(proyecto_id, categoria_id),
            FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
            FOREIGN KEY(categoria_id) REFERENCES categorias(id) ON DELETE CASCADE
        );
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proyecto_subcategorias(
            proyecto_id INTEGER NOT NULL,
            subcategoria_id INTEGER NOT NULL,
            PRIMARY KEY(proyecto_id, subcategoria_id),
            FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
            FOREIGN KEY(subcategoria_id) REFERENCES subcategorias(id) ON DELETE CASCADE
        );
    """)
    conn.commit()
    print("Tablas creadas o verificadas correctamente.")

def main():
    conn = sqlite3.connect(DB_PATH)
    crear_tablas(conn)
    conn.close()

if __name__ == "__main__":
    main()