import sqlite3

def obtener_transacciones_por_proyecto(db_path, proyecto_id):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    query = """
        SELECT Categoria, Subcategoria, Monto, Fecha
        FROM transacciones
        WHERE proyecto_id = ?
    """
    cur.execute(query, (proyecto_id,))
    rows = cur.fetchall()
    # Convierte a lista de dicts
    transacciones = [
        {"Categoría": r[0], "Subcategoría": r[1], "Monto": r[2], "Fecha": r[3]}
        for r in rows
    ]
    conn.close()
    return transacciones